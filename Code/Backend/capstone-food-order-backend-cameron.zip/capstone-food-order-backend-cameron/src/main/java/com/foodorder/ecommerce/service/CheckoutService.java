package com.foodorder.ecommerce.service;

import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.Order;

/**
 * CheckoutService used for order processing
 */
public interface CheckoutService {
    /**
     * Method to place order
     * @param customer details of customer placing order
     * @param order order information
     * @return newly created order
     */
    Order placeOrder(Customer customer, Order order);
}
