package com.foodorder.ecommerce.serviceImpl;


import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.dto.spring.TokenDto;
import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.CustomerResetToken;
import com.foodorder.ecommerce.entity.CustomerVerifyToken;
import com.foodorder.ecommerce.repositories.CustomerRepository;
import com.foodorder.ecommerce.repositories.CustomerResetTokenRepository;
import com.foodorder.ecommerce.repositories.CustomerVerifyTokenRepository;
import com.foodorder.ecommerce.security.ConstantsUtil;
import com.foodorder.ecommerce.service.CustomerTokenService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;

@Component
/**
 * Implementation of the CustomerTokenService interface.
 */
public class CustomerTokenImpl implements CustomerTokenService
{
    private final CustomerVerifyTokenRepository customerVerifyTokenRepository;
    private final CustomerResetTokenRepository customerResetTokenRepository;
    private final CustomerRepository customerRepository;

    public CustomerTokenImpl(final CustomerVerifyTokenRepository customerVerifyTokenRepository, final CustomerResetTokenRepository customerResetTokenRepository, final CustomerRepository customerRepository)
    {
        this.customerVerifyTokenRepository = customerVerifyTokenRepository;
        this.customerResetTokenRepository = customerResetTokenRepository;
        this.customerRepository = customerRepository;
    }

    @Override
    public CustomerVerifyToken getVerificationToken(CustomerDto customerDto)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerDto.getEmail());
        if(!customerCheck.isPresent())
            {
                throw new IllegalArgumentException("Incorrect Details Provided");
            }
        Optional<CustomerVerifyToken> customerVerifyTokenCheck = Optional.ofNullable(customerVerifyTokenRepository.findCustomerVerifyTokenByCustomer(customerCheck.get()));
        if(!customerVerifyTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Incorrect Details Provided");
            }

        return customerVerifyTokenCheck.get();
    }

    @Override
    public CustomerVerifyToken getVerificationToken(final TokenDto tokenDto)
    {
        Optional<CustomerVerifyToken> customerVerifyTokenCheck = Optional.ofNullable(customerVerifyTokenRepository.findCustomerVerifyTokensByToken(tokenDto.getToken()));
        if(!customerVerifyTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Invalid Token");
            }
        if(!verifyTokenExpiry(tokenDto.getToken()))
            {
                throw new IllegalArgumentException("Invalid Token");
            };
        return customerVerifyTokenCheck.get();
    }

    @Override
    public boolean deleteVerifyToken(final CustomerVerifyToken customerVerifyToken)
    {
        Optional<CustomerVerifyToken> customerVerifyTokenCheck = Optional.ofNullable(customerVerifyTokenRepository.findCustomerVerifyTokensByToken(customerVerifyToken.getToken()));
        if(!customerVerifyTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Invalid Token");
            }

        customerVerifyTokenRepository.delete(customerVerifyTokenCheck.get());
        return true;
    }

    @Override
    public CustomerResetToken generateResetToken(final CustomerDto customerDto)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerDto.getEmail());
        if(!customerCheck.isPresent())
            {
                throw new IllegalArgumentException();
            }
        Optional<CustomerResetToken> tokenCheck = Optional.ofNullable(customerResetTokenRepository.findByCustomer(customerCheck.get()));
        if(tokenCheck.isPresent())
            {

                 customerResetTokenRepository.delete(tokenCheck.get());
            }

        CustomerResetToken customerResetToken = new CustomerResetToken(customerCheck.get());
        customerResetTokenRepository.save(customerResetToken);
        return customerResetToken;

    }

    @Override
    public CustomerResetToken getResetToken(final TokenDto tokenDto)
    {
        Optional<CustomerResetToken> customerResetToken = Optional.ofNullable(customerResetTokenRepository.findByToken(tokenDto.getToken()));
        if(!customerResetToken.isPresent())
            {
                throw new IllegalArgumentException("Incorrect Details Provided");
            }
        if(!verifyTokenExpiry(tokenDto.getToken()))
            {
                throw new IllegalArgumentException("Token Expired");
            }
        return customerResetToken.get();
    }

    private boolean verifyTokenExpiry(final String token)
    {
        try
            {
                final Claims claim = (Claims) Jwts.parser().setSigningKey(ConstantsUtil.TOKEN_SECRET).parse(token).getBody();
                Date tokenDate = claim.getExpiration();
                if(new Date(System.currentTimeMillis()).compareTo(tokenDate) > 0 )
                    {
                       return false;
                    }
            }catch (ExpiredJwtException e)
            {
                return false;
            }

        return true;

    }

    @Override
    public boolean deleteResetToken(final CustomerResetToken customerResetToken)
    {
        Optional<CustomerResetToken> customerResetTokenCheck = Optional.ofNullable(customerResetTokenRepository.findByToken(customerResetToken.getToken()));
        if(!customerResetTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Invalid Token");
            }

        customerResetTokenRepository.delete(customerResetTokenCheck.get());
        return true;
    }

    @Override
    public String getUserDetailsFromToken(final TokenDto tokenDto)
    {
        String email = Jwts.parser()
                .setSigningKey(ConstantsUtil.TOKEN_SECRET)
                .parseClaimsJws(tokenDto.getToken())
                .getBody()
                .getSubject();
        if (email == null)
            {
                throw new IllegalStateException("Invalid");
            }

        return email;
    }


}
