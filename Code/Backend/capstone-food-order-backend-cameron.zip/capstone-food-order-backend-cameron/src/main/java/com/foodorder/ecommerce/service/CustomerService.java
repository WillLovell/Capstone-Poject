package com.foodorder.ecommerce.service;


import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.entity.Customer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

/**
 * Interface used for interaction with the Customer repository
 */
@Service
public interface CustomerService extends UserDetailsService
{
    /**
     * Retrieve requested Customer entity from DB
     * @param id of Customer
     * @return Customer
     */
    Customer getCustomer(Long id);

    /**
     * Create new user
     * @param customerRegistrationRequest new user details
     * @return new user
     */
    Customer createCustomer(CustomerDto customerRegistrationRequest);

    /**
     * Update user with new information
     * @param customerUpdateRequest new user details
     * @return updated user details
     */
    Customer updateCustomer(CustomerDto customerUpdateRequest);

    /**
     * Retrieve user by their username
     * @param email user email details
     * @return user queried
     */
    Customer getCustomerByEmail(String email);

    /**
     * Confirm user registration
     * @param customerUpdateRequest user details to confirm
     * @return the confirmed user
     */
    Customer confirmCustomer(CustomerDto customerUpdateRequest);

    /**
     * Reset user password to new password
     * @param customerDto user details
     * @param password new password
     * @return updated user
     */
    Customer resetPassword(CustomerDto customerDto, String password);
}

