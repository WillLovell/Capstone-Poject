package com.foodorder.ecommerce.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

/**
 * Menu Category class containing a set of menu items
 */
@Entity
@Table(name="menu_category")
@Getter
@Setter
public class MenuCategory
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String name;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "category")
    private Set<MenuItem> menuItems;

}







