package com.foodorder.ecommerce.repositories;

import com.foodorder.ecommerce.entity.CustomerAuthority;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/**
 * Extension of the CrudRepository used for the persistence of a CustomerAuthority entity
 */
@Repository
public interface CustomerAuthorityRepository extends CrudRepository<CustomerAuthority, Long>
{
    CustomerAuthority findByName (String name);
}
