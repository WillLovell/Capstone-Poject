package com.foodorder.ecommerce.repositories;

import com.foodorder.ecommerce.entity.CustomerRole;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/**
 * Extension of the CrudRepository used for the persistence of a StaffRole entity
 */
@Repository
public interface CustomerRoleRepository extends CrudRepository<CustomerRole, Long>
{
    CustomerRole findByName(String name);

}
