package com.foodorder.ecommerce.dto.rest;
/**
 * Data Transfer Class used for REST Request to reset Password
 */
public class PasswordRequestDto
{

    private String token;
    private String password;

    public PasswordRequestDto(final String token, final String password)
    {
        this.token = token;
        this.password = password;
    }

    public String getToken()
    {
        return token;
    }

    public String getPassword()
    {
        return password;
    }
}
