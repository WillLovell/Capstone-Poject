package com.foodorder.ecommerce.entity;

import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;
@Entity
@Component
/**
 * CustomerAuthority persisted to Database.
 */
public class CustomerAuthority implements Serializable
{
    private static final long serialVersionUID = -8058337323579748981L;

    @Id
    @Column(name = "id")
    @GeneratedValue(generator="CUSTOMER_AUTH_SEQ",strategy=GenerationType.SEQUENCE)
    private long id;

    @Column(nullable = false, unique = true)
    private String name;

    @ManyToMany(mappedBy = "authorities")
    private Set<CustomerRole> roles;

    public CustomerAuthority()
    {

    }

    public CustomerAuthority(final String name)
    {
        this.name = name;
    }



    public long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public Set<CustomerRole> getCustomerRoles()
    {
        return roles;
    }
}
