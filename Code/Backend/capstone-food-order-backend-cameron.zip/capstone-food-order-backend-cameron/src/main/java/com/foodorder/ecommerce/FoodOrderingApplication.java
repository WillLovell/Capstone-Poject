package com.foodorder.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
/**
 * Main Spring class
 */
public class FoodOrderingApplication
{

    public static void main(String[] args)
    {
        SpringApplication.run(FoodOrderingApplication.class, args);
    }

}
