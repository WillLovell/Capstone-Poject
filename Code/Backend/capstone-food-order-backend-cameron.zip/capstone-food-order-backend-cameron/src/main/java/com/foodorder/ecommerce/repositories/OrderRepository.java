package com.foodorder.ecommerce.repositories;

import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.Order;
import org.springframework.data.repository.CrudRepository;

import java.util.Set;
/**
 * Extension of the CrudRepository used for the persistence of an Order entity
 */
public interface OrderRepository extends CrudRepository<Order, Long>
{
    Set<Order> findAllByCustomer(final Customer customer);
    Set<Order> findAllByOrderStatusAndCustomer(final Order.OrderStatus orderStatus, final Customer customer);
    Order findOrderById(final Long id);

}
