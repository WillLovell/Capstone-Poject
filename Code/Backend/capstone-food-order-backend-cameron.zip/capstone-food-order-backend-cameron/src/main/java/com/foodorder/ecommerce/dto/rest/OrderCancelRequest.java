package com.foodorder.ecommerce.dto.rest;
import lombok.Getter;

/**
 * Request to cancel order JSON representation
 */
@Getter
public class OrderCancelRequest
{
    private long customerId;
    private long orderId;

    public OrderCancelRequest(final long customerId, final long orderId)
    {
        this.customerId = customerId;
        this.orderId = orderId;
    }

}
