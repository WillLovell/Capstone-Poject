/**
 * Used for Global exception handling
 */
package com.foodorder.ecommerce.exception;