package com.foodorder.ecommerce.dto.rest;
/**
 * Data Transfer Class used for REST Request to update an existing User entity
 */
public class CustomerUpdateRequestDto
{
    private String firstName;
    private String email;
    private String lastName;

    public CustomerUpdateRequestDto(final String firstName, final String email, final String lastName)
    {
        this.firstName = firstName;
        this.email = email;
        this.lastName = lastName;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getEmail()
    {
        return email;
    }

    public String getLastName()
    {
        return lastName;
    }
}
