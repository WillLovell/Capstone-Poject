package com.foodorder.ecommerce.service;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * Interface used for interaction with the RestaurantHours repository
 */
@Service
public interface RestaurantHoursService
{
    /**
     *
     * @param date
     * @return
     */
    boolean canPlaceOrder(LocalDateTime date);
}
