package com.foodorder.ecommerce;

import com.foodorder.ecommerce.entity.CustomerAuthority;
import com.foodorder.ecommerce.entity.CustomerRole;
import com.foodorder.ecommerce.repositories.CustomerAuthorityRepository;
import com.foodorder.ecommerce.repositories.CustomerRoleRepository;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Component
/**
 * Class to programmatically setup Customer Authority, Roles and default Admin User
 */
public class CustomerSetup
{
    private CustomerAuthority customerAuthority;
    private CustomerAuthorityRepository customerAuthorityRepository;
    private CustomerRoleRepository customerRoleRepository;

    private CustomerSetup(final CustomerAuthority customerAuthority, final CustomerAuthorityRepository customerAuthorityRepository, final CustomerRoleRepository customerRoleRepository)
    {
        this.customerAuthority = customerAuthority;
        this.customerAuthorityRepository = customerAuthorityRepository;
        this.customerRoleRepository = customerRoleRepository;
    }

    @EventListener
    public void startApp(ApplicationReadyEvent applicationReadyEvent)
    {

        CustomerAuthority readAuthority = createAuthority("READ_AUTHORITY");
        CustomerRole customerRole = createRole("ROLE_CUSTOMER", new HashSet<CustomerAuthority>(Arrays.asList(readAuthority)));
        CustomerRole guestRole = createRole("ROLE_GUEST", new HashSet<CustomerAuthority>(Arrays.asList(readAuthority)));
    }

    private CustomerAuthority createAuthority(String name)
    {
        //Make optional!
        CustomerAuthority customerAuthority = customerAuthorityRepository.findByName(name);
        if(customerAuthority == null)
            {
                customerAuthority = new CustomerAuthority(name);
                customerAuthorityRepository.save(customerAuthority);
            }
        return customerAuthority;
    }
    @Transactional
    CustomerRole createRole(String name, Set<CustomerAuthority> authoritySet)
    {
        //Make optional!
        CustomerRole customerRole = customerRoleRepository.findByName(name);
        if(customerRole == null)
            {
                customerRole = new CustomerRole(name);
                if(customerRole.getCustomerAuthorities() == null)
                    {

                        Set<CustomerAuthority> authorities = new HashSet<>();
                        authoritySet.forEach(auth -> authorities.add(auth));
                        customerRole.setAuthorities(authorities);
                    };
                customerRoleRepository.save(customerRole);
            }
        return customerRole;
    }
}
