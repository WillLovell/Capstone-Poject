package com.foodorder.ecommerce.serviceImpl;

import com.foodorder.ecommerce.entity.MenuCategory;
import com.foodorder.ecommerce.entity.MenuItem;
import com.foodorder.ecommerce.repositories.MenuCategoryRepository;
import com.foodorder.ecommerce.repositories.MenuItemRepository;
import com.foodorder.ecommerce.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
/**
 * Implementation of the MenuService interface.
 */
public class MenuServiceImpl implements MenuService
{
    private MenuItemRepository menuItemRepository;
    private MenuCategoryRepository menuCategoryRepository;
    @Autowired
    public MenuServiceImpl(MenuItemRepository menuItemRepository, MenuCategoryRepository menuCategoryRepository)
    {
        this.menuItemRepository = menuItemRepository;
        this.menuCategoryRepository = menuCategoryRepository;
    }


    @Override
    public List<MenuItem> getAllMenuItems()
    {
        List<MenuItem> menuItems = (List<MenuItem>) menuItemRepository.findAll();

        return menuItems;
    }
    @Override
    public MenuItem getMenuItem(final long id)
    {

        Optional<MenuItem> menuItemOptional = Optional.ofNullable(menuItemRepository.findById(id));
        if(menuItemOptional.isPresent())
            {
                return menuItemOptional.get();
            }
        throw new IllegalStateException("Menu Category not found");

    }

    @Override
    public MenuCategory getMenuCategoryItems(final long id)
    {
        Optional<MenuCategory> menuCategoryOptional = menuCategoryRepository.findById(id);

        if(menuCategoryOptional.isPresent())
            {
                return menuCategoryOptional.get();
            }
        throw new IllegalStateException("Menu Category not found");

    }


}
