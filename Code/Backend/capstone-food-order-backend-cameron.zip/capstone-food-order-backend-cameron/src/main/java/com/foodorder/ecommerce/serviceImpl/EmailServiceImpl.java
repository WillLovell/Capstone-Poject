package com.foodorder.ecommerce.serviceImpl;

import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.dto.spring.OrderDto;
import com.foodorder.ecommerce.entity.CustomerResetToken;
import com.foodorder.ecommerce.entity.CustomerVerifyToken;
import com.foodorder.ecommerce.entity.Order;
import com.foodorder.ecommerce.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
/**
 * Implementation of the EmailService interface.
 */
public class EmailServiceImpl implements EmailService
{
    private final JavaMailSender javaMailSender;

    @Autowired
    public EmailServiceImpl(final JavaMailSender javaMailSender)
    {
        this.javaMailSender = javaMailSender;
    }

    @Override
    public boolean sendConfirmationEmail(final CustomerDto customerDto, final CustomerVerifyToken customerVerifyToken)
    {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(customerDto.getEmail());
        message.setSubject("Complete Customer Registration!");
        message.setFrom("proj354.capstone@gmail.com");
        message.setText("To confirm your account, please click here : "
                +"http://localhost:8080/confirm?token="+customerVerifyToken.getToken());

        javaMailSender.send(message);
        return  true;
    }

    @Override
    public boolean sendReset(final CustomerDto customerDto, final CustomerResetToken customerResetToken)
    {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(customerDto.getEmail());
        message.setSubject("Customer Reset Request");
        message.setFrom("proj354.capstone@gmail.com");
        message.setText("To reset, please click the below. Else ignore. : "
                +"http://localhost:8080/reset?token="+customerResetToken.getToken());

        javaMailSender.send(message);
        return  true;
    }

    @Override
    public void sendOrderUpdateToCustomer(final OrderDto orderDto, final CustomerDto customerDto)
    {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(customerDto.getEmail());
        message.setSubject("Order Update");
        message.setFrom("proj354.capstone@gmail.com");
        Order.OrderStatus status = orderDto.getOrderStatus();
        switch(status)
            {
                case PENDING:
                {
                    message.setText("Thank you for placing you order.");
                }
                case CANCEL_REQUEST:
                {
                    message.setText("We have received you cancellation request. We will update you shortly ");
                }
                case CANCELLED:
                {
                    message.setText("We were able to cancel your order.");
                }
            }
        javaMailSender.send(message);
    }

    @Override
    public void sendOrderUpdateToStaff(final OrderDto orderDto)
    {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo("proj354.capstone@gmail.com"); //Staff email

        message.setFrom("proj354.capstone@gmail.com");
        Order.OrderStatus status = orderDto.getOrderStatus();
        switch(status)
            {
                case PENDING:
                {
                    message.setSubject("Customer - New Order Request");
                    message.setText("New Order received");
                }
                case CANCEL_REQUEST:
                {
                    message.setSubject("Customer -Cancel Order Request");
                    message.setText("Cancel Order Request. Please update status ");
                }
                case CANCELLED:
                {
                    message.setSubject("Automatic - Order Cancellation");
                    message.setText("System cancelled order " + orderDto.getId());
                }
            }
        javaMailSender.send(message);
    }
}
