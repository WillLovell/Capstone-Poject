package com.foodorder.ecommerce.serviceImpl;

import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.Order;
import com.foodorder.ecommerce.repositories.CustomerRepository;
import com.foodorder.ecommerce.repositories.OrderRepository;
import com.foodorder.ecommerce.service.CheckoutService;
import com.foodorder.ecommerce.service.CustomerService;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

/**
 * Implementation of the CheckoutService
 */
@Service
public class CheckoutServiceImpl implements CheckoutService
{

    private CustomerService customerService;
    private CustomerRepository customerRepository;
    private OrderRepository orderRepository;

    public CheckoutServiceImpl(CustomerService customerService,
                               CustomerRepository customerRepository,
                               OrderRepository orderRepository) {
        this.customerService = customerService;
        this.customerRepository = customerRepository;
        this.orderRepository = orderRepository;
    }

    /**
     * Method responsible for the persistence of the Customer, Order and items Ordered
     * @param customer Customer placing the order
     * @param order Order entity created
     * @return OrderResponseDto with relevant order details
     */
    @Transactional
    @Override
    public Order placeOrder(Customer customer, Order order)
    {
        order.setCustomer(customer);

//        customer.addOrder(order);

        Order createdOrder =  orderRepository.save(order);
        return order;

    }


}









