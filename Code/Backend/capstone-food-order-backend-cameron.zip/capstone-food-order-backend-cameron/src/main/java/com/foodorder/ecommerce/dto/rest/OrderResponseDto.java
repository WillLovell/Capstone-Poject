package com.foodorder.ecommerce.dto.rest;

import com.foodorder.ecommerce.dto.spring.OrderDto;
import com.foodorder.ecommerce.dto.spring.CustomerDto;
import lombok.Getter;

import java.io.Serializable;

/**
 * OrderResponseDto represents a Data Transfer Object (DTO) Class used to transfer data between Objects.
 */
@Getter
public class OrderResponseDto implements Serializable
{
    private final OrderDto order;
    private final CustomerDto customer;
    private final String created;
    private final String updated;


    public OrderResponseDto(final OrderDto order, final CustomerDto customer, final String created, final String updated)
    {
        this.order = order;
        this.customer = customer;
        this.created = created;
        this.updated = updated;
    }
}