package com.foodorder.ecommerce.service;


import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.entity.Order;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * Interface used for interaction with the Order repository
 */
@Service
public interface OrderService
{
    /**
     * Method to retrieve Orders for a given customer
     * @param customerDto customer's details
     * @return set of orders
     */
    Set<Order> getAllCustomerOrders(CustomerDto customerDto);

    /**
     * Method to retrieve Orders for a given order status
     * @param orderStatus status queried
     * @return set of orders
     */
    Set<Order> getOrdersByStatus(Order.OrderStatus orderStatus, CustomerDto customerDto);

    /**
     * Method to retrieve an Order
     * @param id of order to retrieve
     * @return queried Order
     */
    Order getOrderById(long id);

    /**
     * Method to request an order cancellation by a customer
     * @param customerDto customer requesting cancellation
     * @param orderId order to cancel
     * @return true on success
     */
    boolean processCancellation(CustomerDto customerDto, final long orderId);
}
