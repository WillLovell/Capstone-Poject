package com.foodorder.ecommerce.entity;

import com.foodorder.ecommerce.security.ConstantsUtil;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import javax.persistence.*;
import java.util.Date;
@Entity
/**
 * Token class used to generate a reset token for password reset of a User.
 */
public class CustomerVerifyToken
{
    @Id
    @GeneratedValue(generator="STAFF_VER_SEQ",strategy= GenerationType.SEQUENCE)
    @Column(name="id")
    private Long id;

    @Column(name="token")
    private String token;

    @OneToOne(targetEntity = Customer.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "user_id")
    private Customer customer;


    public CustomerVerifyToken(final Customer customer)
    {
        this.customer = customer;
        this.token = generateToken();
    }

    private String generateToken()
    {
        return Jwts.builder().setSubject(customer.getEmail())
                .setExpiration(new Date(System.currentTimeMillis() + ConstantsUtil.VERIFY_TOKEN_EXPIRE))
                .signWith(SignatureAlgorithm.HS256, ConstantsUtil.TOKEN_SECRET).compact();
    }

    public CustomerVerifyToken()
    {

    }

    public Long getId()
    {
        return id;
    }

    public String getToken()
    {
        return token;
    }

    public Customer getCustomer()
    {
        return customer;
    }
}
