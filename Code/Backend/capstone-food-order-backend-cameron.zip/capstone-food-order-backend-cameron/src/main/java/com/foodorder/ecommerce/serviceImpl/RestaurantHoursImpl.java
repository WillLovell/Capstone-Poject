package com.foodorder.ecommerce.serviceImpl;


import com.foodorder.ecommerce.entity.RestaurantHours;
import com.foodorder.ecommerce.repositories.RestaurantHoursRepository;
import com.foodorder.ecommerce.service.RestaurantHoursService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Time;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.Optional;

@Component
/**
 * Implementation of the RestaurantHours Service interface.
 */
public class RestaurantHoursImpl implements RestaurantHoursService
{

    private RestaurantHoursRepository restaurantHoursRepository;
    @Autowired
    private RestaurantHoursImpl(final RestaurantHoursRepository restaurantHoursRepository)
    {
        this.restaurantHoursRepository = restaurantHoursRepository;
    }


    @Override
    public boolean canPlaceOrder(final LocalDateTime date)
    {
        DayOfWeek dow = date.getDayOfWeek();
        Optional<RestaurantHours> restaurantHoursOptional = restaurantHoursRepository.findByDayOfWeek(dow);
        if(!restaurantHoursOptional.isPresent())
            {
                throw new IllegalStateException("No such day of week");
            }
        Time openTime = restaurantHoursOptional.get().getOpenTime();
        Time closeTime = restaurantHoursOptional.get().getCloseTime();
        Time orderTime = Time.valueOf(date.toLocalTime());

        if(orderTime.after(openTime) && orderTime.before(closeTime))
            {
                return  true;
            }
        return false;

    }



}
