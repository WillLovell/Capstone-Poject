package com.foodorder.ecommerce.security;

import com.foodorder.ecommerce.entity.CustomerRole;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
/**
 * Class extends default Spring User Class. JwtToken parsed into Principal Staff
 */
public class PrincipalCustomer extends User implements Serializable
{
    private final long id;
    private final boolean status;
    private static final long serialVersionUID = 7525404040889652725L;

    public PrincipalCustomer(final String username, final String password, final Collection<? extends GrantedAuthority> authorities, final long id, final boolean status)
    {
        super(username, password, authorities);
        this.id = id;
        this.status = status;
    }

    public long getId()
    {
        return id;
    }

    public Collection<GrantedAuthority> getAuthorities(CustomerRole role)
    {
        Set<GrantedAuthority> grantedAuthoritySet = new HashSet<>();


                grantedAuthoritySet.add(new SimpleGrantedAuthority(role.getName()));
                role.getCustomerAuthorities().stream().map(
                        auth -> new SimpleGrantedAuthority(auth.getName()))
                        .forEach(grantedAuthoritySet::add);
        return grantedAuthoritySet;
    }
    @Override
    public boolean isEnabled()
    {
        return status;
    }
}
