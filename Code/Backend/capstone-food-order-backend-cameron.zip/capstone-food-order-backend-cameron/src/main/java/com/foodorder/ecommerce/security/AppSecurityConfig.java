package com.foodorder.ecommerce.security;

import com.foodorder.ecommerce.repositories.CustomerRepository;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.stereotype.Component;


@Configuration
@EnableWebSecurity
/**
 * Web security configuration class
 */
public class AppSecurityConfig extends WebSecurityConfigurerAdapter
{

    private CustomerRepository customerRepository;

    private static final String[] AUTH_WHITELIST = {
            // -- Swagger UI v2
            "/v2/api-docs",
            "/swagger-resources",
            "/swagger-resources/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui.html",
            "/webjars/**",
            // -- Swagger UI v3 (OpenAPI)
            "/v3/api-docs/**",
            "/swagger-ui/**"
            // other public endpoints of your API may be appended to this array
    };

    public AppSecurityConfig(final CustomerRepository customerRepository)
    {
        this.customerRepository = customerRepository;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.cors().and().csrf().disable()
                .authorizeRequests()
                .antMatchers(HttpMethod.POST, ConstantsUtil.SING_UP_URL)
                .permitAll()
//                .antMatchers("/customers").permitAll()
                .antMatchers("/menu/**").permitAll()
                .antMatchers("/login/**").permitAll()
                .antMatchers("/confirm").permitAll()
                .antMatchers(AUTH_WHITELIST)
                .permitAll()
                .anyRequest().authenticated()
                .and()
                .addFilter(new CustomerJWTAuthFilter(authenticationManager()))
                .addFilter(new CustomerAuthorizationFilter(authenticationManager(), customerRepository))
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS);



    }

//    @Bean
//    @Override
//    public UserDetailsService userDetailsService() {
//        UserDetails user =
//                User.withDefaultPasswordEncoder()
//                        .username("user")
//                        .password("password")
//                        .roles("USER")
//                        .build();
//
//        return new InMemoryUserDetailsManager(user);
//    }

}
