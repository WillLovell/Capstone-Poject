package com.foodorder.ecommerce.repositories;

import com.foodorder.ecommerce.entity.MenuCategory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

/**
 * Extension of the CrudRepository used for the menu category
 */

public interface MenuCategoryRepository extends CrudRepository<MenuCategory, Long>
{
}
