package com.foodorder.ecommerce.controller;

import com.foodorder.ecommerce.dto.rest.*;
import com.foodorder.ecommerce.dto.spring.*;
import com.foodorder.ecommerce.entity.*;
import com.foodorder.ecommerce.security.ConstantsUtil;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.util.EnumUtils;

import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * ControllerUtils class used for Object conversion, to and from entities to their DTO
 * representations
 */
@Component
public class ControllerUtils
{
    final String PATTERN_RESPONSE = "yyyy-MM-dd HH:mm";
    final String PATTERN_REQUEST = "yyyy-MM-dd";
    /**
     * Convert a MenuItem to a MenuItemDto
     * @param menuItem to convert
     * @return DTO representation of a MenuItem
     */
    protected MenuItemDto convertToMenuItemDto(final MenuItem menuItem)
    {
        MenuItemDto menuItemDto = new MenuItemDto(
                menuItem.getId(),
                menuItem.getName(),
                menuItem.getPrice(),
                menuItem.getImageUrl(),
                menuItem.getDescription(),
                this.convertToMenuCategoryDto(menuItem.getCategory())
        );

        return menuItemDto;
    }



    /**
     * Convert a Menu Items contained in a given category to MenuItemDTO
     * @param menuCategory
     * @return menuCategoryDto with a Set of MenuitemDto's
     */
    protected MenuCategoryDto convertToMenuCategoryDto(final MenuCategory menuCategory)
    {

        MenuCategoryDto menuCategoryDto = new MenuCategoryDto(menuCategory.getId(), menuCategory.getName()
        );

        return menuCategoryDto;
    }
    /**
     * Create a DTO representing the Customer entity.
     * @param customer details
     * @return DTO representing the Customer
     */
        protected CustomerResponseDto convertCustomerToCustomerReponseDto(Customer customer)
        {
            CustomerResponseDto customerResponseDto = new CustomerResponseDto(customer.getFirstName(), customer.getEmail());
            return customerResponseDto;
        }
    /**
     * Create a DTO representing the Customer entity requested.
     * @param id of Customer entity
     * @return DTO representing the Customer
     */
        protected CustomerDto convertToCustomerDto(Long id)
        {
            CustomerDto customerDto = new CustomerDto(id);
            return customerDto;
        }


    /**
     * Customer submitted data via API for registration. The request body received as a CustomerRegistrationRequestDto
     * object is converted to a CustomerDto object for use internally.
     * @param customerRegistrationRequestDto
     * @return customerDto
     */
    protected CustomerDto convertCustomerRegRequestToCustomerDto(final CustomerRegistrationRequestDto customerRegistrationRequestDto)
    {
        CustomerDto customerDto = new CustomerDto(
               customerRegistrationRequestDto.getFirstName(),
                customerRegistrationRequestDto.getEmail(),
                customerRegistrationRequestDto.getPassword()
        );
        return customerDto;
    }



    /**
     * Convert order request received via POST request to a orderDto
     * @param orderRequestDto
     * @return
     */
    protected OrderDto convertToOrderDto(final OrderRequestDto orderRequestDto)
    {
        OrderDto orderDto = new OrderDto(
                orderRequestDto.getOrder().getTotalQuantity(),
                orderRequestDto.getOrder().getTotalPrice(),
                Order.OrderStatus.PENDING,
                orderRequestDto.getOrderItems()
        );
        return  orderDto;
    }


    /**
     * Convert OrderDto to an Order Entity
     * @param orderDto to converted
     * @return Order enity
     */
    protected Order convertOrderDtoToOrder(final OrderDto orderDto)
    {
        Set<OrderItem> orderItems = new HashSet<>();
        orderDto.getOrderItems().forEach(
                orderItemDto -> orderItems.add(
                        this.convertToOrderItem(orderItemDto)));

        Order newOrder = new Order(
                orderDto.getTotalQuantity(),
                orderDto.getTotalPrice(),
                orderDto.getOrderStatus(),
                orderItems
                );
        return newOrder;

    }
    /**
     * Convert OrderDto to an Order Entity
     * @param orderDto to converted
     * @return Order enity
     */
    protected Order convertOrderDtoToOrder(final OrderDto orderDto, Set<OrderItem> orderItems)
    {
        Order newOrder = new Order(
                orderDto.getTotalQuantity(),
                orderDto.getTotalPrice(),
                orderDto.getOrderStatus()
        );
        orderItems.forEach(newOrder::add);
        return newOrder;

    }

    /**
     * Converrt OrderitemDto to an OrderItem entity
     * @param orderItemDto to convert
     * @returnOrderItem
     */
    protected OrderItem convertToOrderItem(final OrderItemDto orderItemDto)
    {
        OrderItem orderItem = new OrderItem(
                orderItemDto.getItemPrice(),
                orderItemDto.getQuantity(),
                orderItemDto.getMenuItemId(),
                orderItemDto.getName()
        );
        return orderItem;
    }

    /**
     * Convert a Set of OrderItem entities to a Set of OrderItemDto
     * @param orderItemDtoSet to convert
     * @return Set of OrderItemDto's
     */
    protected Set<OrderItem> convertOrderItemsDtoToOrderItems(final Set<OrderItemDto> orderItemDtoSet)
    {

        Set<OrderItem> orderItems = orderItemDtoSet.stream().map(
                this::convertToOrderItem).collect(Collectors.toSet());

        return orderItems;
    }
    /**
     * Create a CustomerDto entity from a Staff update JSON request
     * @param customerUpdateRequestDto staff details to update
     * @return DTO representation of Staff
     */
    protected CustomerDto convertToCustomerDto(final CustomerUpdateRequestDto customerUpdateRequestDto)
    {
        CustomerDto customerDto = new CustomerDto(

                customerUpdateRequestDto.getEmail(),
                customerUpdateRequestDto.getFirstName(),
                customerUpdateRequestDto.getLastName()

        );
        return customerDto;
    }
    /**
     * Create a REST DTO representing an Order entity.
     * @param order order entity details to convert
     * @return REST DTO representing an Order entity
     */
    protected OrderResponseDto convertToOrderResponseDto(final Order order)
    {
        return new OrderResponseDto(
                this.convertToOrderDto(order),
                this.convertToCustomerDto(order),
        new SimpleDateFormat(PATTERN_RESPONSE).format(order.getDateCreated())
                ,new SimpleDateFormat(PATTERN_RESPONSE).format(order.getLastUpdated()));

    }
    /**
     * Create a DTO representing the Customer entity requested.
     * @param order containing customer details
     * @return DTO representing the Customer
     */
    private CustomerDto convertToCustomerDto(Order order)
    {
        CustomerDto customerDto = new CustomerDto(
                order.getCustomer().getId(),
                order.getCustomer().getEmail(),
                order.getCustomer().getFirstName(),
                order.getCustomer().getFirstName());

        return customerDto;
    }
    /**
     * Create a REST DTO representing an Order entity.
     * @param order order entity details to convert
     * @return REST DTO representing an Order entity
     */
    protected OrderDto convertToOrderDto(Order order)
    {
        Set<OrderItemDto> orderItemDtos = new HashSet<>();
        order.getOrderItems().forEach(
                orderItem -> orderItemDtos.add(new OrderItemDto(
                        orderItem.getItemPrice(),
                        orderItem.getQuantity(),
                        orderItem.getMenuItemId(),
                        orderItem.getName()))
        );

        OrderDto orderDto = new OrderDto(
                order.getId(), order.getTotalQuantity(),
                order.getTotalPrice(),
                order.getOrderStatus(),
                orderItemDtos
        );
        return orderDto;
    }

    /**
     * Create a DTO representing the Customer entity requested.
     * @param orderRequestDto order dto containing customer details
     * @return DTO representing the Customer
     */
    protected CustomerDto convertToCustomerDto(final OrderRequestDto orderRequestDto)
    {
        return new CustomerDto(orderRequestDto.getCustomer().getId());
    }
    /**
     * Create a DTO representing the Customer entity requested.
     * @param email of Customer entity
     * @return DTO representing the Customer
     */
    protected CustomerDto convertToCustomerDto(final String email)
    {
        return new CustomerDto(email);
    }
    /**
     * Create a DTO representing the Customer entity requested.
     * @param customer entity to convert
     * @return DTO representing the Customer
     */
    protected CustomerDto convertToCustomerDto(final Customer customer)
    {
        return new CustomerDto(customer.getEmail());
    }
    /**
     * Create DTO representing a Token Entity
     * @param tokenRequest string received from parameter
     * @return  DTO representing a Token Entity
     */
    protected TokenDto convertToTokenDto(final String tokenRequest)
    {
        TokenDto token = new TokenDto(tokenRequest);
        if (!verifyToken(token))
            {
                throw new IllegalStateException("Invalid Token");
            }
        return token;

    }

    private boolean verifyToken(final TokenDto tokenDto)
    {
        String username = Jwts.parser()
                .setSigningKey(ConstantsUtil.TOKEN_SECRET)
                .parseClaimsJws(tokenDto.getToken())
                .getBody()
                .getSubject();
        if (username == null)
            {
                throw new IllegalStateException("Invalid Token");
            }

        return true;
    }

    /**
     * Helper method to validate & return an Order Status
     * @param status string from query parameter representing an order status
     * @return
     */
    protected Order.OrderStatus convertToOrderStatus(final String status)
    {
        if(status.chars().allMatch(Character::isAlphabetic))
            {
                try
                    {
                        return EnumUtils.findEnumInsensitiveCase(Order.OrderStatus.class,status);
                    }
                catch (IllegalArgumentException exception)
                    {
                        throw new IllegalArgumentException("No such status");
                    }

            }
        throw new IllegalArgumentException("No such status");
    }
    /**
     * Convert Set of orders to a Set of OrderDto
     * @param orders
     * @return Set of OrderDto
     */
    protected Set<OrderResponseDto> convertToOrderResponseDto(final Set<Order> orders)
    {

        Set<OrderResponseDto> orderResponseDtoSet = new HashSet<>();

        orders.forEach(
                order ->
                        orderResponseDtoSet.add(
                                new OrderResponseDto(

                                        this.convertToOrderDto(order),
                                        this.convertToCustomerDto(order),
                                        new SimpleDateFormat(PATTERN_RESPONSE).format(order.getDateCreated())
                                        ,new SimpleDateFormat(PATTERN_RESPONSE).format(order.getLastUpdated()))
                        )
        );
        return orderResponseDtoSet;
    }


}
