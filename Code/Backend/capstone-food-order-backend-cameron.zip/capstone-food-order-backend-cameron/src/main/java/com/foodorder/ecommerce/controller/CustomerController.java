package com.foodorder.ecommerce.controller;


import com.foodorder.ecommerce.dto.rest.CustomerRegistrationRequestDto;
import com.foodorder.ecommerce.dto.rest.CustomerResponseDto;
import com.foodorder.ecommerce.dto.rest.CustomerUpdateRequestDto;
import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.CustomerVerifyToken;
import com.foodorder.ecommerce.security.ConstantsUtil;
import com.foodorder.ecommerce.security.PrincipalCustomer;
import com.foodorder.ecommerce.service.CustomerService;
import com.foodorder.ecommerce.service.CustomerTokenService;
import com.foodorder.ecommerce.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/customers")
@CrossOrigin(ConstantsUtil.UI_URL)
/**
 * Rest Controller responsible for the REST Api calls related to customer management.
 */
public class CustomerController
{
    private ControllerUtils controllerUtils;
    private CustomerService customerService;
    private EmailService emailService;
    private CustomerTokenService customerTokenService;

    @Autowired
    public CustomerController(ControllerUtils controllerUtils, CustomerService customerService, final EmailService emailService, final CustomerTokenService customerTokenService)
    {
        this.controllerUtils = controllerUtils;
        this.customerService = customerService;
        this.emailService = emailService;
        this.customerTokenService = customerTokenService;
    }

    /**
     * Method to create a new customer
     * @param customerRegistrationRequestDto new customer details
     * @return response with customer details
     */
    @PostMapping()
    public ResponseEntity<CustomerResponseDto> createCustomer(@RequestBody CustomerRegistrationRequestDto customerRegistrationRequestDto)
    {

        CustomerDto customerDto = controllerUtils.convertCustomerRegRequestToCustomerDto(customerRegistrationRequestDto);
        Customer customer = customerService.createCustomer(customerDto);
        if (customer != null)
            {
                CustomerDto customerDto1 = controllerUtils.convertToCustomerDto(customer);
                CustomerVerifyToken customerVerifyToken = customerTokenService.getVerificationToken(customerDto1);
                emailService.sendConfirmationEmail(customerDto1, customerVerifyToken);

            }
        CustomerResponseDto customerResponseDto = new CustomerResponseDto(customer.getFirstName(), customer.getEmail());
        return ResponseEntity.ok().body(customerResponseDto);
    }


    @PreAuthorize("hasRole('CUSTOMER')")
    @PutMapping("/update")
    public ResponseEntity<CustomerResponseDto> updateCustomer(@RequestBody CustomerUpdateRequestDto customerUpdateRequestDto)
    {

        PrincipalCustomer principalCustomer = ((PrincipalCustomer)SecurityContextHolder.getContext().getAuthentication().getPrincipal());
        if(customerUpdateRequestDto.getEmail() != principalCustomer.getUsername())
            {
                throw new IllegalArgumentException("Incorrect Customer");
            }
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(customerUpdateRequestDto);
        Customer customer = customerService.updateCustomer(customerDto);
        CustomerResponseDto customerResponseDto = new CustomerResponseDto(customer.getFirstName(), customer.getEmail());

        return ResponseEntity.ok().body(customerResponseDto);
    }
    @PreAuthorize("hasRole('CUSTOMER')")
    @DeleteMapping
    public String deactivateCustomer( )
    {
        try
            {
                PrincipalCustomer principalCustomer = ((PrincipalCustomer)SecurityContextHolder.getContext().getAuthentication().getPrincipal());
                System.out.println("customerDto" + principalCustomer.getId());

            }
            catch (Exception e)
                {
                    System.out.println("Error");
                }


//        CustomerDto customerDto = controllerUtils.convertToCustomerDto(id);

//        Customer customer = customerService.getCustomer(customerDto.getId());

        return "deactivate";
    }

}
