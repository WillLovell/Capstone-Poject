package com.foodorder.ecommerce.dto.spring;
/**
 * Data Transfer Object (DTO) Class used to transfer data between Spring Classes.
 * TokenDto represent a Token entity
 */
public class TokenDto
{
    private final String token;

    public TokenDto(final String token)
    {
        this.token = token;
    }

    public String getToken()
    {
        return token;
    }
}