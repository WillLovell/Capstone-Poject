package com.foodorder.ecommerce.dto.rest;
/**
 * Data Transfer Class used for REST Request for User Login
 */
public class CustomerLoginRequest
{
    private String username;
    private String password;

    public String getUsername()
    {
        return username;
    }


    public String getPassword()
    {
        return password;
    }

}
