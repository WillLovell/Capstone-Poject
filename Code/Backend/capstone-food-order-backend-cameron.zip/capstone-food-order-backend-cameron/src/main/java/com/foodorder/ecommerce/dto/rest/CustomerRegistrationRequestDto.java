package com.foodorder.ecommerce.dto.rest;
/**
 * Data Transfer Class used for REST Request to register a new User entity
 */
public class CustomerRegistrationRequestDto
{
    private String firstName;
    private String email;
    private String password;

    public String getFirstName()
    {
        return firstName;
    }

    public String getEmail()
    {
        return email;
    }

    public String getPassword()
    {
        return password;
    }
}
