package com.foodorder.ecommerce.controller;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.foodorder.ecommerce.dto.rest.CustomerResponseDto;
import com.foodorder.ecommerce.dto.rest.PasswordRequestDto;
import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.dto.spring.TokenDto;
import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.CustomerResetToken;
import com.foodorder.ecommerce.entity.CustomerVerifyToken;
import com.foodorder.ecommerce.security.ConstantsUtil;
import com.foodorder.ecommerce.service.CustomerService;
import com.foodorder.ecommerce.service.CustomerTokenService;
import com.foodorder.ecommerce.service.EmailService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@CrossOrigin(ConstantsUtil.UI_URL)
@RequestMapping("/login")
/**
 * The AccountTokenController controls REST Api end points for generating and validating account tokens
 * to and from users.
 */
public class AccountTokenController
{
    private ControllerUtils controllerUtils;
    private CustomerService customerService;
    private HttpServletResponse httpServletResponse;
    private CustomerTokenService customerTokenService;
    private EmailService emailService;

    public AccountTokenController(final ControllerUtils controllerUtils, final CustomerService customerService, final HttpServletResponse httpServletResponse, final CustomerTokenService customerTokenService, final EmailService emailService)
    {
        this.controllerUtils = controllerUtils;
        this.customerService = customerService;
        this.httpServletResponse = httpServletResponse;
        this.customerTokenService = customerTokenService;
        this.emailService = emailService;
    }
    /**
     * API endpoint for processing forgotten passwords. Email is received via JSON request
     * @param objectNode
     * @return String message confirming email sent, else exception thrown.
     */
    @PostMapping("/forgot-password")
    public ResponseEntity<Object> confirmAccount(@RequestBody ObjectNode objectNode)
    {
        String email = objectNode.get("email").asText();
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(email);
        Customer customer = customerService.getCustomerByEmail(email);
        CustomerDto customerDto1 = controllerUtils.convertToCustomerDto(customer);
        CustomerResetToken token = customerTokenService.generateResetToken(customerDto1);
        if(emailService.sendReset(customerDto1, token))
            {
                return ResponseEntity.ok().body("message: Email sent.");
            }
        throw new IllegalStateException("Unable to verify.");

    }

    /**
     * API endpoint for resetting password. New password and generated Token is received
     * @param passwordRequestDto password and generated Token
     * @return ResponseEntity with StaffResponseDto and Http 200, else exception thrown.
     * @throws IOException
     */
    @PostMapping("/reset-password")
    public ResponseEntity<CustomerResponseDto> processResetRequest(@RequestBody PasswordRequestDto passwordRequestDto) throws IOException
    {
        TokenDto tokenDto = controllerUtils.convertToTokenDto(passwordRequestDto.getToken());
        CustomerResetToken customerResetToken = customerTokenService.getResetToken(tokenDto);
        String email =  customerTokenService.getUserDetailsFromToken(tokenDto);
        Customer customer = customerService.getCustomerByEmail(email);
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(email);
        Customer updatedCustomer = customerService.resetPassword(customerDto, passwordRequestDto.getPassword());

        if(updatedCustomer != null)
            {
                customerTokenService.deleteResetToken(customerResetToken);
                CustomerResponseDto customerResponseDto = controllerUtils.convertCustomerToCustomerReponseDto(customer);
                return ResponseEntity.ok().body(customerResponseDto);
            }
        throw new IllegalStateException("Unable to process reset.");

    }
    /**
     * API endpoint for confirming created account with Token emailed to email address.
     * @param token verify token
     * @return ResponseEntity with StaffResponseDto and Http 200, else exception thrown.
     * @throws IOException
     */
    @GetMapping("/confirm-account")
    public ResponseEntity<CustomerResponseDto> resetRequest(@RequestParam String token) throws IOException
    {
        TokenDto tokenDto = controllerUtils.convertToTokenDto(token);
        CustomerVerifyToken customerVerifyToken = customerTokenService.getVerificationToken(tokenDto);
        String email =  customerTokenService.getUserDetailsFromToken(tokenDto);
        Customer customer = customerService.getCustomerByEmail(email);
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(customer);
        Customer updatedCustomer = customerService.confirmCustomer(customerDto);

        if(updatedCustomer != null)
            {
                customerTokenService.deleteVerifyToken(customerVerifyToken);
                CustomerResponseDto customerResponseDto = controllerUtils.convertCustomerToCustomerReponseDto(customer);
                return ResponseEntity.ok().body(customerResponseDto);
            }
        throw new IllegalStateException("Unable to verify.");

    }

}
