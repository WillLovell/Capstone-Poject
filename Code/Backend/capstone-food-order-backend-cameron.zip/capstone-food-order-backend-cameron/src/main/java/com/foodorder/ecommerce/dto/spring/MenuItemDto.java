package com.foodorder.ecommerce.dto.spring;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
/**
 * Data Transfer Object (DTO) Class used to transfer data between Obnjects.
 */
@Data
public class MenuItemDto implements Serializable
{
        private final Long id;
        private final String name;
        private final BigDecimal price;
        private final String  imageUrl;
        private final String description;
        private MenuCategoryDto menuCategory;


        public MenuItemDto(final Long id, final String name, final BigDecimal price, final String imageUrl, final String description, MenuCategoryDto menuCategory)
        {
            this.id = id;
            this.name = name;
            this.price = price;
            this.imageUrl = imageUrl;
            this.description = description;
            this.menuCategory = menuCategory;
        }

        public MenuItemDto(final Long id, final String name, final BigDecimal price, final String imageUrl, final String description)
        {
            this.id = id;
            this.name = name;
            this.price = price;
            this.imageUrl = imageUrl;
            this.description = description;
        }
}
