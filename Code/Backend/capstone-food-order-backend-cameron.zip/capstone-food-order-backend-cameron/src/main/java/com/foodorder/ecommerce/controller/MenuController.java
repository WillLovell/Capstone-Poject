package com.foodorder.ecommerce.controller;

import com.foodorder.ecommerce.dto.spring.MenuCategoryDto;
import com.foodorder.ecommerce.dto.spring.MenuItemDto;
import com.foodorder.ecommerce.entity.MenuCategory;
import com.foodorder.ecommerce.entity.MenuItem;
import com.foodorder.ecommerce.security.ConstantsUtil;
import com.foodorder.ecommerce.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(ConstantsUtil.UI_URL)
@RequestMapping("/menu")
/**
 * Rest Controller responsible for the REST Api calls related to the restaurant's menu items & menu categories. These
 * Api endpoints are unrestricted, and can be consumed by any service.
 */
public class MenuController
{
    private MenuService menuService;
    private ControllerUtils controllerUtils;

    @Autowired
    public MenuController(MenuService menuService, ControllerUtils controllerUtils)
    {
        this.menuService = menuService;
        this.controllerUtils = controllerUtils;
    }
    /**
     * Public Api endpoint method for querying the menu categories. Method will be
     * @param id menu category id queried
     * @return MenuCategoryDto Encapsulated Set of MenuItemDto's
     */
    @GetMapping("/menu/category/{id}")
    public MenuCategoryDto getMenuCategoryDto(@PathVariable final long id)
    {
        MenuCategory menuCategory = menuService.getMenuCategoryItems(id);
        MenuCategoryDto menuCategoryDto = controllerUtils.convertToMenuCategoryDto(menuCategory);
        return menuCategoryDto;
    }


    /**
     * Public Api endpoint method for querying a specific menu item.
     * @param id menu item queried
     * @return JSON representation of a menuItemDto
     */
    @GetMapping("/{id}")
    public ResponseEntity<MenuItemDto> getMenuItemDto(@PathVariable final long id)
    {
        MenuItem menuItem = menuService.getMenuItem(id);
        MenuItemDto menuItemDto = controllerUtils.convertToMenuItemDto(menuItem);
        return new ResponseEntity<MenuItemDto>(menuItemDto, HttpStatus.OK);
    }

    /**
     * Public Api endpoint to return all active menu items.
     * @return all actibe menu items
     */
    @GetMapping()
    public ResponseEntity<Set<MenuItemDto>> getMenu()
    {

        List<MenuItem> menuItems = menuService.getAllMenuItems();
        Set<MenuItemDto> menuItemDtos = menuItems.stream().map(
                controllerUtils::convertToMenuItemDto).collect(Collectors.toSet());
        return new ResponseEntity<Set<MenuItemDto>>(menuItemDtos, HttpStatus.OK);
    }

}

