package com.foodorder.ecommerce.dto.rest;

import com.foodorder.ecommerce.dto.spring.OrderDto;
import com.foodorder.ecommerce.dto.spring.OrderItemDto;
import com.foodorder.ecommerce.dto.spring.CustomerDto;
import lombok.Getter;

import java.util.Set;
/**
 * OrderRequestDto represents a Data Transfer Object (DTO) used to transfer data between Objects for
 * the Order, Customer and Order Item entities
 */
@Getter
public class OrderRequestDto {

    private CustomerDto customer;
    private OrderDto order;
    private Set<OrderItemDto> orderItems;

    public CustomerDto getCustomer()
    {
        return customer;
    }

    public OrderRequestDto(final CustomerDto customer, final OrderDto order, final Set<OrderItemDto> orderItems)
    {
        this.customer = customer;
        this.order = order;
        this.orderItems = orderItems;
    }
}
