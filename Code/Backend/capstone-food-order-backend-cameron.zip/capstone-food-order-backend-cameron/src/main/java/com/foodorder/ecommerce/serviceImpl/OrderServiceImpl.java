package com.foodorder.ecommerce.serviceImpl;

import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.Order;
import com.foodorder.ecommerce.repositories.CustomerRepository;
import com.foodorder.ecommerce.repositories.OrderRepository;
import com.foodorder.ecommerce.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Optional;
import java.util.Set;
@Component
/**
 * Implementation of the OrderService interface.
 */
public class OrderServiceImpl implements OrderService
{
    private OrderRepository orderRepository;
    private CustomerRepository customerRepository;
    @Autowired
    public OrderServiceImpl(final OrderRepository orderRepository, final CustomerRepository customerRepository)
    {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
    }
    @Override
    public Set<Order> getAllCustomerOrders(final CustomerDto customerDto)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerDto.getEmail());
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        Set<Order> orders = orderRepository.findAllByCustomer(customerCheck.get());
        return orders;
    }

    @Override
    public Set<Order> getOrdersByStatus(final Order.OrderStatus orderStatus, final CustomerDto customerDto)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerDto.getEmail());
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }

        Set<Order> orders = orderRepository.findAllByOrderStatusAndCustomer(orderStatus, customerCheck.get());
        return orders;
    }

    @Override
    public Order getOrderById(final long id)
    {
        Optional<Order> orderOptional = orderRepository.findById(id);
        if(!orderOptional.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect order details provided");
            }
        return orderOptional.get();
    }

    @Override
    public boolean processCancellation(final CustomerDto customerDto, final long orderId)
    {
        Optional<Customer> customerCheck = customerRepository.findById(customerDto.getId());
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }

        Customer customer = customerCheck.get();
        Optional<Order> orderOptional = orderRepository.findById(orderId);
        if(!orderOptional.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect order details provided");
            }
        Order order = orderOptional.get();

        if(order.getCustomer().equals(customer))
            {
                Instant orderDateTime = order.getDateCreated().toInstant();
                LocalDateTime orderLocalDateTime = LocalDateTime.ofInstant(orderDateTime, ZoneId.systemDefault());
                LocalDateTime now = LocalDateTime.from(LocalDateTime.now().atZone(ZoneId.systemDefault()));

;                if(order.getOrderStatus().compareTo(Order.OrderStatus.PENDING)==0)// CAN cancel
                    {
                        if(now.isBefore(orderLocalDateTime.plusMinutes(2)))
                            {
                                order.setOrderStatus(Order.OrderStatus.CANCELLED);
                                orderRepository.save(order);
                                //EMAIL CLIENT
                                return true;
                            }
                        order.setOrderStatus(Order.OrderStatus.CANCEL_REQUEST);
                        orderRepository.save(order);
                        //EMAIL CLIENT
                        return true;
                    }
                else
                {
                  throw new IllegalStateException("Unable to cancel order");
                }
            }
        throw new UsernameNotFoundException("Incorrect order details provided");

    }


}
