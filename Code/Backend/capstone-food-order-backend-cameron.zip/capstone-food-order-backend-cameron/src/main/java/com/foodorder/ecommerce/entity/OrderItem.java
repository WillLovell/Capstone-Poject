package com.foodorder.ecommerce.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

/**
 * Rest Controller responsible for the REST Api calls related to customers.
 */

@Entity
@Table(name="order_item")
@Getter
@Setter
public class OrderItem {

    public OrderItem()
    {}


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name="item_price")
    private BigDecimal itemPrice;

    @Column(name="quantity")
    private int quantity;

    @Column(name="name")
    private String name;

    @Column(name="menu_item_id")
    private Long menuItemId;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    public OrderItem(final BigDecimal itemPrice, final int quantity, final Long menuItemId, final String name)
    {

        this.itemPrice = itemPrice;
        this.quantity = quantity;
        this.menuItemId = menuItemId;
        this.name = name;
    }
}








