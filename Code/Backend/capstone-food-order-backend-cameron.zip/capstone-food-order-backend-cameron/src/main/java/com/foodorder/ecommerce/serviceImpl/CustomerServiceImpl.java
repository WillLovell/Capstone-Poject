package com.foodorder.ecommerce.serviceImpl;

import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.CustomerRole;
import com.foodorder.ecommerce.entity.CustomerVerifyToken;
import com.foodorder.ecommerce.repositories.CustomerRepository;
import com.foodorder.ecommerce.repositories.CustomerRoleRepository;
import com.foodorder.ecommerce.repositories.CustomerVerifyTokenRepository;
import com.foodorder.ecommerce.security.Encryption;
import com.foodorder.ecommerce.security.PrincipalCustomer;
import com.foodorder.ecommerce.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Implementation of the CustomerService interface.
 */
@Component
public class CustomerServiceImpl implements CustomerService
{
    private Encryption encryption;
    private CustomerRepository customerRepository;
    private CustomerRoleRepository customerRoleRepository;
    private final CustomerVerifyTokenRepository customerVerifyTokenRepository;
    private Customer customer;

    @Autowired
    private CustomerServiceImpl(final CustomerRepository customerRepository, final Encryption encryption, final CustomerRoleRepository customerRoleRepository, final CustomerVerifyTokenRepository customerVerifyTokenRepository)
    {
        this.customerRepository = customerRepository;
        this.encryption = encryption;
        this.customerRoleRepository = customerRoleRepository;

        this.customerVerifyTokenRepository = customerVerifyTokenRepository;
    }

    @Override
    public Customer getCustomer(final Long id)
    {
        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        System.out.println("Optional " + optionalCustomer);
        if(optionalCustomer.isPresent())
            {
                return optionalCustomer.get();
            }
        throw new IllegalStateException("No such Customer");
    }



    @Override
    public Customer createCustomer(final CustomerDto customerRegistrationRequest)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerRegistrationRequest.getEmail());

        if(customerCheck.isPresent())
            {
                throw new IllegalStateException("Customer already exists");
            }
        CustomerRole customerRole = customerRoleRepository.findByName("ROLE_CUSTOMER");

            Customer customer = new Customer(
                    customerRegistrationRequest.getFirstName(),
                    customerRegistrationRequest.getEmail(),
                    encryption.encode(customerRegistrationRequest.getPassword())
            );
        customer.setRole(customerRole);
        CustomerVerifyToken customerVerifyToken = new CustomerVerifyToken(customer);
        customerRepository.save(customer);
        customerVerifyTokenRepository.save(customerVerifyToken);
        return customer;
    }

    @Override
    public Customer updateCustomer(final CustomerDto customerUpdateRequest)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerUpdateRequest.getEmail());
        System.out.println("CUSTOMER IS " + customerCheck.toString());
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }

        customerRepository.updateCustomer(
                customerUpdateRequest.getFirstName(),
                customerUpdateRequest.getLastName(),
                customerUpdateRequest.getId());
        return customerRepository.findById(customerUpdateRequest.getId()).get();
    }

    @Override
    public Customer getCustomerByEmail(final String email)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(email);
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        return customerCheck.get();
    }

    @Override
    public Customer confirmCustomer(final CustomerDto customerDto)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerDto.getEmail());
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        Customer customer = customerCheck.get();
        customer.setAccountStatus(true);
        customerRepository.save(customer);
        return customer;
    }

    @Override
    public Customer resetPassword(final CustomerDto customerDto, final String password)
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(customerDto.getEmail());
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        customerCheck.get().setProtectedPassword(encryption.encode(password));
        customerRepository.save(customerCheck.get());
        return customerCheck.get();
    }

    @Override
    public UserDetails loadUserByUsername(final String email) throws UsernameNotFoundException
    {
        Optional<Customer> customerCheck = customerRepository.findByEmail(email);
        if(!customerCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        Customer customer = customerCheck.get();

        PrincipalCustomer principalCustomer = new PrincipalCustomer(customer.getEmail(), customer.getProtectedPassword(), customer.getGrantedAuthorities(), customer.getId(), customer.isAccountActivated());
        return principalCustomer;
    }
}
