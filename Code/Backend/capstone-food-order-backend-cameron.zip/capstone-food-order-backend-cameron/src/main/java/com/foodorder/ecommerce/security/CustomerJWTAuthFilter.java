package com.foodorder.ecommerce.security;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.foodorder.ecommerce.dto.rest.CustomerLoginRequest;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
/**
 * Custom JWT Authentication Filter to used to login user
 */
public class CustomerJWTAuthFilter extends UsernamePasswordAuthenticationFilter
{

    private final AuthenticationManager authenticationManager;

    public CustomerJWTAuthFilter(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
        this.setFilterProcessesUrl("/login");
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request,
                                                HttpServletResponse response) throws AuthenticationException
    {
        try {

            CustomerLoginRequest creds = new ObjectMapper()
                    .readValue(request.getInputStream(), CustomerLoginRequest.class);

            return authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            creds.getUsername(),
                            creds.getPassword(),
                            new ArrayList<>())
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request,
                                            HttpServletResponse response,
                                            FilterChain chain,
                                            Authentication auth) throws IOException {
        
        String username = ((PrincipalCustomer) auth.getPrincipal()).getUsername();
        System.out.println(username);

        String token = Jwts.builder()
                .setSubject(username)
                        .setExpiration(new Date(System.currentTimeMillis() + ConstantsUtil.LOGIN_EXPIRATION_TIME))
                                .signWith(SignatureAlgorithm.HS512, ConstantsUtil.TOKEN_SECRET).compact();

//        String body = ((User) auth.getPrincipal()).getUsername() + " " + token;
        response.addHeader(ConstantsUtil.HEADER_STR, ConstantsUtil.TOKEN_PREFIX + token);

    }
}