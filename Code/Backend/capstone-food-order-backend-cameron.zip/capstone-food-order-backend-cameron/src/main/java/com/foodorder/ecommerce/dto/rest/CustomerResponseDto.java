package com.foodorder.ecommerce.dto.rest;
/**
 * Data Transfer Class used for REST Response to represent Staff entity
 */
public class CustomerResponseDto
{
    private String firstName;
    private String email;

    public CustomerResponseDto(final String firstName, final String email)
    {
        this.firstName = firstName;
        this.email = email;
    }

    public String getFirstName()
    {
        return firstName;
    }
    public String getEmail()
    {
        return email;
    }
}
