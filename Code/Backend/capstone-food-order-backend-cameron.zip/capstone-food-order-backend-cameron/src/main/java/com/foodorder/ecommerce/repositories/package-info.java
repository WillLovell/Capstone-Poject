/**
 * Houses extended JPA repository interfaces for entity classes
 */
package com.foodorder.ecommerce.repositories;