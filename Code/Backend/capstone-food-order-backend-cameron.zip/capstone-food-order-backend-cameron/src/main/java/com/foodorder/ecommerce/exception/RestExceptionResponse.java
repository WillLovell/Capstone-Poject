package com.foodorder.ecommerce.exception;

import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * Global Exception Response Handler to RestControllers for response to users.
 */
public final class RestExceptionResponse
{
    final static String PATTERN = "yyyy-MM-dd HH:mm";
    private String message;
    private Date date;

    public RestExceptionResponse(final String message, final Date date)
    {
        this.message = message;
        this.date = date;
    }

    public String getMessage() {
        return message;
    }

    public String getDateTime() {
        return new SimpleDateFormat(PATTERN).format(date);
    }

}

