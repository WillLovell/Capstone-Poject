/**
 * Data Transfer Object Classes used for REST request, response
 */
package com.foodorder.ecommerce.dto.rest;