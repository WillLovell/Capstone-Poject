package com.foodorder.ecommerce.service;

import com.foodorder.ecommerce.entity.MenuCategory;
import com.foodorder.ecommerce.entity.MenuItem;
import org.springframework.stereotype.Service;

import java.util.List;
/**
 * MenuService used for the retrieval of Menu Items and their categories
 */
@Service
public interface MenuService
{
    /**
     * Retrieve all active menu items
     * @return list of all active menu items
     */
    List<MenuItem> getAllMenuItems();

    /**
     * Retrieve specific menu item
     * @param id of menu item to retrieve
     * @return requested menu Item
     */
    MenuItem getMenuItem(long id);

    /**
     * Retrieve all menu items for a given menu category
     * @param id requested menu category
     * @return List of Menu Items for given Menu Category
     */
    MenuCategory getMenuCategoryItems(final long id);
}
