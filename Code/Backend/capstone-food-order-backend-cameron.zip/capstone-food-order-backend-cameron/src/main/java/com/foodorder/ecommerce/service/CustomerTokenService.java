package com.foodorder.ecommerce.service;


import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.dto.spring.TokenDto;
import com.foodorder.ecommerce.entity.CustomerResetToken;
import com.foodorder.ecommerce.entity.CustomerVerifyToken;
/**
 * Interface used for interaction with the StaffToken repository
 */
public interface CustomerTokenService
{
    /**
     * Retrieve verification token for a user
     * @param customerDto
     *user to retrieve token for
     * @return token
     */
    CustomerVerifyToken getVerificationToken(CustomerDto customerDto);

    /**
     * Check if token received as input is in database
     * @param tokenDto input token
     * @return token
     */
    CustomerVerifyToken getVerificationToken(TokenDto tokenDto);

    /**
     * Delete verification token
     * @param staffVerifyToken token to delete
     * @return true on success
     */
    boolean deleteVerifyToken(CustomerVerifyToken staffVerifyToken);

    /**
     * Generate forgot password token
     * @param customerDto user to generate token for
     * @return reset token
     */
    CustomerResetToken generateResetToken(CustomerDto customerDto);

    /**
     * Retrieve forgot password token from db
     * @param tokenDto queried token
     * @return reset token
     */
    CustomerResetToken getResetToken(TokenDto tokenDto);


    /**
     * Retrieve forgot password token from db
     * @param staffResetToken queried token
     * @return reset token
     */
    boolean deleteResetToken(CustomerResetToken staffResetToken);

    /**
     * Parse token to retrieve user details
     * @param tokenDto to parse
     * @return username
     */
    String getUserDetailsFromToken(TokenDto tokenDto);


}
