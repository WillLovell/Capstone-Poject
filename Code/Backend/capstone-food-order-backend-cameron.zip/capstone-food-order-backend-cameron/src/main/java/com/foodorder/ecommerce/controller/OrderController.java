package com.foodorder.ecommerce.controller;

import com.foodorder.ecommerce.dto.rest.OrderCancelRequest;
import com.foodorder.ecommerce.dto.spring.OrderDto;
import com.foodorder.ecommerce.dto.rest.OrderRequestDto;
import com.foodorder.ecommerce.dto.rest.OrderResponseDto;
import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.entity.Customer;
import com.foodorder.ecommerce.entity.Order;
import com.foodorder.ecommerce.entity.OrderItem;
import com.foodorder.ecommerce.security.ConstantsUtil;
import com.foodorder.ecommerce.security.PrincipalCustomer;
import com.foodorder.ecommerce.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.yaml.snakeyaml.util.EnumUtils;

import java.time.LocalDateTime;
import java.util.Set;

/**
 * Checkout controller Class is responsible for handling Api requests for managing
 * orders.
 */
@CrossOrigin(ConstantsUtil.UI_URL)
@RestController
@RequestMapping("/account")
public class OrderController
{

    private CheckoutService checkoutService;
    private CustomerService customerService;
    private ControllerUtils controllerUtils;
    private RestaurantHoursService restaurantHoursService;
    private  OrderService orderService;
    private EmailService emailService;

    @Autowired
    public OrderController(CheckoutService checkoutService,
                           CustomerService customerService,
                           ControllerUtils controllerUtils, final RestaurantHoursService restaurantHoursService, final OrderService orderService, final EmailService emailService) {
        this.checkoutService = checkoutService;
        this.controllerUtils = controllerUtils;
        this.customerService = customerService;
        this.restaurantHoursService = restaurantHoursService;
        this.orderService = orderService;
        this.emailService = emailService;
    }

    /**
     * The placeOrder method accepts a JSON request in the form of OrderRequestDto via a POST Request.
     * The Request is transformed and an OrderResponseDto i sent back to the caller.
     * @param orderRequestDto containing client, and order information.
     * @return OrderResponseDto containing the order information
     */
    @PostMapping("/checkout")
    public OrderResponseDto placeOrder(@RequestBody OrderRequestDto orderRequestDto) {
        verifyCustomer(orderRequestDto.getCustomer().getId());
        CustomerDto customerDto =  controllerUtils.convertToCustomerDto(orderRequestDto);
        OrderDto orderDto = controllerUtils.convertToOrderDto(orderRequestDto);
        Customer customer = customerService.getCustomer(customerDto.getId());
        Set<OrderItem> orderItems = controllerUtils.convertOrderItemsDtoToOrderItems(orderDto.getOrderItems());
        Order orderToCreate = controllerUtils.convertOrderDtoToOrder(orderDto, orderItems);
        Order createdOrder = checkoutService.placeOrder(customer, orderToCreate);
        if(createdOrder != null)
            {

                if(customer.getOrders().contains(createdOrder))
                    {
                        CustomerDto customerDto1 = controllerUtils.convertToCustomerDto(createdOrder.getCustomer());
                        emailService.sendOrderUpdateToCustomer(orderDto, customerDto1);
                        emailService.sendOrderUpdateToStaff(orderDto);
                    }

            }
        OrderResponseDto orderResponseDto = controllerUtils.convertToOrderResponseDto(createdOrder);

        return orderResponseDto;
    }

    /**
     * Returns boolean if client can place order based on kitchen closing time
     * @return
     */
    @GetMapping("/can-place")
    public boolean canPlace()
    {
        return  restaurantHoursService.canPlaceOrder(LocalDateTime.now().plusMinutes(15));
    }

    /**
     * Dynamic search method, enables to search for orders by customer based on date, status
     * @param id customer id
     * @param criteria all or status
     * @param status specific status
     * @return search result of orders
     */
    @GetMapping("/{id}/search/{criteria}")
    public ResponseEntity<Set<OrderResponseDto>> getOrderHistory(@PathVariable final long id, @PathVariable final String criteria, @RequestParam(name="name", required = false) String status)
    {
        verifyCustomer(id);
        Set<Order> orders;
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(id);
            switch (criteria)
                {
                    case "all":
                    {
                        orders = orderService.getAllCustomerOrders(customerDto);
                        break;
                    }
                    case "status":
                    {
                        Order.OrderStatus orderStatus = controllerUtils.convertToOrderStatus(status);
                        orders = orderService.getOrdersByStatus(EnumUtils.findEnumInsensitiveCase(Order.OrderStatus.class, status), customerDto);
                        break;
                    }
                    default:
                        throw new IllegalArgumentException("Invalid input");

                }
        if(orders == null)
            {
                throw new IllegalArgumentException("Invalid input");
            }
        Set<OrderResponseDto>  orderResponseDtos = controllerUtils.convertToOrderResponseDto(orders);
        return new ResponseEntity<Set<OrderResponseDto>>(orderResponseDtos, HttpStatus.OK);

    }

    /**
     * Methos for customer to request to cancel order
     * @param id customer id
     * @param orderCancelRequest order canceling
     * @return
     */
    @PostMapping("/{id}/cancel-order")
    public ResponseEntity<OrderResponseDto> cancelOrder(@PathVariable final long id, @RequestBody OrderCancelRequest orderCancelRequest)
    {
        verifyCustomer(id);
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(id);
        boolean result = orderService.processCancellation(customerDto, orderCancelRequest.getOrderId());
        if(result)
            {
                Order order = orderService.getOrderById(orderCancelRequest.getOrderId());
                if(order != null)
                    {
                        Customer customer = order.getCustomer();
                        if(customer.getOrders().contains(order))
                            {
                                CustomerDto customerDto1 = controllerUtils.convertToCustomerDto(order.getCustomer());
                                OrderDto orderDto = controllerUtils.convertToOrderDto(order);
                                emailService.sendOrderUpdateToCustomer(orderDto, customerDto1);
                                emailService.sendOrderUpdateToStaff(orderDto);
                            }
                    }
                OrderResponseDto orderResponseDto = controllerUtils.convertToOrderResponseDto(order);
                return new ResponseEntity<OrderResponseDto>(orderResponseDto, HttpStatus.OK);
            };
        throw new IllegalStateException("Error occured");


    }

    /**
     * Helper method to verify customer
     * @param id
     */
    private void verifyCustomer(final long id)
    {
        try
            {
                Customer customer = customerService.getCustomer(id);
                PrincipalCustomer principalCustomer = ((PrincipalCustomer) SecurityContextHolder.getContext().getAuthentication().getPrincipal());
                if(customer.getId()!= principalCustomer.getId())
                    {
                        throw new IllegalStateException("Incorrect Details");
                    }

            }
        catch (Exception e)
            {
                System.out.println("Error");
            }
    }


}









