/**
 * The entity package holds all entity classes persisted to the database
 */
package com.foodorder.ecommerce.entity;