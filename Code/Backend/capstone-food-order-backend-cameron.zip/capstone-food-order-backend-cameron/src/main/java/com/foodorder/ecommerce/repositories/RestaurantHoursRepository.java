package com.foodorder.ecommerce.repositories;

import com.foodorder.ecommerce.entity.RestaurantHours;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.DayOfWeek;
import java.util.Optional;

@Repository
/**
 * Extension of the CrudRepository used for the persistence of an Order entity
 */
public interface RestaurantHoursRepository extends CrudRepository<RestaurantHours, Long>
{

    Optional<RestaurantHours> findByDayOfWeek(final DayOfWeek dayOfWeek);
}
