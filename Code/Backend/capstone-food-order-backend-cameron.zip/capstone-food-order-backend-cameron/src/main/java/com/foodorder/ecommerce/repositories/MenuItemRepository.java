package com.foodorder.ecommerce.repositories;

import com.foodorder.ecommerce.entity.MenuItem;
import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
/**
 * Extension of the CrudRepository used for the persistence of the menu item entity
 */
@CrossOrigin("http://localhost:4200")
public interface MenuItemRepository extends CrudRepository<MenuItem, Long>
{
    MenuItem findById(long id);
}
