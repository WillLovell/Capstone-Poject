package com.foodorder.ecommerce.entity;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="orders")
@Getter
@Setter
/**
 * Order Entity, containing a reference to the menu items ordered as well as the customer
 * that placed the order
 */
public class Order {

    public enum OrderStatus
    {
        PENDING,
        DECLINED,
        CANCEL_REQUEST,
        CANCELLED,
        CONFIRMED,
        IN_PROGRESS,
        COMPLETED,
        COLLECTED
    }


    public Order(final int totalQuantity, final BigDecimal totalPrice, final OrderStatus orderStatus)
    {
        this.totalQuantity = totalQuantity;
        this.totalPrice = totalPrice;
        this.orderStatus = orderStatus;
    }

    public Order(final int totalQuantity, final BigDecimal totalPrice, final OrderStatus orderStatus, final Set<OrderItem> orderItems)
    {
        this.totalQuantity = totalQuantity;
        this.totalPrice = totalPrice;
        this.orderStatus = orderStatus;
        this.orderItems = orderItems;
    }

    public Order(){

    }

    @Id
    @SequenceGenerator(name = "ORDER_SEQ", sequenceName = "ORDER_SEQ", initialValue = 10)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name="total_quantity")
    private int totalQuantity;

    @Column(name="total_price")
    private BigDecimal totalPrice;

    @Column(name="status")
    @Enumerated(EnumType.STRING)
    private OrderStatus orderStatus;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="date_created")
    @CreationTimestamp
    private Date dateCreated;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="last_updated")
    @UpdateTimestamp
    private Date lastUpdated;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "order")
    private Set<OrderItem> orderItems = new HashSet<>();

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;


    /**
     * Helper method to add the order items to the Order
     * @param item
     */
    public void add(OrderItem item) {

        if (item != null) {
            if (orderItems == null) {
                orderItems = new HashSet<>();
            }
            orderItems.add(item);
            item.setOrder(this);
        }
    }

    public Set<OrderItem> getOrderItems()
    {
        return orderItems;
    }
}








