/**
 * Data Transfer Object Classes used for internal transfer of data
 */
package com.foodorder.ecommerce.dto.spring;