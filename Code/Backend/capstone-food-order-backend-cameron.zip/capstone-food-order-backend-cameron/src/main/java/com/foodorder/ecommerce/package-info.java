/**
 * Main package for content management system.
 */
package com.foodorder.ecommerce;