package com.foodorder.ecommerce.service;

import com.foodorder.ecommerce.dto.spring.CustomerDto;
import com.foodorder.ecommerce.dto.spring.OrderDto;
import com.foodorder.ecommerce.entity.CustomerResetToken;
import com.foodorder.ecommerce.entity.CustomerVerifyToken;
import org.springframework.stereotype.Service;

/**
 * Interface used for sending emails
 */

@Service
public interface EmailService
{
    /**
     * Method to send confirmation email to user on registration
     * @param customerDto user info
     * @param customerVerifyToken verification token value
     * @return true if successful.
     */
    boolean sendConfirmationEmail(final CustomerDto customerDto, final CustomerVerifyToken customerVerifyToken);

    /**
     * Method to send confirmation email to user on registration
     * @param customerDto user info
     * @param customerResetToken reset token value
     * @return true if successful.
     */
    boolean sendReset(final CustomerDto customerDto, final CustomerResetToken customerResetToken);

    /**
     * Method to send order update email to user
     * @param orderDto order information
     * @param customerDto customer information
     */
    void sendOrderUpdateToCustomer(final OrderDto orderDto, final CustomerDto customerDto);

    /**
     * Method to send order update email to staff
     * @param orderDto order information
     */
    void sendOrderUpdateToStaff(final OrderDto orderDto);

}
