package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.Customer;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Extension of the JpaRepository used for the persistence of the Customer entity
 */
@Repository
public interface CustomerRepository extends CrudRepository<Customer, Long>
{
    Optional<Customer> findByEmail(String email);
    @Transactional
    @Modifying
    @Query("update Customer u set u.firstName = ?1, u.lastName = ?2 where u.id = ?3")
    void updateCustomer(String firstName, String lastName, long userId);
}
