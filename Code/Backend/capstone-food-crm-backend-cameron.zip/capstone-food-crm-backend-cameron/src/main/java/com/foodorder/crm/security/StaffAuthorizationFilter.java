package com.foodorder.crm.security;

import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.repositories.StaffRepository;
import io.jsonwebtoken.Jwts;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Custom JWT AuthorizationFilter to Authorize request to API End points
 */
public class StaffAuthorizationFilter extends BasicAuthenticationFilter
{

    private StaffRepository staffRepository;
    public StaffAuthorizationFilter(final AuthenticationManager authenticationManager, StaffRepository staffRepository)
    {
        super(authenticationManager);
        this.staffRepository = staffRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                            HttpServletResponse response,
                            FilterChain chain
                            ) throws IOException, ServletException
    {
        String header = request.getHeader(ConstantsUtil.HEADER_STR);
        if(header == null || !header.startsWith(ConstantsUtil.TOKEN_PREFIX))
            {
                chain.doFilter(request, response);
                return;
            }
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = getAuthentication(request);
        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
        chain.doFilter(request, response);
    }

    private UsernamePasswordAuthenticationToken getAuthentication(final HttpServletRequest request)
    {
        String token = request.getHeader(ConstantsUtil.HEADER_STR);

        if(token != null)
            {


                token = token.replace(ConstantsUtil.TOKEN_PREFIX, "");

                String staff = Jwts.parser()
                        .setSigningKey(ConstantsUtil.TOKEN_SECRET)
                        .parseClaimsJws(token)
                        .getBody()
                        .getSubject();

                if (staff != null)
                    {
                        Staff staffInfo = staffRepository.findStaffByEmail(staff).get();
                        PrincipalStaff principalStaff = new PrincipalStaff(staffInfo.getEmail(), staffInfo.getProtectedPassword(), staffInfo.getGrantedAuthorities(), staffInfo.getId(), staffInfo.isStatus());
                        return new UsernamePasswordAuthenticationToken(principalStaff, null, principalStaff.getAuthorities(staffInfo.getRole()));
                    }
                return null;
            }
        return null;

    }
}
