package com.foodorder.crm.dto.rest;
import java.math.BigDecimal;
/**
 * Data Transfer Class used for REST Request
 */
public class MenuItemRequestDto
{
    private String name;
    private BigDecimal price;
    private String  imageUrl;
    private String description;
    private long menuCategoryId;
    private boolean status;

    public MenuItemRequestDto(final String name, final BigDecimal price, final String imageUrl, final String description, final long menuCategoryId, final boolean status)
    {
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
        this.menuCategoryId = menuCategoryId;
        this.status = status;
    }


//    public MenuItemRequestDto(final String name, final BigDecimal price, final String imageUrl, final String description, final long menuCategoryId)
//    {
//        this.name = name;
//        this.price = price;
//        this.imageUrl = imageUrl;
//        this.description = description;
//        this.menuCategoryId = menuCategoryId;
//        this.status = true;
//    }

    public String getName()
    {
        return name;
    }

    public BigDecimal getPrice()
    {
        return price;
    }

    public String getImageUrl()
    {
        return imageUrl;
    }

    public String getDescription()
    {
        return description;
    }


    public long getMenuCategoryId()
    {
        return menuCategoryId;
    }

    public boolean isStatus()
    {
        return status;
    }
}
