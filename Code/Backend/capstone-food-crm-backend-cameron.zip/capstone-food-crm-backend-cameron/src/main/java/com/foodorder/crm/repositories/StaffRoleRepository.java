package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.StaffRole;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/**
 * Extension of the CrudRepository used for the persistence of a StaffRole entity
 */
@Repository
public interface StaffRoleRepository extends CrudRepository<StaffRole, Long>
{
    StaffRole findByName (String name);

}
