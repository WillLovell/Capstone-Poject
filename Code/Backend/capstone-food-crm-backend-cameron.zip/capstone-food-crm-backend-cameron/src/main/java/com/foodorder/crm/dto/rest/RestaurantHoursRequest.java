package com.foodorder.crm.dto.rest;

import lombok.Getter;

import java.time.LocalDateTime;
@Getter
/**
 * Data Transfer Class used for REST Request representing RestaurantHours entity
 */
public class RestaurantHoursRequest
{
    private int dayOfWeek;
    private String open;
    private String close;

    public RestaurantHoursRequest(final int dayOfWeek, final String open, final String close)
    {
        this.dayOfWeek = dayOfWeek;
        this.open = open;
        this.close = close;
    }
}
