package com.foodorder.crm.entity;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * The MenuItem entity class used to reflect the menu items tht will be displayed on the menu page
 */

@Entity
@Table(name="menu_item")
@Data
public class MenuItem
{

    @Id
    @SequenceGenerator(name = "MENU_ITEM_SEQ", sequenceName = "MENU_ITEM_SEQ", allocationSize = 5, initialValue = 10)
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private MenuCategory category;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "price")
    private BigDecimal price;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "active")
    private boolean active;

    @Column(name = "date_created")
    @CreationTimestamp
    private Date dateCreated;

    @Column(name = "last_updated")
    @UpdateTimestamp
    private Date lastUpdated;

    public MenuItem(final String name, final String description, final BigDecimal price, final String imageUrl, final MenuCategory category)
    {
        this.category = category;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageUrl = imageUrl;
        this.active = true;
    }


    public MenuItem()
    {

    }
}
