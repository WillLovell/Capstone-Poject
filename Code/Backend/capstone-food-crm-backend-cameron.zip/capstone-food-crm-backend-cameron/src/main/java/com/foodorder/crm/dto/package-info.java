/**
 * Data Transfer Object Classes used for REST request, response and internal data transfer objects
 */
package com.foodorder.crm.dto;