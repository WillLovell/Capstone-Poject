package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.Customer;
import com.foodorder.crm.entity.Order;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Optional;
import java.util.Set;
/**
 * Extension of the CrudRepository used for the persistence of an Order entity
 */
@Repository
public interface OrderRepository extends CrudRepository<Order, Long>
{
    Optional<Set<Order>> findOrderByOrderStatus(final Order.OrderStatus orderStatus);
    Optional<Set<Order>> findOrderByCustomer(final Customer customer);
    Set<Order> findOrdersByCustomer_Id(final Long customer_id);
    Set<Order> findOrdersByDateCreatedIsLike(final Date dateCreated);
    Set<Order> findByDateCreatedBetween(final Date start, final Date end);
    Optional<Order> findOrderById(final Long id);
}
