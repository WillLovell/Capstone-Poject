package com.foodorder.crm.dto.spring;

import java.io.Serializable;
/**
 * Data Transfer Object (DTO) Class used to transfer data between Objects.
 * MenuCategory represent a Set of MenuItemDtos
 */

public class MenuCategoryDto implements Serializable
{
    private Long id;
    private String name;

    public MenuCategoryDto(final Long id, final String name)
    {
        this.id = id;
        this.name = name;
    }

    public Long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }
}
