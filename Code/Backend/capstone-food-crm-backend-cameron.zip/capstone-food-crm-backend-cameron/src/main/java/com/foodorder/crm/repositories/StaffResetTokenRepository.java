package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffResetToken;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/**
 * Extension of the CrudRepository used for the persistence of a StaffResetToken entity
 */
@Repository
public interface StaffResetTokenRepository extends CrudRepository<StaffResetToken, Long>
{
    StaffResetToken findByToken(final String token);
    StaffResetToken findByStaff(final Staff staff);
}
