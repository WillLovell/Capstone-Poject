package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.RestaurantHours;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.DayOfWeek;
import java.util.Optional;
/**
 * Extension of the CrudRepository used for the persistence of an Order entity
 */
@Repository
public interface RestaurantHoursRepository extends CrudRepository<RestaurantHours, Long>
{

    Optional<RestaurantHours> findByDayOfWeek(final DayOfWeek dayOfWeek);
}
