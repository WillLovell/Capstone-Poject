package com.foodorder.crm.dto.rest;

import com.foodorder.crm.dto.spring.CustomerDto;
import lombok.Getter;

import java.io.Serializable;
import java.util.Date;

/**
 * Data Transfer Class used for REST Response for Order entities
 */
@Getter
public class OrderResponseDto implements Serializable
{
    private final OrderDto order;
    private final CustomerDto customer;
    private final String created;
    private final String updated;

    public OrderResponseDto(final OrderDto order, final CustomerDto customer, final String created, final String updated)
    {
        this.order = order;
        this.customer = customer;
        this.created = created;
        this.updated = updated;
    }
}
