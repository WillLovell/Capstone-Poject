package com.foodorder.crm.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Encryption class used to hash password
 */
@Component
public class Encryption extends BCryptPasswordEncoder
{

}
