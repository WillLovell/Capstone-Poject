package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.StaffAuthority;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/**
 * Extension of the CrudRepository used for the persistence of a StaffAuthority entity
 */
@Repository
public interface StaffAuthorityRepository extends CrudRepository<StaffAuthority, Long>
{
    StaffAuthority findByName (String name);
}
