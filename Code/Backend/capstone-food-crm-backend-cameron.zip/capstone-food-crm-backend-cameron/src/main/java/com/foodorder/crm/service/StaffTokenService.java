package com.foodorder.crm.service;

import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.dto.spring.TokenDto;
import com.foodorder.crm.entity.StaffResetToken;
import com.foodorder.crm.entity.StaffVerifyToken;
/**
 * Interface used for interaction with the StaffToken repository
 */
public interface StaffTokenService
{
    /**
     * Retrieve verification token for a user
     * @param staffDto user to retrieve token for
     * @return token
     */
    StaffVerifyToken getVerificationToken(StaffDto staffDto);

    /**
     * Check if token received as input is in database
     * @param tokenDto input token
     * @return token
     */
    StaffVerifyToken getVerificationToken(TokenDto tokenDto);

    /**
     * Delete verification token
     * @param staffVerifyToken token to delete
     * @return true on success
     */
    boolean deleteVerifyToken(StaffVerifyToken staffVerifyToken);

    /**
     * Generate forgot password token
     * @param staffDto user to generate token for
     * @return reset token
     */
    StaffResetToken generateResetToken(StaffDto staffDto);

    /**
     * Retrieve forgot password token from db
     * @param tokenDto queried token
     * @return reset token
     */
    StaffResetToken getResetToken(TokenDto tokenDto);


    /**
     * Delete verification token
     * @param staffResetToken token to delete
     * @return true on success
     */
    boolean deleteResetToken(StaffResetToken staffResetToken);

    /**
     * Parese token to retrieve user details
     * @param tokenDto to parse
     * @return username
     */
    String getUserDetailsFromToken(TokenDto tokenDto);


}
