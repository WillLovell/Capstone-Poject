package com.foodorder.crm.entity;

import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Customer Entity persisted to Database.
 */
@Entity
@Table()
@Getter
public class Customer implements Serializable
{

    @Id
    @GeneratedValue(generator="CUSTOMER_SEQ",strategy=GenerationType.SEQUENCE)
    @Column(name="id")
    private Long id;

    @Column(name="first_name", nullable = false)
    private String firstName;

    @Column(name="last_name", nullable = true)
    private String lastName;

    @Column(name="email", nullable = false, unique = true)
    private String email;

    @Column(name="protected_password", nullable = false)
    private String protectedPassword;

    @Column(name="account_status")
    private boolean accountStatus;

    @Column(name="account_activated")
    private boolean accountActivated;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private Set<Order> orders = new HashSet<>();

    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    private CustomerRole role;

    public Customer(final String firstName, final String email, final String password)
    {
        this.firstName = firstName;
        this.email = email;
        this.protectedPassword = password;
        this.accountStatus = true;
        this.accountActivated = false;

    }

    public Customer()
    {

    }

    /**
     * Helper method to add an order to the customer's Set of Order
     * @param order
     */
    public void addOrder(Order order) {

        if (order != null) {

            if (orders == null) {
                orders = new HashSet<>();
            }

            orders.add(order);
            order.setCustomer(this);
        }
    }

    public CustomerRole getRole()
    {
        return role;
    }

    private Set<CustomerAuthority> getAuthorities()
    {
        return getRole().getCustomerAuthorities();
    }

    public Set<GrantedAuthority> getGrantedAuthorities()
    {
        Set<GrantedAuthority> grantedAuthoritySet = new HashSet<>();
        getAuthorities().forEach(auth ->
                grantedAuthoritySet.add(new SimpleGrantedAuthority(auth.getName()))
        );
        return grantedAuthoritySet;
    }

    public void setRole(final CustomerRole role)
    {
        this.role = role;
    }
}






