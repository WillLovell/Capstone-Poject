package com.foodorder.crm.security;

import com.foodorder.crm.entity.StaffRole;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Class extends default Spring User Class. JwtToken parsed into Principal Staff
 */
public class PrincipalStaff extends User implements Serializable
{
    private final long id;
    private final boolean status;
    private static final long serialVersionUID = -8910169411684852759L;

    public PrincipalStaff(final String username, final String password, final Collection<? extends GrantedAuthority> authorities, final long id, final boolean status)
    {
        super(username, password, authorities);

        this.id = id;
        this.status = status;
    }


    public long getId()
    {
        return id;
    }

    public Collection<GrantedAuthority> getAuthorities(StaffRole role)
    {
        Set<GrantedAuthority> grantedAuthoritySet = new HashSet<>();
        grantedAuthoritySet.add(new SimpleGrantedAuthority(role.getName()));
        role.getStaffAuthorities().stream().map(
                        auth -> new SimpleGrantedAuthority(auth.getName()))
                .forEach(grantedAuthoritySet::add);
        return grantedAuthoritySet;
    }
    @Override
    public boolean isEnabled()
    {
        return status;
    }

}
