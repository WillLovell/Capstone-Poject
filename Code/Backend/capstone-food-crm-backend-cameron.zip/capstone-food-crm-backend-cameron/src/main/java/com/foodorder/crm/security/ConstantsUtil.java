package com.foodorder.crm.security;

/**
 * Constants used by Token Entities and Security Package
 */
public final class ConstantsUtil
{
    public static final long LOGIN_TOKEN_EXPIRE = 864000000;
    public static final long VERIFY_TOKEN_EXPIRE = 1800000;
    public static final long RESET_TOKEN_EXPIRE = 100000000;
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STR = "Authorization";
    public static final String SING_UP_URL = "dashboard/staff";
    public static final String TOKEN_SECRET ="e78d5ad0-d76a-4714-a919-5bd8493cb270";
    public static final String UI_URL = "http://localhost:4200";
}
