package com.foodorder.crm.dto.rest;
/**
 * Data Transfer Class used for REST Response to represent Staff entity
 */
import lombok.Getter;

import java.io.Serializable;
@Getter
public class StaffResponseDto implements Serializable
{
    private static final long serialVersionUID = 474637239670836354L;
    private Long id;
    private String firstName;
    private String lastName;
    private String email;


    public StaffResponseDto(final Long id, final String firstName, final String lastName, final String email)
    {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }


}
