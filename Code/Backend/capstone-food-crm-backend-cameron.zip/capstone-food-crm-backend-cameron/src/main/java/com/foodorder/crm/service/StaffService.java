package com.foodorder.crm.service;

import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.dto.spring.TokenDto;
import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffRole;
import com.foodorder.crm.entity.StaffVerifyToken;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.Set;
/**
 * Interface used for interaction with the Staff repository
 */
@Service
public interface StaffService extends UserDetailsService
{
    /**
     * Retrieve user by their id
     * @param id of user
     * @return user queried
     */
    Staff getStaffById(Long id);

    /**
     * Retrieve user by their username
     * @param staffDto user details, including username
     * @return user queried
     */
    Staff getStaffByEmail(String staffDto);

    /**
     * Update user with new information
     * @param staffDto new user details
     * @return updated user details
     */
    Staff updateStaff(StaffDto staffDto);

    /**
     * Create new user
     * @param staffDto new user details
     * @return new user
     */
    Staff createStaff(StaffDto staffDto);

    /**
     * Delete or deactivate user
     * @param id user id
     * @param delete true if delete required
     * @param deactivate true if deactivate required
     * @return true on success
     */
    Boolean deleteStaff(long id, boolean delete, boolean deactivate);

    /**
     * Confirm user registration
     * @param staffDto user details to confirm
     * @return the confirmed user
     */
    Staff confirmStaff(StaffDto staffDto);

    /**
     * Reset user password to new password
     * @param staffDto user details
     * @param password new password
     * @return updated user
     */
    Staff resetPassword(StaffDto staffDto, String password);

    /**
     * Return all user roles persisted to db
     * @return set of user roles
     */
    Set<StaffRole> getRoles();

    /**
     * Retrieve specific user role
     * @param role role to query
     * @return the queried role
     */
    StaffRole getRole(String role);

    /**
     * Retrieve all staff users
     * @return all staff users
     */
    Set<Staff> getAllStaff();
}
