package com.foodorder.crm.serviceImpl;


import com.foodorder.crm.dto.spring.MenuCategoryDto;
import com.foodorder.crm.dto.spring.MenuItemDto;
import com.foodorder.crm.entity.MenuCategory;
import com.foodorder.crm.entity.MenuItem;
import com.foodorder.crm.repositories.MenuCategoryRepository;
import com.foodorder.crm.repositories.MenuItemRepository;
import com.foodorder.crm.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
/**
 * Implementation of the MenuService interface.
 */
@Component
public class MenuServiceImpl implements MenuService
{
    private MenuItemRepository menuItemRepository;
    private MenuCategoryRepository menuCategoryRepository;
    @Autowired
    public MenuServiceImpl(MenuItemRepository menuItemRepository, MenuCategoryRepository menuCategoryRepository)
    {
        this.menuItemRepository = menuItemRepository;
        this.menuCategoryRepository = menuCategoryRepository;
    }



    @Override
    public List<MenuItem> getAllMenuItems()
    {
        List<MenuItem> menuItems = (List<MenuItem>) menuItemRepository.findAll();

        return menuItems;
    }

    @Override
    public MenuItem getMenuItem(final long id)
    {

        Optional<MenuItem> menuItemOptional =menuItemRepository.findById(id);
        if(menuItemOptional.isPresent())
            {
                return menuItemOptional.get();
            }
        throw new IllegalStateException("Menu Category not found");

    }

    @Override
    public Set<MenuCategory> getAllMenuCategories()
    {
        Set<MenuCategory> menuCategorySet = StreamSupport.stream(menuCategoryRepository.findAll().spliterator(),false).collect(Collectors.toSet());
//                (Set<MenuCategory>) menuCategoryRepository.findAll();
        return menuCategorySet;
    }


//    @Override
//    public MenuCategory getMenuCategoryItems(final long id)
//    {
//        Optional<MenuCategory> menuCategoryOptional = menuCategoryRepository.findById(id);
//
//        if(menuCategoryOptional.isPresent())
//            {
//                return menuCategoryOptional.get();
//            }
//        throw new IllegalStateException("Menu Category not found");
//
//    }

    @Override
    public MenuCategory getMenuCategoryDetails(final long id)
    {
        Optional<MenuCategory> menuCategoryOptional = menuCategoryRepository.findById(id);

        if(menuCategoryOptional.isPresent())
            {
                return menuCategoryOptional.get();
            }
        throw new IllegalStateException("Menu Category not found");
    }

    @Override
    public MenuCategory updateMenuCategoryDetails(MenuCategoryDto menuCategoryDto)
    {
        Optional<MenuCategory> menuCategoryOptional = menuCategoryRepository.findById(menuCategoryDto.getId());

        if(!menuCategoryOptional.isPresent())
            {
                throw new IllegalStateException("Menu Category not found");
            }
        else
            {
                menuCategoryRepository.updateMenuItem(menuCategoryDto.getName(), menuCategoryDto.getId());
            }
        return menuCategoryRepository.findById(menuCategoryDto.getId()).get();
    }


    @Override
    @Transactional
    public MenuItem updateMenuItem(final MenuItemDto menuItemDto, boolean status, final long menuCategoryId)
    {
        Optional<MenuItem> menuItemOptional = menuItemRepository.findById(menuItemDto.getId());
        Optional<MenuCategory> menuCategoryOptional = menuCategoryRepository.findById(menuCategoryId);

        if(!(menuItemOptional.isPresent() || menuCategoryOptional.isPresent() || menuItemDto.getPrice().doubleValue() > 0))
            {
                throw new IllegalStateException("Menu Item not found");
            }
        else
            {
                menuItemRepository.updateMenuItem(
                        menuItemDto.getDescription(),
                        menuItemDto.getName(),
                        menuItemDto.getPrice(),
                        menuItemDto.getImageUrl(),
                        status,
                        menuCategoryOptional.get(),
                        menuItemDto.getId()
                );

            }
            return menuItemRepository.findById(menuItemDto.getId()).get();
    }

    @Override
    public MenuItem createMenuItem(final MenuItemDto menuItemDto, final MenuCategoryDto menuCategoryDto)
    {
        Optional<MenuCategory> menuCategoryOptional = menuCategoryRepository.findById(menuCategoryDto.getId());
        if(!menuCategoryOptional.isPresent())
            {
                throw new IllegalStateException("No such category");
            }
        else
        {
            MenuItem menuItem = new MenuItem(
                    menuItemDto.getName(),
                    menuItemDto.getDescription(),
                    menuItemDto.getPrice(),
                    menuItemDto.getImageUrl(),
                    menuCategoryOptional.get()

            );
            menuItemRepository.save(menuItem);
            return menuItem;
        }
    }

    @Override
    public boolean deleteMenuItem(final MenuItemDto menuItemDto)
    {
        Optional<MenuItem> menuItemOptional =menuItemRepository.findById(menuItemDto.getId());
        if(!menuItemOptional.isPresent())
            {
                throw new IllegalStateException("No such menu item");
            }
        try
            {
                menuItemRepository.delete(menuItemOptional.get());
                return true;
            }catch (Exception e)
            {
                return false;
            }
    }


}
