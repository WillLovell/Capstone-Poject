package com.foodorder.crm.entity;
/**
 * Class to represent Authorities granted to a Staff user
 */

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;
@Entity
@Table()
public class StaffAuthority implements Serializable
{
    private static final long serialVersionUID = 5362872590263416083L;
    @Id
    @Column(name = "id")
    @GeneratedValue(generator="STAFF_AUTH_SEQ",strategy= GenerationType.SEQUENCE)
    private long id;

    @Column(nullable = false, unique = true)
    private String name;

    @ManyToMany(mappedBy = "authorities")
    private Set<StaffRole> roles;

    public StaffAuthority()
    {

    }

    public StaffAuthority(final String name)
    {
        this.name = name;
    }

    public long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public Set<StaffRole> getCustomerRoles()
    {
        return roles;
    }
}