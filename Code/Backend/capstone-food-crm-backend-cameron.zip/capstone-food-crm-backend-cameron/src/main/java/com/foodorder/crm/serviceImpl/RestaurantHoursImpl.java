package com.foodorder.crm.serviceImpl;

import com.foodorder.crm.dto.rest.RestaurantHoursDto;
import com.foodorder.crm.entity.RestaurantHours;
import com.foodorder.crm.repositories.RestaurantHoursRepository;
import com.foodorder.crm.service.RestaurantHoursService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Time;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;
@Component
/**
 * Implementation of the RestaurantHours Service interface.
 */
public class RestaurantHoursImpl implements RestaurantHoursService
{

    private RestaurantHoursRepository restaurantHoursRepository;
    @Autowired
    private RestaurantHoursImpl(final RestaurantHoursRepository restaurantHoursRepository)
    {
        this.restaurantHoursRepository = restaurantHoursRepository;
    }

    @Override
    public boolean createRestaurantHours(final RestaurantHoursDto restaurantHoursDto)
    {
        DayOfWeek dow = restaurantHoursDto.getDayOfWeek();
        Optional<RestaurantHours> restaurantHoursOptional = restaurantHoursRepository.findByDayOfWeek(dow);
        if(restaurantHoursOptional.isPresent())
            {
                throw new IllegalStateException("Day of week already exists.");
            }
        RestaurantHours restaurantHours = new RestaurantHours();
        Time close = Time.valueOf(restaurantHoursDto.getClose());
        Time open = Time.valueOf(restaurantHoursDto.getOpen());
        restaurantHours.setDayOfWeek(dow);
        restaurantHours.setOpenTime(open);
        restaurantHours.setCloseTime(close);


        restaurantHoursRepository.save(restaurantHours);
        return true;
    }

    @Override
    public boolean updateHours(final RestaurantHoursDto restaurantHoursDto)
    {
        DayOfWeek dow = restaurantHoursDto.getDayOfWeek();
        Optional<RestaurantHours> restaurantHoursOptional = restaurantHoursRepository.findByDayOfWeek(dow);
        if(!restaurantHoursOptional.isPresent())
            {
                throw new IllegalStateException("No time currently set");
            }
        RestaurantHours restaurantHours = restaurantHoursOptional.get();
        Time close = Time.valueOf(restaurantHoursDto.getClose());
        Time open = Time.valueOf(restaurantHoursDto.getOpen());
        restaurantHours.setDayOfWeek(dow);
        restaurantHours.setOpenTime(open);
        restaurantHours.setCloseTime(close);
        restaurantHoursRepository.save(restaurantHours);
        return true;
    }



//    @Override
//    public boolean canPlaceOrder(final LocalDateTime date)
//    {
//        DayOfWeek dow = date.getDayOfWeek();
//        Optional<RestaurantHours> restaurantHoursOptional = restaurantHoursRepository.findByDayOfWeek(dow);
//        if(!restaurantHoursOptional.isPresent())
//            {
//                throw new IllegalStateException("No such day of week");
//            }
//        Time openTime = restaurantHoursOptional.get().getOpenTime();
//        Time closeTime = restaurantHoursOptional.get().getCloseTime();
//        Time orderTime = Time.valueOf(date.toLocalTime());
//
//        if(orderTime.after(openTime) && orderTime.before(closeTime))
//            {
//                return  true;
//            }
//        return false;
//
//    }



}
