package com.foodorder.crm.dto.rest;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.foodorder.crm.entity.Order;
import lombok.Getter;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

/**
 * Data Transfer Object (DTO) Class used to transfer data between Objects.
 */

@Getter
public class OrderDto implements Serializable
{
    private final long id;
    private  int totalQuantity;
    private  BigDecimal totalPrice;
    private  Order.OrderStatus orderStatus;
    private  Set<OrderItemDto> orderItems;



    public OrderDto(final long id, final int totalQuantity, final BigDecimal totalPrice, final Order.OrderStatus orderStatus, final Set<OrderItemDto> orderItems)
    {
        this.id = id;
        this.totalQuantity = totalQuantity;
        this.totalPrice = totalPrice;
        this.orderStatus = orderStatus;
        this.orderItems = orderItems;
    }
    @JsonCreator
    public OrderDto(final int totalQuantity, final BigDecimal totalPrice, final Order.OrderStatus orderStatus, final Set<OrderItemDto> orderItems)
    {
        this.id = -1;
        this.totalQuantity = totalQuantity;
        this.totalPrice = totalPrice;
        this.orderStatus = orderStatus;
        this.orderItems = orderItems;
    }

    public OrderDto(final long id)
    {
        this.id = id;

    }


    public OrderDto(final long id, final Order.OrderStatus orderStatus)
    {
        this.id = id;
        this.orderStatus = orderStatus;
    }
}
