package com.foodorder.crm.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Time;
import java.time.DayOfWeek;
@Entity
@Getter
@Setter
/**
 * RestaurantHours is used to represent operating hours for a week. Start, end and day of week.
 */
@Table(name="restaurant_hours")
public class RestaurantHours
{
    @Id
    @GeneratedValue(generator="HOURS_SEQ",strategy= GenerationType.SEQUENCE)
    @Column(name="id")
    private Long id;

    @Enumerated(EnumType.STRING)
    private DayOfWeek dayOfWeek;

    private Time openTime;
    private Time closeTime;

    public RestaurantHours(final DayOfWeek dow, final Time valueOf, final Time valueOf1)
    {
        this.dayOfWeek = dayOfWeek;
        this.openTime = openTime;
        this.closeTime = closeTime;
    }


    public RestaurantHours()
    {

    }
}
