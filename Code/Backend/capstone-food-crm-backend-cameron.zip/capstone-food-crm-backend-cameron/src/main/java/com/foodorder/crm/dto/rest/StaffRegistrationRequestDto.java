package com.foodorder.crm.dto.rest;

/**
 * Data Transfer Class used for REST Request to register a new User entity
 */
public class StaffRegistrationRequestDto
{
    private String firstName;
    private String lastName;
    private String email;
    private String password;

    protected StaffRegistrationRequestDto(final String firstName, final String lastName, final String email, final String password)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public String getEmail()
    {
        return email;
    }

    public String getPassword()
    {
        return password;
    }
}
