package com.foodorder.crm.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

/**
 * Class represents Roles for a given Staff user
 */
@Entity
@Table()
public class StaffRole implements Serializable
{

    private static final long serialVersionUID = 4117912120105623187L;
    @Id
    @Column(name = "id")
    @GeneratedValue(generator="STAFF_ROLE_SEQ",strategy=GenerationType.SEQUENCE)
    private long id;
    @Column(nullable = false, unique = true)
    private String name;

    @OneToMany(mappedBy = "role")
    private Set<Staff> staffSet;

    @ManyToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
    @JoinTable(
            name = "staff_authorities",
            joinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "authority_id", referencedColumnName = "id")
    )
    private Set<StaffAuthority> authorities;

    public StaffRole(final String name)
    {
        this.name = name;
    }

    public StaffRole()
    {

    }



    public long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public Set<Staff> getStaffs()
    {
        return staffSet;
    }

    public Set<StaffAuthority> getStaffAuthorities()
    {
        return authorities;
    }

    public void setAuthorities(final Set<StaffAuthority> authorities)
    {
        this.authorities = authorities;
    }
}