package com.foodorder.crm.dto.spring;

import lombok.Data;

import java.util.Set;
@Data
/**
 * Data Transfer Object (DTO) Class used to transfer data between Spring Classes.
 * MenuCategorySetDto represent a Set of MenuCategory entities
 */
public class MenuCategorySetDto
{
        private final Set<MenuItemDto> menuItems;
}
