package com.foodorder.crm.controller;

import com.foodorder.crm.dto.rest.MenuCategoryUpdateRequest;
import com.foodorder.crm.dto.rest.MenuItemRequestDto;
import com.foodorder.crm.dto.spring.MenuCategoryDto;
import com.foodorder.crm.dto.spring.MenuItemDto;
import com.foodorder.crm.entity.MenuCategory;
import com.foodorder.crm.entity.MenuItem;
import com.foodorder.crm.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Rest Controller responsible for the REST Api calls for menu management
 */
@RestController
@CrossOrigin()
@RequestMapping("/dashboard/menu")


public class MenuController
{
    private final MenuService menuService;
    private final ControllerUtils controllerUtils;

    @Autowired
    public MenuController(final MenuService menuService, final ControllerUtils controllerUtils)
    {
        this.menuService = menuService;
        this.controllerUtils = controllerUtils;
    }

    /**
     * Public Api endpoint method for querying the menu categories. Method will be
     * @param id menu category id queried
     * @return MenuCategoryDto Encapsulated Set of MenuItemDto's
     */
    @GetMapping("/category/{id}")
    public ResponseEntity<MenuCategoryDto> getMenuCategoryDto(@PathVariable final long id)
    {
        MenuCategory menuCategory = menuService.getMenuCategoryDetails(id);
        MenuCategoryDto menuCategoryDto = controllerUtils.convertToMenuCategoryDto(menuCategory);
        return new ResponseEntity<>(menuCategoryDto, HttpStatus.OK);
    }

    /**
     * Api endpoint method for updating a MenuCategory
     * @param id of menu category
     * @param menuCategoryUpdateRequest new category details
     * @return DTO representing MenuCategory
     */
    @PutMapping("/category/{id}")
    public ResponseEntity<MenuCategoryDto> updateMenuCategoryDto(@PathVariable final long id,  @RequestBody MenuCategoryUpdateRequest menuCategoryUpdateRequest)
    {
        MenuCategoryDto menuCategoryDto = controllerUtils.convertToMenuCategoryDto(menuCategoryUpdateRequest, id);
        MenuCategory menuCategory = menuService.updateMenuCategoryDetails(menuCategoryDto);
        MenuCategoryDto response = controllerUtils.convertToMenuCategoryDto(menuCategory);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Api endpoint method for retrieving details of all MenuCategory
     * @return Set of DTOs representing MenuCategory
     */
    @GetMapping("/category")
    public ResponseEntity<Set<MenuCategoryDto>> getMenuCategories()
    {
        Set<MenuCategory> menuCategorySet = menuService.getAllMenuCategories();
        Set<MenuCategoryDto> menuCategoryDtoSet = menuCategorySet.stream().map(
                controllerUtils::convertToMenuCategoryDto).collect(Collectors.toSet());
        return new ResponseEntity<Set<MenuCategoryDto>>(menuCategoryDtoSet, HttpStatus.OK);
    }

    /**
     * Public Api endpoint method for querying a specific menu item.
     * @param id menu item queried
     * @return JSON representation of a menuItemDto
     */
    @GetMapping("/{id}")
    public ResponseEntity<MenuItemDto> getMenuItemDto(@PathVariable final long id)
    {
        MenuItem menuItem = menuService.getMenuItem(id);
        MenuItemDto menuItemDto = controllerUtils.convertToMenuItemDto(menuItem);
        return new ResponseEntity<>(menuItemDto, HttpStatus.OK);
    }

    /**
     * Api endpoint method for Updating a MenuItem
     * @param id MenuItem id
     * @param menuItemRequestDto MenuItem to update
     * @return DTO representing updated MenuItem
     */
    @PutMapping("/{id}")
    public ResponseEntity<MenuItemDto> updateMenuItemDto(@PathVariable long id, @RequestBody MenuItemRequestDto menuItemRequestDto)
    {

        MenuItemDto menuItemDto = controllerUtils.convertToMenuItemDto(menuItemRequestDto, id);
        MenuItem menuItem = menuService.updateMenuItem(menuItemDto, menuItemRequestDto.isStatus(), menuItemRequestDto.getMenuCategoryId());

        return new ResponseEntity<>(menuItemDto, HttpStatus.OK);
    }
    /**
     * Public Api endpoint to return all active menu items.
     * @return all active menu items
     */
    @GetMapping()
    public ResponseEntity<Set<MenuItemDto>> getMenu()
    {

        List<MenuItem> menuItems = menuService.getAllMenuItems();
        Set<MenuItemDto> menuItemDtos = menuItems.stream().map(
                controllerUtils::convertToMenuItemDto).collect(Collectors.toSet());
        return new ResponseEntity<Set<MenuItemDto>>(menuItemDtos, HttpStatus.OK);
    }

    /**
     * Api endpoint method for creating a new MenuItem
     * @param menuItemRequestDto details for new MenuItem
     * @return DTO representing new MenuItem
     */
    @PostMapping
    public ResponseEntity<MenuItemDto> createMenuItem(@RequestBody MenuItemRequestDto menuItemRequestDto)
    {
        MenuItemDto menuItemDto = controllerUtils.convertToMenuItemDto(menuItemRequestDto);
        MenuCategoryDto menuCategoryDto = controllerUtils.convertToMenuCategoryDto(menuItemRequestDto);
        MenuItem menuItem = menuService.createMenuItem(menuItemDto, menuCategoryDto);
        MenuItemDto responseDto = controllerUtils.convertToMenuItemDto(menuItem);
        return new ResponseEntity<>(responseDto, HttpStatus.OK);
    }

    /**
     * Api endpoint method for delete a MenuItem
     * @param id db id for MenuItem
     * @return true if transaction successful
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> deleteMenuItem(@PathVariable final long id)
    {
        MenuItemDto menuItemDto = new MenuItemDto(id);
        boolean result = menuService.deleteMenuItem(menuItemDto);
        if(result)
            {
                return new ResponseEntity<Boolean>(true, HttpStatus.OK);
            }
        throw new IllegalStateException("Unable to process");

    }

}

