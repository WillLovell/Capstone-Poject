package com.foodorder.crm.controller;


import com.foodorder.crm.dto.rest.CustomerResponseDto;
import com.foodorder.crm.dto.spring.CustomerDto;
import com.foodorder.crm.entity.Customer;
import com.foodorder.crm.security.ConstantsUtil;
import com.foodorder.crm.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Set;

/**
 * Rest Controller responsible for the REST Api calls related to customer management.
 */
@CrossOrigin(ConstantsUtil.UI_URL)
@RestController
@RequestMapping("/dashboard/customers")

public class CustomerController
{
    private ControllerUtils controllerUtils;
    private CustomerService customerService;
    @Autowired
    public CustomerController(ControllerUtils controllerUtils, CustomerService customerService)
    {
        this.controllerUtils = controllerUtils;
        this.customerService = customerService;
    }

    /**
     * API endpoint to request customer details. Customer id passed in as path variable.
     * @param id
     * @return DTO representation of requested customer
     */
    @GetMapping("/{id}")
    public ResponseEntity<CustomerResponseDto> getCustomerbyId(@PathVariable long id)
    {
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(id);
        System.out.println("customerDto" + customerDto.getId());
        Customer customer = customerService.getCustomer(customerDto.getId());
        System.out.println(customer);
        CustomerResponseDto customerResponseDto = controllerUtils.convertCustomerToCustomerReponseDto(customer);
        return ResponseEntity.ok().body(customerResponseDto);
    }

    /**
     * API endpoint to request all customer details.
     * @return Set of Customer DTOs representation the customers
     */
    @GetMapping("/")
    public ResponseEntity<Set<CustomerResponseDto>> getCustomers()
    {
        Set<Customer> customers = customerService.getAllCustomers();
        Set<CustomerResponseDto> customerResponseDto = new HashSet<>();
        customers.stream().forEach(customer -> customerResponseDto.add(
                controllerUtils.convertCustomerToCustomerReponseDto(customer)));
        return ResponseEntity.ok().body(customerResponseDto);
    }


}
