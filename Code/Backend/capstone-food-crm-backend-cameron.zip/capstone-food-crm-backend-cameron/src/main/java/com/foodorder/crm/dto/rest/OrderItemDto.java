package com.foodorder.crm.dto.rest;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Data Transfer Object (DTO) Class used to transfer data between Objects for the Order Item entity.
 */

@Data
public class OrderItemDto implements Serializable
{
    private final BigDecimal itemPrice;
    private final int quantity;
    private final Long menuItemId;
    private final String name;

}
