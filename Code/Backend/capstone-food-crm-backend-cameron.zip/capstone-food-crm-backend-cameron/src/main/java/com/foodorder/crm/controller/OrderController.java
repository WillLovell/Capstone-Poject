package com.foodorder.crm.controller;

import com.foodorder.crm.dto.rest.OrderDto;
import com.foodorder.crm.dto.rest.OrderResponseDto;
import com.foodorder.crm.dto.rest.OrderUpdateRequest;
import com.foodorder.crm.dto.spring.CustomerDto;
import com.foodorder.crm.entity.Customer;
import com.foodorder.crm.entity.Order;
import com.foodorder.crm.security.ConstantsUtil;
import com.foodorder.crm.service.CustomerService;
import com.foodorder.crm.service.EmailService;
import com.foodorder.crm.service.OrderService;
import com.foodorder.crm.service.RestaurantHoursService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.yaml.snakeyaml.util.EnumUtils;
import java.text.ParseException;
import java.util.Date;
import java.util.Optional;
import java.util.Set;

/**
 * API RestController for operations relating to Orders
 */
@RestController
@CrossOrigin(ConstantsUtil.UI_URL)
@RequestMapping("/dashboard/orders")

public class OrderController
{
    private OrderService orderService;
    private CustomerService customerService;
    private ControllerUtils controllerUtils;
    private RestaurantHoursService restaurantHoursService;
    private EmailService emailService;

    @Autowired
    public OrderController(final OrderService orderService, final ControllerUtils controllerUtils, final CustomerService customerService, final RestaurantHoursService restaurantHoursService, final EmailService emailService)
    {
        this.orderService = orderService;
        this.controllerUtils = controllerUtils;
        this.customerService = customerService;
        this.restaurantHoursService = restaurantHoursService;
        this.emailService = emailService;
    }

    /**
     * Api endpoint search method for retrieving Orders by a given Order.Status
     * @param status to retrieve
     * @return Set of DTOs representing orders by given status
     */
    @GetMapping(value = "/search/status")
    public ResponseEntity<Set<OrderResponseDto>> getOrdersByStatus(@RequestParam(name="name", required = true) String status)
    {
        Order.OrderStatus orderStatus = controllerUtils.convertToOrderStatus(status);
        Set<Order> orders = orderService.getOrdersByStatus(orderStatus);
        Set<OrderResponseDto>  orderResponseDtos = controllerUtils.convertToOrderResponseDto(orders);
        return new ResponseEntity<>(orderResponseDtos, HttpStatus.OK);
    }

    /**
     * Api endpoint search method for retrieving Orders by a given Customer entity's id
     * @param id of customer
     * @return Set of DTOs representing orders for given customer
     */
    @GetMapping(value = "/search/customer")
    public ResponseEntity<Set<OrderResponseDto>> getOrdersByCustomer(@RequestParam(name="id", required = true) long id)
    {
        Customer customer = customerService.getCustomer(id);
        CustomerDto customerDto = controllerUtils.convertToCustomerDto(customer);
        Set<Order> orders = orderService.getOrdersByCustomer(customerDto);
        Set<OrderResponseDto>  orderResponseDtos = controllerUtils.convertToOrderResponseDto(orders);
        return new ResponseEntity<>(orderResponseDtos, HttpStatus.OK);
    }
    /**
     * Api endpoint search method for retrieving Order by a given Order entity id
     * @param id of Order entity
     * @return DTO representing order
     */
    @GetMapping(value = "/search/order")
    public ResponseEntity<OrderResponseDto> getOrdersByOrderId(@RequestParam(name="id", required = true) long id)
    {
        OrderDto orderDto = controllerUtils.convertToOrderDto(id);
        Order order = orderService.getOrderById(orderDto.getId());
        OrderResponseDto  orderResponseDto = controllerUtils.convertToOrderResponseDto(order);
        return new ResponseEntity<>(orderResponseDto, HttpStatus.OK);
    }
    /**
     * Api endpoint search method for retrieving Order by a given Order entity id
     * @param from string representing 'from' date
     * @param to optional string representing 'to' date
     * @return Set of DTOs representing orders in date query
     */
    @GetMapping(value = "/search/date")
    public Set<OrderResponseDto> getOrdersByDate(@RequestParam("from") String from,
                                                 @RequestParam(value = "to", required = false)   Optional<String> to) throws ParseException
    {
        Set<Order> orders;
        if(!to.isPresent())
            {
                Date dateFrom = controllerUtils.convertToDateFormat(from);
                orders = orderService.getOrdersByDate(Date.from(dateFrom.toInstant()));
            }
        else if (from.equals(to.get()))
            {
//                Date start  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(from.toString());
//                start.
//                Date end = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(to.toString());
//                System.out.println(Date.from(from.toInstant()));
//                orders = orderRepository.findByDateCreatedBetween(Date.from(from.toInstant()),Date.from(to.get().toInstant()));
                Date dateFrom = controllerUtils.convertToDateFormat(from);
                Date dateTo = controllerUtils.convertAndOffsetDate(to.get(), 1);
                orders = orderService.getOrdersBetweenDates(Date.from(dateFrom.toInstant()), Date.from(dateTo.toInstant()));
            }
        else
        {
            Date dateFrom = controllerUtils.convertToDateFormat(from);
            Date dateTo = controllerUtils.convertToDateFormat(to.get());
            orders = orderService.getOrdersBetweenDates(Date.from(dateFrom.toInstant()),Date.from(dateTo.toInstant()));

        }
        Set<OrderResponseDto>  orderResponseDtos = controllerUtils.convertToOrderResponseDto(orders);

        return orderResponseDtos;

    }

    /**
     * Api endpoint to update an Order entity's order status
     * @param orderUpdateRequest details of order to update
     * @return DTO representing the updated order
     */
    @PutMapping
    public ResponseEntity<OrderResponseDto> updateOrderStatus(@RequestBody OrderUpdateRequest orderUpdateRequest)
    {
        OrderDto orderDto = controllerUtils.convertToOrderDto(orderUpdateRequest);
        Order order = orderService.updateOrderStatus(orderDto);
        if(order != null)
            {
                Customer customer = order.getCustomer();
                if(customer.getOrders().contains(order))
                    {
                        CustomerDto customerDto = controllerUtils.convertToCustomerDto(order.getCustomer());
                        emailService.sendOrderUpdateToCustomer(orderDto, customerDto);
                    }
            }
        OrderResponseDto  orderResponseDto = controllerUtils.convertToOrderResponseDto(order);
        return new ResponseEntity<>(orderResponseDto, HttpStatus.OK);
    }




}
