package com.foodorder.crm.serviceImpl;

import com.foodorder.crm.dto.rest.OrderDto;
import com.foodorder.crm.dto.spring.CustomerDto;
import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.entity.Order;
import com.foodorder.crm.entity.StaffResetToken;
import com.foodorder.crm.entity.StaffVerifyToken;
import com.foodorder.crm.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
/**
 * Implementation of the EmailService interface.
 */
@Component
public class EmailServiceImpl implements EmailService
{
    private JavaMailSender javaMailSender;

    @Autowired
    public EmailServiceImpl(final JavaMailSender javaMailSender)
    {
        this.javaMailSender = javaMailSender;
    }

    @Override
    public boolean sendConfirmationEmail(final StaffDto staffDto, final StaffVerifyToken staffVerifyToken)
    {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(staffDto.getEmail());
        message.setSubject("Complete Registration!");
        message.setFrom("proj354.capstone@gmail.com");
        message.setText("To confirm your account, please click here : "
                +"http://localhost:8081/confirm?token="+staffVerifyToken.getToken());

        javaMailSender.send(message);
        return  true;
    }

    @Override
    public boolean sendReset(final StaffDto staffDto, final StaffResetToken staffResetToken)
    {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(staffDto.getEmail());
        message.setSubject("Reset Request");
        message.setFrom("proj354.capstone@gmail.com");
        message.setText("To reset, please click the below. Else ignore. : "
                +"http://localhost:8081/reset?token="+staffResetToken.getToken());

        javaMailSender.send(message);
        return  true;
    }

    @Override
    public void sendOrderUpdateToCustomer(final OrderDto orderDto, final CustomerDto customerDto)
    {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(customerDto.getEmail());
        message.setSubject("Order Update");
        message.setFrom("proj354.capstone@gmail.com");
        Order.OrderStatus status = orderDto.getOrderStatus();
        switch(status)
            {
                case DECLINED:
                {
                    message.setText("Unfortunately we could not process your order.");
                }
                case CONFIRMED:
                {
                    message.setText("Good news! Your order has been confirmed!");
                }
                case COMPLETED:
                {
                    message.setText("Great news! Your order is ready for collection!");
                }
            }
        javaMailSender.send(message);
    }



}
