package com.foodorder.crm.dto.rest;

/**
 * Data Transfer Class used for REST Response
 */
public class CustomerResponseDto
{
    private String firstName;
    private String email;
    private long id;

    public CustomerResponseDto(final String firstName, final String email, final long id)
    {
        this.firstName = firstName;
        this.email = email;
        this.id = id;
    }

    public String getFirstName()
    {
        return firstName;
    }
    public String getEmail()
    {
        return email;
    }

    public long getId()
    {
        return id;
    }
}
