package com.foodorder.crm.entity;
/**
 * Token class used to generate a reset token for password reset of a User.
 */

import com.foodorder.crm.security.ConstantsUtil;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import javax.persistence.*;
import java.util.Date;
@Entity
@Table()
public class StaffResetToken
{
    @Id
    @GeneratedValue(generator="STAFF_RESET_SEQ",strategy= GenerationType.SEQUENCE)
    @Column(name="id")
    private Long id;

    @Column(name="token")
    private String token;

    @OneToOne(targetEntity = Staff.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "user_id")
    private Staff staff;


    public StaffResetToken(final Staff staff)
    {
        this.staff = staff;
        this.token = generateToken();
    }

    private String generateToken()
    {
        return Jwts.builder().setSubject(staff.getEmail())
                .setExpiration(new Date(System.currentTimeMillis() + ConstantsUtil.RESET_TOKEN_EXPIRE))
                .signWith(SignatureAlgorithm.HS256, ConstantsUtil.TOKEN_SECRET).compact();
    }

    public StaffResetToken()
    {

    }

    public Long getId()
    {
        return id;
    }

    public String getToken()
    {
        return token;
    }

    public Staff getStaff()
    {
        return staff;
    }
}
