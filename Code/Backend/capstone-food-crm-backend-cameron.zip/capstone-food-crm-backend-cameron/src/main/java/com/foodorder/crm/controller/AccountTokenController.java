package com.foodorder.crm.controller;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.foodorder.crm.dto.rest.PasswordRequestDto;
import com.foodorder.crm.dto.rest.StaffResponseDto;
import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.dto.spring.TokenDto;
import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffResetToken;
import com.foodorder.crm.entity.StaffRole;
import com.foodorder.crm.entity.StaffVerifyToken;
import com.foodorder.crm.security.ConstantsUtil;
import com.foodorder.crm.security.PrincipalStaff;
import com.foodorder.crm.service.EmailService;
import com.foodorder.crm.service.StaffService;
import com.foodorder.crm.service.StaffTokenService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
/**
 * The AccountTokenController controls REST Api end points for generating and validating account tokens
 * to and from users.
 */
@RestController
@CrossOrigin(ConstantsUtil.UI_URL)
@RequestMapping("")

public class AccountTokenController
{
    private ControllerUtils controllerUtils;
    private StaffService staffService;
    private HttpServletResponse httpServletResponse;
    private StaffTokenService staffTokenService;
    private EmailService emailService;

    public AccountTokenController(final ControllerUtils controllerUtils, final StaffService staffService, final HttpServletResponse httpServletResponse, final StaffTokenService staffTokenService, final EmailService emailService)
    {
        this.controllerUtils = controllerUtils;
        this.staffService = staffService;
        this.httpServletResponse = httpServletResponse;
        this.staffTokenService = staffTokenService;
        this.emailService = emailService;
    }

    /**
     * API endpoint for processing forgotten passwords. Email is received via JSON request
     * @param objectNode
     * @return String message confirming email sent, else exception thrown.
     */
    @PostMapping("/login/forgot-password")
    public ResponseEntity<Object> requestPasswordReset(@RequestBody ObjectNode objectNode)
    {
        String email = objectNode.get("email").asText();
//        StaffDto staffDto = controllerUtils.convertToStaffDto(email);
        Staff staff = staffService.getStaffByEmail(email);
        StaffDto staffDto1 = controllerUtils.convertToStaffDto(staff);
        StaffResetToken token = staffTokenService.generateResetToken(staffDto1);
        if(emailService.sendReset(staffDto1, token))
            {
                return ResponseEntity.ok().body("message: Email sent.");
            }
        throw new IllegalStateException("Unable to verify.");

    }

    /**
     * API endpoint for resetting password. New password and generated Token is received
     * @param passwordRequestDto password and generated Token
     * @return ResponseEntity with StaffResponseDto and Http 200, else exception thrown.
     * @throws IOException
     */
    @PostMapping("/login/reset-password")
    public ResponseEntity<StaffResponseDto> processResetRequest(@RequestBody PasswordRequestDto passwordRequestDto) throws IOException
    {
        TokenDto tokenDto = controllerUtils.convertToTokenDto(passwordRequestDto.getToken());
        StaffResetToken staffResetToken = staffTokenService.getResetToken(tokenDto);
        String email =  staffTokenService.getUserDetailsFromToken(tokenDto);
        Staff staff = staffService.getStaffByEmail(email);
        StaffDto staffDto = controllerUtils.convertToStaffDto(email);
        Staff updatedStaff = staffService.resetPassword(staffDto, passwordRequestDto.getPassword());

        if(updatedStaff != null)
            {
                staffTokenService.deleteResetToken(staffResetToken);
                StaffResponseDto staffResponseDto = controllerUtils.convertStaffToStaffReponseDto(staff);
                return ResponseEntity.ok().body(staffResponseDto);
            }
        throw new IllegalStateException("Unable to process reset.");

    }

    /**
     * API endpoint for confirming created account with Token emailed to email address.
     * @param token verify token
     * @return ResponseEntity with StaffResponseDto and Http 200, else exception thrown.
     * @throws IOException
     */
    @GetMapping("/confirm")
    public ResponseEntity<StaffResponseDto> confirmAccount(@RequestParam String token) throws IOException
    {
        TokenDto tokenDto = controllerUtils.convertToTokenDto(token);
        StaffVerifyToken staffVerifyToken = staffTokenService.getVerificationToken(tokenDto);
        String email =  staffTokenService.getUserDetailsFromToken(tokenDto);
        Staff staff = staffService.getStaffByEmail(email);
        StaffDto staffDto = controllerUtils.convertToStaffDto(email);
        Staff updatedStaff = staffService.confirmStaff(staffDto);

        if(updatedStaff != null)
            {
                staffTokenService.deleteVerifyToken(staffVerifyToken);
                StaffResponseDto staffResponseDto = controllerUtils.convertStaffToStaffReponseDto(staff);
                return ResponseEntity.ok().body(staffResponseDto);
            }
        throw new IllegalStateException("Unable to verify.");

    }

    /**
     * API endpoint to validate Token, and respond with role.
     * @return user Role
     * @throws IOException
     */
    @GetMapping("/can-access")
    public ResponseEntity<Object> getCode() throws IOException
    {

        PrincipalStaff principalStaff = verifyStaff();
        if(principalStaff != null)
            {

                        StaffDto staffDto = new StaffDto(principalStaff.getId());
                        Staff staff = staffService.getStaffById(staffDto.getId());
                        String type = getRoleType(staff);
                        return new ResponseEntity<Object>( Collections.singletonMap("message:", type), HttpStatus.OK);

            }
        throw new IllegalStateException("Unable to verify.");

    }

    /**
     * Helper method to validate Token and User making the request
     * @return the user based on the received Token
     */
    private PrincipalStaff verifyStaff()
    {
        try
            {

                PrincipalStaff principalStaff = ((PrincipalStaff) SecurityContextHolder.getContext().getAuthentication().getPrincipal());
                if(principalStaff.isEnabled() || principalStaff != null)
                    {
                        return principalStaff;
                    }
                throw new IllegalStateException("Error processing. Please try again");
            }
        catch (RuntimeException e)
            {
                throw new IllegalStateException("Error processing. Please try again");
            }

    }

    /**
     * Helper method to return user Role
     * @param staff
     * @return user role
     */
    private String getRoleType(Staff staff)
    {
        try
            {
                String roleName = staff.getRole().getName();
                roleName = roleName.replace("ROLE_", "");
                return roleName;
            }
        catch (RuntimeException e)
            {
                throw new IllegalStateException("Error processing. Please try again");
            }

    }

}
