/**
 * Used for Global exception handling
 */
package com.foodorder.crm.exception;