package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffRole;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
/**
 * Extension of the CrudRepository used for the persistence of a Staff entity
 */
@Repository
public interface StaffRepository extends CrudRepository<Staff, Long>
{
    Optional<Staff> findStaffByEmail(String email);
    @Modifying
    @Transactional
    @Query("update Staff u set u.firstName = ?1, u.lastName = ?2, u.email = ?3, u.role = ?4 where u.id = ?5")
    void updateStaff(String firstName, String lastName, String email, StaffRole role, long userId);
    @Modifying
    @Transactional
    @Query("update Staff u set u.status = ?1 where u.id = ?2")
    void verifiedStaff(boolean status, long userId);

    Optional<Staff> findById(Long id);


}
