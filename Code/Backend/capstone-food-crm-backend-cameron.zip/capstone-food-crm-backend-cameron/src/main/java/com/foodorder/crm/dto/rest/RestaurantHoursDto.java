package com.foodorder.crm.dto.rest;

import lombok.Getter;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;
@Getter
/**
 * Data Transfer Class used for REST Response representing  RestaurantHours entity
 */
public class RestaurantHoursDto
{
    private DayOfWeek dayOfWeek;
    private LocalTime open;
    private LocalTime close;

    public RestaurantHoursDto(final DayOfWeek dayOfWeek, final LocalTime open, final LocalTime close)
    {
        this.dayOfWeek = dayOfWeek;
        this.open = open;
        this.close = close;
    }
}
