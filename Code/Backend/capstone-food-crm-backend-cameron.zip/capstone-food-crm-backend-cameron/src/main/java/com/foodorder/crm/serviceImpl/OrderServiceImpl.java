package com.foodorder.crm.serviceImpl;

import com.foodorder.crm.dto.rest.OrderDto;
import com.foodorder.crm.dto.spring.CustomerDto;
import com.foodorder.crm.entity.Order;
import com.foodorder.crm.repositories.CustomerRepository;
import com.foodorder.crm.repositories.OrderRepository;
import com.foodorder.crm.service.EmailService;
import com.foodorder.crm.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
@Component
/**
 * Implementation of the OrderService interface.
 */
public class OrderServiceImpl implements OrderService
{
    private OrderRepository orderRepository;
    private CustomerRepository customerRepository;
    private EmailService emailService;
    @Autowired
    public OrderServiceImpl(final OrderRepository orderRepository, final CustomerRepository customerRepository, final EmailService emailService)
    {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
        this.emailService = emailService;
    }

    @Override
    public Set<Order> getAllOrders()
    {
        Set<Order> orders = StreamSupport.stream(orderRepository.findAll().spliterator(),false).collect(Collectors.toSet());
        return orders;
    }

    @Override
    public Order getOrderById(final long id)
    {
        Optional<Order> optionalOrder = orderRepository.findOrderById(id);
        if(!optionalOrder.isPresent())
            {
                throw new IllegalArgumentException("No such order");
            }
        return optionalOrder.get();
    }

    @Override
    public Set<Order> getOrdersByCustomer(final CustomerDto customerDto)
    {
       Set<Order> orders = orderRepository.findOrdersByCustomer_Id(customerDto.getId());
       return orders;
    }


    @Override
    public Set<Order> getOrdersByStatus(final Order.OrderStatus orderStatus)
    {
        Optional<Set<Order>> optionalOrders = orderRepository.findOrderByOrderStatus(orderStatus);
        if(!optionalOrders.isPresent())
            {
                throw new IllegalArgumentException("No orders found");
            }
        return optionalOrders.get();
    }

    @Override
    public Set<Order> getOrdersByDate(final Date date)
    {
        Optional<Set<Order>> optionalOrders = Optional.ofNullable(orderRepository.findOrdersByDateCreatedIsLike(date));
        if(!optionalOrders.isPresent())
            {
                throw new IllegalArgumentException("No orders found for " + date);
            }
        return optionalOrders.get();
    }

    @Override
    public Order updateOrderStatus(final OrderDto orderDto)
    {
        Optional<Order> optionalOrder = orderRepository.findOrderById(orderDto.getId());
        if(!optionalOrder.isPresent())
            {
                throw new IllegalArgumentException("No such order");
            }
        Order order = optionalOrder.get();
        order.setOrderStatus(orderDto.getOrderStatus());

        return order;
    }

    @Override
    public Set<Order> getOrdersBetweenDates(final Date from, final Date to)
    {
        Optional<Set<Order>> optionalOrders = Optional.ofNullable(orderRepository.findByDateCreatedBetween(from, to));
        if(optionalOrders.isPresent())
            {
                return  optionalOrders.get();
            }
        throw new IllegalArgumentException("No " +
                "orders found");
    }
}
