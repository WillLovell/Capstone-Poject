package com.foodorder.crm.dto.rest;

import com.foodorder.crm.entity.Order;

/**
 * Data Transfer Class used for REST Request to update an Order Status
 */
public class OrderUpdateRequest
{
    private final long id;
    private final Order.OrderStatus status;

    public OrderUpdateRequest(final long id, final Order.OrderStatus orderStatus)
    {
        this.id = id;
        this.status = orderStatus;
    }

    public long getId()
    {
        return id;
    }

    public Order.OrderStatus getStatus()
    {
        return status;
    }
}
