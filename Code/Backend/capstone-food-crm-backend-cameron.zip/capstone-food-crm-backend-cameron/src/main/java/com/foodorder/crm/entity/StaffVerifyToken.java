package com.foodorder.crm.entity;

import com.foodorder.crm.security.ConstantsUtil;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.core.userdetails.User;

import javax.persistence.*;
import java.util.Date;

/**
 * Token class used to generate a reset token for password reset of a User.
 */

@Entity
@Table()
public class StaffVerifyToken
{
    @Id
    @GeneratedValue(generator="STAFF_VER_SEQ",strategy= GenerationType.SEQUENCE)
    @Column(name="id")
    private Long id;

    @Column(name="token")
    private String token;

    @OneToOne(targetEntity = Staff.class, fetch = FetchType.EAGER)
    @JoinColumn(nullable = false, name = "user_id")
    private Staff staff;


    public StaffVerifyToken(final Staff staff)
    {
        this.staff = staff;
        this.token = generateToken();
    }

    private String generateToken()
    {
        return Jwts.builder().setSubject(staff.getEmail())
                .setExpiration(new Date(System.currentTimeMillis() + ConstantsUtil.VERIFY_TOKEN_EXPIRE))
                .signWith(SignatureAlgorithm.HS256, ConstantsUtil.TOKEN_SECRET).compact();
    }

    public StaffVerifyToken()
    {

    }

    public Long getId()
    {
        return id;
    }

    public String getToken()
    {
        return token;
    }

    public Staff getStaff()
    {
        return staff;
    }
}