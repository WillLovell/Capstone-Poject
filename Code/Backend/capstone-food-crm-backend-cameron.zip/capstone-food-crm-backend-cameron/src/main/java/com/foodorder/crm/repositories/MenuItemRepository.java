package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.MenuCategory;
import com.foodorder.crm.entity.MenuItem;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.math.BigDecimal;
import java.util.Optional;

/**
 * Extension of the CrudRepository used for the persistence of the menu item entity
 */
@Repository
@CrossOrigin("http://localhost:4200")
public interface MenuItemRepository extends CrudRepository<MenuItem, Long>
{
    Optional<MenuItem> findById(long id);
    @Transactional
    @Modifying
    @Query("update MenuItem u set u.description = ?1, u.name = ?2 , u.price = ?3, u.imageUrl = ?4 , u.active = ?5, u.category = ?6 where u.id = ?7")
    void updateMenuItem(String description, String name, BigDecimal price, String imageUrl, boolean status, MenuCategory menuCategory, long menuItemId);

}
