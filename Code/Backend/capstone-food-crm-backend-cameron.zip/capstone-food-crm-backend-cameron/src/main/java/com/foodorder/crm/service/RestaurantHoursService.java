package com.foodorder.crm.service;

import com.foodorder.crm.dto.rest.RestaurantHoursDto;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Date;
/**
 * Interface used for interaction with the RestaurantHours repository
 */
@Service
public interface RestaurantHoursService
{
    /**
     * Method to create new Restaurant Hours
     * @param restaurantHoursDto day, open and close time
     * @return true on success
     */
    boolean createRestaurantHours(RestaurantHoursDto restaurantHoursDto);

    /**
     * Method to create new Restaurant Hours
     * @param restaurantHoursDto day, open and close time
     * @return true on success
     */
    boolean updateHours(RestaurantHoursDto restaurantHoursDto);
}
