package com.foodorder.crm.controller;


import com.foodorder.crm.dto.rest.*;
import com.foodorder.crm.dto.spring.*;
import com.foodorder.crm.entity.*;
import com.foodorder.crm.security.ConstantsUtil;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.util.EnumUtils;

import javax.management.relation.Role;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * ControllerUtils class used for Object conversion, to and from entities to their DTO
 * representations
 */
@Component
public class ControllerUtils
{
    final String PATTERN_RESPONSE = "yyyy-MM-dd HH:mm";
    final String PATTERN_REQUEST = "yyyy-MM-dd";
    final String ROLE_PREFIX = "ROLE_";

    /**
     * Convert Set of orders to a Set of OrderDto
     * @param orders
     * @return Set of OrderDto
     */
    protected Set<OrderResponseDto> convertToOrderResponseDto(final Set<Order> orders)
    {

        Set<OrderResponseDto> orderResponseDtoSet = new HashSet<>();

        orders.forEach(
                order ->
                orderResponseDtoSet.add(
                        new OrderResponseDto(

                                this.convertToOrderDto(order),
                                this.convertToCustomerDto(order),
                                new SimpleDateFormat(PATTERN_RESPONSE).format(order.getDateCreated())
                               ,new SimpleDateFormat(PATTERN_RESPONSE).format(order.getLastUpdated()))
                )
        );
    return orderResponseDtoSet;
    }

    /**
     * Helper method to convert Order to OrderDto. Called internally
     * @param order to convert
     * @return OrderDto
     */
    private OrderDto convertToOrderDto(Order order)
    {
        Set<OrderItemDto> orderItemDtos = new HashSet<>();
        order.getOrderItems().forEach(
                orderItem -> orderItemDtos.add(new OrderItemDto(
                        orderItem.getItemPrice(),
                        orderItem.getQuantity(),
                        orderItem.getMenuItemId(),
                        orderItem.getName()))
        );

        OrderDto orderDto = new OrderDto(
                order.getId(), order.getTotalQuantity(),
                order.getTotalPrice(),
                order.getOrderStatus(),
                orderItemDtos
        );
        return orderDto;
    }

    /**
     * Helper method to convert instantiate a CustomerDto from Order information.
     * @param order relaying to customer
     * @return CustomerDto related to the order
     */
    private CustomerDto convertToCustomerDto(Order order)
    {
        return  new CustomerDto(
                order.getCustomer().getId(),
                order.getCustomer().getEmail(),
                order.getCustomer().getFirstName(),
                order.getCustomer().getLastName()
        );
    }

    /**
     * Convert a MenuItem to a MenuItemDto
     * @param menuItem to convert
     * @return DTO representation of a MenuItem
     */
    protected MenuItemDto convertToMenuItemDto(final MenuItem menuItem)
    {
        MenuItemDto menuItemDto = new MenuItemDto(
                menuItem.getId(),
                menuItem.getName(),
                menuItem.getPrice(),
                menuItem.getImageUrl(),
                menuItem.getDescription(),
                this.convertToMenuCategoryDto(menuItem.getCategory())
        );

        return menuItemDto;
    }

    /**
     * Convert a Menu Items contained in a given category to MenuItemDTO
     * @param menuCategory
     * @return menuCategoryDto with a Set of MenuitemDto's
     */
    protected MenuCategorySetDto convertToMenuCategoryDtoSet(final MenuCategory menuCategory)
    {

        Set<MenuItemDto> menuItemDtos = menuCategory.getMenuItems().stream().map(
                this::convertToMenuItemDto).collect(Collectors.toSet());

        MenuCategorySetDto menuCategorySetDto = new MenuCategorySetDto(
                menuItemDtos

        );

        return menuCategorySetDto;
    }
    /**
     * Convert a MenuCategory to a MenuCategoryDto
     * @param menuCategory to convert
     * @return DTO representation of a MenuCategory
     */
    protected MenuCategoryDto convertToMenuCategoryDto(final MenuCategory menuCategory)
    {

        MenuCategoryDto menuCategoryDto = new MenuCategoryDto(menuCategory.getId(), menuCategory.getName()
        );

        return menuCategoryDto;
    }



    /**
     * Instantiate a StaffDto from an id received.
     * @param id of staff member
     * @return DTO representation of Staff
     */
    protected StaffDto convertToStaffDto(final long id)
    {
        StaffDto staffDto = new StaffDto(
                id
        );
        return staffDto;

    }

    /**
     * Create a REST representation of a Staff entity (StaffResponseDto)
     * @param staff instance to convert
     * @return REST DTO representation of Staff
     */
    protected StaffResponseDto convertStaffToStaffReponseDto(final Staff staff)
    {
        return new StaffResponseDto(staff.getId(), staff.getFirstName(), staff.getLastName(), staff.getEmail());
    }
    /**
     * Create a Staff DTO entity from a Staff Registration JSON request
     * @param staffRegrequest StaffRegistrationRequestDto instance to convert
     * @return Internal DTO representation of a Staff entity
     */
    protected StaffDto convertStaffRegRequestToStaffDto(final StaffRegistrationRequestDto staffRegrequest)
    {
        StaffDto staffDto = new StaffDto(
                staffRegrequest.getFirstName(),
                staffRegrequest.getLastName(),
                staffRegrequest.getEmail(),
                staffRegrequest.getPassword()
        );
        return staffDto;
    }

    /**
     * Create a Staff DTO entity from a Staff update JSON request
     * @param staffUpdateRequestDto staff details to update
     * @param id of staff member
     * @return DTO representation of Staff
     */
//    protected StaffDto convertToStaffDto(final StaffUpdateRequestDto staffUpdateRequestDto, final long id)
//    {
//        StaffDto staffDto = new StaffDto(
//                staffUpdateRequestDto.getFirstName(),
//                staffUpdateRequestDto.getLastName()
//        );
//        return staffDto;
//    }

    /**
     * Create a JSON response StaffResponseDto
     * @param staff staff details to convert
     * @return JSON response with Staff entity details
     */
    protected StaffResponseDto convertToStaffResponseDto(final Staff staff)
    {
        return new StaffResponseDto(staff.getId(), staff.getFirstName(), staff.getLastName(), staff.getEmail());
    }


    /**
     * Create a DTO representing New MenuItem entity request.
     * @param menuItemRequestDto new menu item details
     * @param id menu item
     * @return representation of a MenuItem entity
     */
    protected MenuItemDto convertToMenuItemDto(final MenuItemRequestDto menuItemRequestDto, final long id)
    {
        MenuItemDto menuItemDto = new MenuItemDto(
                id,
                menuItemRequestDto.getName(),
                menuItemRequestDto.getPrice(),
                menuItemRequestDto.getImageUrl(),
                menuItemRequestDto.getDescription()

        );

        return menuItemDto;

    }


    /**
     * Create a DTO representing updated MenuCategory entity.
     * @param menuCategoryUpdateRequest MenuCategory entity to update.
     * @param id MenuCategory entity id
     * @return DTO representing the MenuCategory entity
     */
    protected MenuCategoryDto convertToMenuCategoryDto(final MenuCategoryUpdateRequest menuCategoryUpdateRequest, final long id)
    {
        MenuCategoryDto menuCategoryDto = new MenuCategoryDto(
                id,
                menuCategoryUpdateRequest.getName()
        );
        return menuCategoryDto;
    }


    /**
     * Create a DTO representing the MenuItem entity requested.
     * @param menuItemRequestDto MenuItem entity details
     * @return representation of a MenuItem entity
     */
    protected MenuItemDto convertToMenuItemDto(final MenuItemRequestDto menuItemRequestDto)
    {
        return new MenuItemDto((long) 0, menuItemRequestDto.getName(), menuItemRequestDto.getPrice(), menuItemRequestDto.getImageUrl(), menuItemRequestDto.getDescription());
    }

    /**
     * Create a DTO representing the MenuItem entity requested.
     * @param menuItemRequestDto MenuItem entity details
     * @return representation of a MenuItem entity
     */
    protected MenuCategoryDto convertToMenuCategoryDto(final MenuItemRequestDto menuItemRequestDto)
    {
        return new MenuCategoryDto(menuItemRequestDto.getMenuCategoryId(), "");
    }

    /**
     * Create a DTO representing the Customer entity requested.
     * @param id of Customer entity
     * @return DTO representing the Customer
     */
    protected CustomerDto convertToCustomerDto(final long id)
    {
        return new CustomerDto(id);
    }

    /**
     * Create a DTO representing the Customer entity.
     * @param customer details
     * @return DTO representing the Customer
     */
    protected CustomerDto convertToCustomerDto(final Customer customer)
    {
        return new CustomerDto(customer.getId(), customer.getEmail(),customer.getFirstName(), customer.getLastName());
    }

    /**
     * Create a DTO representing an Order entity.
     * @param id requested order entity
     * @return DTO representing
     */
    protected OrderDto convertToOrderDto(final long id)
    {
        return new OrderDto(id);
    }

    /**
     * Create a REST DTO representing an Order entity.
     * @param order order entity details to convert
     * @return REST DTO representing an Order entity
     */
    protected OrderResponseDto convertToOrderResponseDto(final Order order)
    {
        return new OrderResponseDto(

                this.convertToOrderDto(order),
                this.convertToCustomerDto(order),
                new SimpleDateFormat(PATTERN_RESPONSE).format(order.getDateCreated())
                ,new SimpleDateFormat(PATTERN_RESPONSE).format(order.getLastUpdated()));

    }

    /**
     * Create a DTO representing an Order entity to update.
     * @param orderUpdateRequest order entity details to update
     * @return DTO representing an Order entity
     */
    protected OrderDto convertToOrderDto(final OrderUpdateRequest orderUpdateRequest)
    {

        if(EnumUtils.findEnumInsensitiveCase(Order.OrderStatus.class, orderUpdateRequest.getStatus().name()) == null)
            {
                throw new IllegalArgumentException("No such Status");
            }

        return new OrderDto(
                orderUpdateRequest.getId(),
                orderUpdateRequest.getStatus()
        );
    }

    /**
     * Helper method to validate & return an Order Status
     * @param status string from query parameter representing an order status
     * @return
     */
    protected Order.OrderStatus convertToOrderStatus(final String status)
    {
        if(status.chars().allMatch(Character::isAlphabetic)) //Validate
            {
                try
                    {
                        return EnumUtils.findEnumInsensitiveCase(Order.OrderStatus.class,status);
                    }
                    catch (IllegalArgumentException exception)
                        {
                            throw new IllegalArgumentException("No such status");
                        }

            }
        throw new IllegalArgumentException("No such status");
    }

    /**
     * Helper function to convert date query received
     * @param stringDate string to parse as date
     * @return Date representing the parsed String
     */
    protected Date convertToDateFormat(final String stringDate)
    {
        SimpleDateFormat formatter = new SimpleDateFormat(PATTERN_REQUEST);
        try
            {
                Date date =  formatter.parse(stringDate);
                return date;
            } catch (ParseException e)
            {
                throw new IllegalArgumentException("No such date. Check Format");
            }
    }

    /**
     * Helper function to convert date query received
     * @param s string to parse as date
     * @param i offset in days
     * @return Offset Date
     */
    protected Date convertAndOffsetDate(final String s, final int i)
    {

        OffsetDateTime offsetDateTime = OffsetDateTime.parse(s + " 11:59:59");
        offsetDateTime.plusDays(i);
        return Date.from(offsetDateTime.toInstant());
    }

    /**
     * Create DTO representing a Staff Entity
     * @param staff entity
     * @return  DTO representing a Staff Entity
     */
    protected StaffDto convertToStaffDto(final Staff staff)
    {
        return new StaffDto(staff.getEmail(), staff.getId());
    }
    /**
     * Create DTO representing a Token Entity
     * @param tokenRequest string received from parameter
     * @return  DTO representing a Token Entity
     */
    protected TokenDto convertToTokenDto(final String tokenRequest)
    {
        TokenDto token = new TokenDto(tokenRequest);
        if (!verifyToken(token))
            {
                throw new IllegalStateException("Invalid Token");
            }
        return token;

    }

    private boolean verifyToken(final TokenDto tokenDto)
    {
        String username = Jwts.parser()
                .setSigningKey(ConstantsUtil.TOKEN_SECRET)
                .parseClaimsJws(tokenDto.getToken())
                .getBody()
                .getSubject();
        if (username == null)
            {
                throw new IllegalStateException("Invalid Token");
            }

        return true;
    }

    /**
     *
     * @param email
     * @return
     */
    protected StaffDto convertToStaffDto(final String email)
    {
        return new StaffDto(email, true);
    }

    /**
     * Create a RestaurantHours DTO entity from a new RestaurantHours request
     * @param restaurantHoursRequest new RestaurantHours request
     * @return DTO representation of a RestaurantHours entity
     */
    protected RestaurantHoursDto convertToRestaurantHoursDto(final RestaurantHoursRequest restaurantHoursRequest)
    {
        RestaurantHoursDto restaurantHoursDto;
        try
            {
                DayOfWeek dayOfWeek = DayOfWeek.of(restaurantHoursRequest.getDayOfWeek());
                LocalTime openTime = LocalTime.parse(restaurantHoursRequest.getOpen());
                LocalTime closeTime = LocalTime.parse(restaurantHoursRequest.getClose());
                restaurantHoursDto = new RestaurantHoursDto(dayOfWeek, openTime, closeTime);
            } catch (RuntimeException exception)
            {
                throw new IllegalArgumentException("Invalid input.");
            }
        return restaurantHoursDto;
    }

    /**
     * Helper method to validate String received representing a Role
     * @param role string from query parameter
     * @param roles Set of all Role entity
     * @return true if found; false
     */
    protected boolean verifyRoles(final String role, final Set<StaffRole> roles)
    {

        return roles.stream().anyMatch(staffRole -> staffRole.getName().compareToIgnoreCase(ROLE_PREFIX + role) == 0);
    }

    /**
     * Helper method to convert String parameter from request to internal ROLE String
     * @param role
     * @return
     */
    protected String convertToRole(final String role)
    {
        return ROLE_PREFIX + role;
    }
    /**
     * Create a Staff DTO entity from a Staff update JSON request
     * @param staffUpdateRequestDto staff details to update
     * @param id of staff member
     * @return DTO representation of Staff
     */
    protected StaffDto convertToStaffDto(final StaffUpdateRequestDto staffUpdateRequestDto, final long id, final StaffRole staffRole)
    {
        return new StaffDto(
                staffUpdateRequestDto.getFirstName(),
                staffUpdateRequestDto.getLastName(),
                staffUpdateRequestDto.getEmail(),
                id,
                staffRole
        );
    }

    /**
     * Create a DTO representation of a Customer entity
     * @param customer entity to convert
     * @return DTO representation of a Customer entity
     */
    protected CustomerResponseDto convertCustomerToCustomerReponseDto(final Customer customer)
    {
        CustomerResponseDto customerResponseDto = new CustomerResponseDto(customer.getFirstName(), customer.getEmail(), customer.getId());
        return customerResponseDto;
    }
}
