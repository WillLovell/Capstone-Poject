package com.foodorder.crm;
import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffAuthority;
import com.foodorder.crm.entity.StaffRole;
import com.foodorder.crm.repositories.StaffAuthorityRepository;
import com.foodorder.crm.repositories.StaffRepository;
import com.foodorder.crm.repositories.StaffRoleRepository;
import com.foodorder.crm.security.Encryption;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Class to programmatically setup Staff Authority, Roles and default Admin User
 */
@Component
public class StaffSetup
{
        private StaffAuthorityRepository staffAuthorityRepository;
        private StaffRoleRepository staffRoleRepository;
        private StaffRepository staffRepository;
        private final Encryption encryption;


    private StaffSetup(final StaffAuthorityRepository staffAuthorityRepository, final StaffRoleRepository staffRoleRepository, final StaffRepository staffRepository, final Encryption encryption)
        {

            this.staffAuthorityRepository = staffAuthorityRepository;
            this.staffRoleRepository = staffRoleRepository;
            this.staffRepository = staffRepository;
            this.encryption = encryption;
        }

        @EventListener
        public void startApp(ApplicationReadyEvent applicationReadyEvent)
        {

            StaffAuthority readAuthority = createAuthority("READ_AUTHORITY");
            StaffAuthority writeAuthority = createAuthority("WRITE_AUTHORITY");
            StaffAuthority deleteAuthority = createAuthority("DELETE_AUTHORITY");
            StaffRole adminRole = createRole("ROLE_ADMIN", new HashSet<StaffAuthority>(Arrays.asList(readAuthority,writeAuthority, deleteAuthority)));
            StaffRole managerRole = createRole("ROLE_MANAGER", new HashSet<StaffAuthority>(Arrays.asList(readAuthority, writeAuthority, deleteAuthority)));
            StaffRole unassignedRole = createRole("ROLE_UNASSIGNED", new HashSet<StaffAuthority>(Arrays.asList()));
            createAdminUser();
        }

        private StaffAuthority createAuthority(String name)
        {
            //Make optional!
            StaffAuthority staffAuthority = staffAuthorityRepository.findByName(name);
            if(staffAuthority == null)
                {
                    staffAuthority = new StaffAuthority(name);
                    staffAuthorityRepository.save(staffAuthority);
                }
            return staffAuthority;
        }
        @Transactional
        StaffRole createRole(String name, Set<StaffAuthority> authoritySet)
        {
            //Make optional!
            StaffRole staffRole = staffRoleRepository.findByName(name);
            if(staffRole == null)
                {
                    staffRole = new StaffRole(name);
                    if(staffRole.getStaffAuthorities() == null)
                        {
                            Set<StaffAuthority> authorities = new HashSet<>();
                            authoritySet.forEach(auth -> authorities.add(auth));
                            staffRole.setAuthorities(authorities);
                        };
                    staffRoleRepository.save(staffRole);
                }
            return staffRole;
        }

        @Transactional
        void createAdminUser()
        {
            StaffRole role = staffRoleRepository.findByName("ROLE_ADMIN");
            String username = "restAdmin";
            Optional<Staff> admin = staffRepository.findStaffByEmail(username);
            if (!admin.isPresent())
                {
                    Staff staff = new Staff(
                          "John", "Smith", username, encryption.encode("password"), role);
                    staff.setStatus(true);
                    staffRepository.save(staff);
                }
            return;
        }
}


