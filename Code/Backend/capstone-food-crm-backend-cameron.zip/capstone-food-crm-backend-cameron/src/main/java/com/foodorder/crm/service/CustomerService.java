package com.foodorder.crm.service;


import com.foodorder.crm.dto.spring.CustomerDto;
import com.foodorder.crm.entity.Customer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * Interface used for interaction with the Customer repository
 */
@Service
public interface CustomerService
{
    /**
     * Retrieve requested Customer entity from DB
     * @param id of Customer
     * @return Customer
     */
    Customer getCustomer(Long id);

    /**
     * Retrieve all customers from the database
     * @return set of customers
     */
    Set<Customer> getAllCustomers();


}

