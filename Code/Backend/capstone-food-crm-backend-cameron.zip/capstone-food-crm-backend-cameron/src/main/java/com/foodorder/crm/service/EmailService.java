package com.foodorder.crm.service;

import com.foodorder.crm.dto.rest.OrderDto;
import com.foodorder.crm.dto.spring.CustomerDto;
import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.entity.StaffResetToken;
import com.foodorder.crm.entity.StaffVerifyToken;
import org.springframework.stereotype.Service;
/**
 * Interface used for sending emails
 */
@Service
public interface EmailService
{
    /**
     * Method to send confirmation email to user on registration
     * @param staffDto user info
     * @param staffVerifyToken verification token value
     * @return true if successful.
     */
    boolean sendConfirmationEmail(final StaffDto staffDto, final StaffVerifyToken staffVerifyToken);

    /**
     * Method to send confirmation email to user on registration
     * @param staffDto user info
     * @param staffResetToken reset token value
     * @return true if successful.
     */
    boolean sendReset(final StaffDto staffDto, final StaffResetToken staffResetToken);

    /**
     * Method to send order update email to user 
     * @param orderDto order information
     * @param customerDto customer information
     */
    void sendOrderUpdateToCustomer(final OrderDto orderDto, final CustomerDto customerDto);
}
