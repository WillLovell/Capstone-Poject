package com.foodorder.crm.dto.rest;

/**
 * Data Transfer Class used for REST Request to delete/deactivate User entity
 */
public class StaffDeleteRequest
{
    private final long id;
    private final boolean deactivate;
    private final boolean delete;

    public StaffDeleteRequest(final long id, final boolean deactivate, final boolean delete)
    {
        this.id = id;
        this.deactivate = deactivate;
        this.delete = delete;
    }

    public long getId()
    {
        return id;
    }

    public boolean isDeactivate()
    {
        return deactivate;
    }

    public boolean isDelete()
    {
        return delete;
    }
}
