package com.foodorder.crm.controller;

import com.foodorder.crm.dto.rest.RestaurantHoursDto;
import com.foodorder.crm.dto.rest.RestaurantHoursRequest;
import com.foodorder.crm.security.ConstantsUtil;
import com.foodorder.crm.service.RestaurantHoursService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * API RestController for operations relating to RestaurantHours
 */

@CrossOrigin(ConstantsUtil.UI_URL)
@RestController
@RequestMapping("/dashboard/hours")

public class RestaurantHoursController
{
    private RestaurantHoursService restaurantHoursService;
    private ControllerUtils controllerUtils;
    @Autowired
    private RestaurantHoursController(final RestaurantHoursService restaurantHoursService, final ControllerUtils controllerUtils)
    {
        this.restaurantHoursService = restaurantHoursService;
        this.controllerUtils = controllerUtils;
    }

    /**
     * Api endpoint to create new restaurant hours.
     * @param restaurantHoursRequest details for new restaurant hours
     */
    @PostMapping
    public void createHours(@RequestBody RestaurantHoursRequest restaurantHoursRequest)
    {
        RestaurantHoursDto restaurantHoursDto = controllerUtils.convertToRestaurantHoursDto(restaurantHoursRequest);
        restaurantHoursService.createRestaurantHours(restaurantHoursDto);
    }

    /**
     * Api endpoint to update restaurant hours.
     * @param restaurantHoursRequest
     */
    @PutMapping
    public void updateHours(@RequestBody RestaurantHoursRequest restaurantHoursRequest)
    {
        RestaurantHoursDto restaurantHoursDto = controllerUtils.convertToRestaurantHoursDto(restaurantHoursRequest);
        restaurantHoursService.updateHours(restaurantHoursDto);
    }

}
