/**
 * Main package for content management system.
 */
package com.foodorder.crm;