package com.foodorder.crm.repositories;

import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffVerifyToken;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
/**
 * Extension of the CrudRepository used for the persistence of a StaffVerifyToken entity
 */
@Repository
public interface StaffVerifyTokenRepository extends CrudRepository<StaffVerifyToken, Long>
{
    StaffVerifyToken findStaffVerifyTokenByStaff(final Staff staff);
    StaffVerifyToken findStaffVerifyTokensByToken(final String token);
}
