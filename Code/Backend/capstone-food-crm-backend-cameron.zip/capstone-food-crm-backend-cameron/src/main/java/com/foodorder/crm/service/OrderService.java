package com.foodorder.crm.service;

import com.foodorder.crm.dto.rest.OrderDto;
import com.foodorder.crm.dto.spring.CustomerDto;
import com.foodorder.crm.entity.Order;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Set;
/**
 * Interface used for interaction with the Order repository
 */
@Service
public interface OrderService
{
    /**
     * Method to retrieve all  orders
     * @return all orders
     */
    Set<Order> getAllOrders();

    /**
     * Method to retrieve an Order
     * @param id of order to retrieve
     * @return queried Order
     */
    Order getOrderById(long id);

    /**
     * Method to retrieve Orders for a given customer
     * @param customerDto customer's details
     * @return set of orders
     */
    Set<Order> getOrdersByCustomer(CustomerDto customerDto);

    /**
     * Method to retrieve Orders for a given order status
     * @param orderStatus status queried
     * @return set of orders
     */
    Set<Order> getOrdersByStatus(Order.OrderStatus orderStatus);

    /**
     * Method to retrieve Orders for a given date
     * @param date queried
     * @return set of orders
     */
    Set<Order> getOrdersByDate(Date date);

    /**
     * Method to update an Order's status
     * @param orderDto order to update with status
     * @return updated order
     */
    Order updateOrderStatus(OrderDto orderDto);
    /**
     * Method to retrieve Orders for a given date range
     * @param from,to queried dates
     * @return set of orders
     */
    Set<Order> getOrdersBetweenDates(Date from, Date to);

}
