package com.foodorder.crm.controller;


import com.foodorder.crm.dto.rest.*;
import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffRole;
import com.foodorder.crm.entity.StaffVerifyToken;
import com.foodorder.crm.security.ConstantsUtil;
import com.foodorder.crm.service.EmailService;
import com.foodorder.crm.service.StaffService;
import com.foodorder.crm.service.StaffTokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.HashSet;
import java.util.Set;
/**
 * API RestController for operations relating to Staff users
 */
@CrossOrigin(ConstantsUtil.UI_URL)
@RestController
@RequestMapping("/dashboard/staff")

public class StaffController
{
    private ControllerUtils controllerUtils;
    private StaffService staffService;
    private EmailService emailService;
    private StaffTokenService staffTokenService;

    @Autowired
    public StaffController(ControllerUtils controllerUtils, StaffService staffService, final EmailService emailService, final StaffTokenService staffTokenService)
    {
        this.controllerUtils = controllerUtils;
        this.staffService = staffService;
        this.emailService = emailService;
        this.staffTokenService = staffTokenService;
    }

    /**
     * Api endpoint to retrieve Staff entity details
     * @param id for requested Staff entity
     * @return DTO representing Staff
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/{id}")
    public ResponseEntity<StaffResponseDto> getStaff(@PathVariable long id)
    {
        StaffDto staffDto = controllerUtils.convertToStaffDto(id);
        System.out.println("StaffDto" + staffDto.getId());
        Staff staff = staffService.getStaffById(staffDto.getId());
        System.out.println(staff);
        StaffResponseDto staffResponseDto = controllerUtils.convertStaffToStaffReponseDto(staff);
        return ResponseEntity.ok().body(staffResponseDto);
    }

    /**
     * Api endpoint to create new Staff entity
     * @param staffRegistrationRequestDto details for new Staff entity
     * @return DTO representing Staff
     */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<StaffResponseDto> createStaff(@RequestBody StaffRegistrationRequestDto staffRegistrationRequestDto)
    {
        StaffDto staffDto = controllerUtils.convertStaffRegRequestToStaffDto(staffRegistrationRequestDto);
        Staff staff = staffService.createStaff(staffDto);
        StaffDto staffDto1 = controllerUtils.convertToStaffDto(staff);
        if (staff != null)
            {
                StaffVerifyToken staffVerifyToken = staffTokenService.getVerificationToken(staffDto1);
                emailService.sendConfirmationEmail(staffDto1, staffVerifyToken);

            }
        StaffResponseDto staffResponseDto = controllerUtils.convertStaffToStaffReponseDto(staff);
        return ResponseEntity.ok().body(staffResponseDto);
    }
    /**
     * Api endpoint to update given Staff entity
     * @param staffUpdateRequestDto details for Staff entity to update
     * @param id for Staff entity to update
     * @return DTO representing Staff
     */
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<StaffResponseDto> updateStaff(@PathVariable long id, @RequestBody StaffUpdateRequestDto staffUpdateRequestDto)
    {

        Set<StaffRole> roles = staffService.getRoles();
        if(!controllerUtils.verifyRoles(staffUpdateRequestDto.getRole(), roles))
            {
                throw new IllegalArgumentException("Incorrect Details Provided");
            }
        String role = controllerUtils.convertToRole(staffUpdateRequestDto.getRole());
        StaffRole staffRole = staffService.getRole(role);
        StaffDto staffDto = controllerUtils.convertToStaffDto(staffUpdateRequestDto, id, staffRole);
        try
            {
                Staff updatedStaff = staffService.updateStaff(staffDto);
                if(updatedStaff==null)
                    {
                        throw new IllegalStateException("Error");

                    }
                StaffResponseDto staffResponseDto = controllerUtils.convertToStaffResponseDto(updatedStaff);
                return new ResponseEntity<StaffResponseDto>(staffResponseDto, HttpStatus.OK);
            }
            catch (RuntimeException ex)
                {
                    throw new IllegalStateException("Eroor");
                }
    }

    /**
     * Api endpoint to delete or deactivate given Staff entity
     * @param staffDeleteRequest boolean fields to select delete or deactivate
     * @return true if success
     */
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping
    public ResponseEntity<Boolean> deactivateStaff(@RequestBody StaffDeleteRequest staffDeleteRequest)
    {
        final long id = staffDeleteRequest.getId();
        final boolean delete = staffDeleteRequest.isDelete();
        final boolean deactivate = staffDeleteRequest.isDeactivate();
        boolean result = staffService.deleteStaff(id,delete,deactivate);
        return new ResponseEntity<Boolean>(true, HttpStatus.OK);
    }
    /**
     * Api endpoint to retrieve all Staff entities
     * @return Set of DTO representing Staff
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/")
    public ResponseEntity<Set<StaffResponseDto>> getStaff()
    {
        Set<Staff> staffSet = staffService.getAllStaff();
        Set<StaffResponseDto> staffResponseDto = new HashSet<>();
        staffSet.stream().forEach(staff -> staffResponseDto.add(
                controllerUtils.convertStaffToStaffReponseDto(staff)));
        return ResponseEntity.ok().body(staffResponseDto);
    }
}
