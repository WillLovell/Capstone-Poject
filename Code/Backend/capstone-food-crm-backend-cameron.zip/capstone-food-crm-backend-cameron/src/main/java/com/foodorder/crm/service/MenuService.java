package com.foodorder.crm.service;

import com.foodorder.crm.dto.spring.MenuCategoryDto;
import com.foodorder.crm.dto.spring.MenuItemDto;
import com.foodorder.crm.entity.MenuCategory;
import com.foodorder.crm.entity.MenuItem;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Set;

/**
 * MenuService used for the retrieval of Menu Items and their categories
 */
@Service
public interface MenuService
{
    /**
     * Retrieve all active menu items
     * @return list of all active menu items
     */
    List<MenuItem> getAllMenuItems();

    /**
     * Retrieve specific menu item
     * @param id of menu item to retrieve
     * @return requested menu Item
     */
    MenuItem getMenuItem(long id);

    /**
     * Retrieve all menu items for a given menu category
     * @return List of Menu Items for given Menu Category
     */
    Set<MenuCategory> getAllMenuCategories();

    /**
     * Retrieve details for a given menu category
     * @param id of menu category
     * @return
     */
    MenuCategory getMenuCategoryDetails(final long id);

    /**
     * Update a Menu Category
     * @param menuCategoryDto details to update
     * @return the updated menu category
     */
    MenuCategory updateMenuCategoryDetails(MenuCategoryDto menuCategoryDto);

    /**
     * Method to update a MenuItem
     * @param menuItemDto details to update
     * @param status new item status
     * @param menuCategoryId id of menu item
     * @return the updated menu item
     */
    MenuItem updateMenuItem(MenuItemDto menuItemDto, boolean status, long menuCategoryId);

    /**
     * Method to create a new MenuItem
     * @param menuItemDto menu items details
     * @param menuCategoryDto menu item's MenuCategory
     * @return newly created MenuItem
     */
    MenuItem createMenuItem(MenuItemDto menuItemDto, final MenuCategoryDto menuCategoryDto);

    /**
     * Method to delete a MenuItem
     * @param menuItemDto menu items details
     * @return true on success
     */
    boolean deleteMenuItem(MenuItemDto menuItemDto);
}
