package com.foodorder.crm.dto.spring;

import com.foodorder.crm.entity.StaffRole;

import java.io.Serializable;

/**
 * Data Transfer Object (DTO) Class used to transfer data between Spring Classes.
 * StaffDto represent a Staff entity
 */
public class StaffDto implements Serializable
{
    private static final long serialVersionUID = -4895514271875089167L;
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private boolean status;
    private StaffRole staffRole;

    public StaffDto(final String firstName, final String lastName, final String email, final String password)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
    }

    public StaffDto(final String firstName, final String lastName, final String email, final long id, StaffRole staffRole)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.id = id;
        this.staffRole = staffRole;
    }

    public StaffDto(final Long id)
    {
        this.id = id;
    }

    public StaffDto(final String firstName, final String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public StaffDto(final String email, final long id)
    {
        this.email = email;
        this.id = id;
    }

    public StaffDto(final String email)
    {
        this.email = email;
    }

    public StaffDto(final String email, final boolean b)
    {
        this.email = email;
        this.status = b;
    }

    public Long getId()
    {
        return id;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public String getEmail()
    {
        return email;
    }

    public String getPassword()
    {
        return password;
    }

    public boolean isStatus()
    {
        return status;
    }

    public StaffRole getStaffRole()
    {
        return staffRole;
    }
}
