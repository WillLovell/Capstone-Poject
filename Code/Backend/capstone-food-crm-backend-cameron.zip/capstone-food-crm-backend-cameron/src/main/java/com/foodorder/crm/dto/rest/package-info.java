/**
 * Data Transfer Object Classes used for REST request, response
 */
package com.foodorder.crm.dto.rest;