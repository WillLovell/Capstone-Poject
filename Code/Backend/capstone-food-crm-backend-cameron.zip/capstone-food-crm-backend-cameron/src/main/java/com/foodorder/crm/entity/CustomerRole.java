package com.foodorder.crm.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

/**
 * CustomerRole persisted to Database.
 */
@Entity
@Table()
public class CustomerRole implements Serializable
{
    private static final long serialVersionUID = 4546687545928054373L;
    @Id
    @Column(name = "id")
    @GeneratedValue(generator="CUSTOMER_ROLE_SEQ",strategy=GenerationType.SEQUENCE)
    private long id;
    @Column(nullable = false, unique = true)
    private String name;

    @OneToMany(mappedBy = "role")
    private Set<Customer> customers;

    @ManyToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
    @JoinTable(
            name = "customer_authorities",
            joinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "authority_id", referencedColumnName = "id")
    )
    private Set<CustomerAuthority> authorities;

    public CustomerRole(final String name)
    {
        this.name = name;
    }

    public CustomerRole()
    {

    }



    public long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public Set<Customer> getCustomers()
    {
        return customers;
    }

    public Set<CustomerAuthority> getCustomerAuthorities()
    {
        return authorities;
    }

    public void setAuthorities(final Set<CustomerAuthority> authorities)
    {
        this.authorities = authorities;
    }
}