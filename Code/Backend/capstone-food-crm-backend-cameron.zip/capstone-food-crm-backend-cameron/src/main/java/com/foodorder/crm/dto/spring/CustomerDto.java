package com.foodorder.crm.dto.spring;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 * Data Transfer Object (DTO) Class used to transfer data between Spring Classes.
 * CustomerDto represent a Customer Entity
 */

public class CustomerDto implements Serializable
{

    private static final long serialVersionUID = 2455668227386990112L;
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    @JsonIgnore
    private String password;


    public CustomerDto(final String firstName, final String lastName, final String email, final String password, final String encryptedPassword)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;

    }

    public CustomerDto(final Long id, final String firstName, final String lastName)
    {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public CustomerDto(final String firstName, final String email, final String password)
    {
        this.firstName = firstName;
        this.email = email;
        this.password = password;
    }

    public CustomerDto(final String firstName, final String email)
    {
        this.firstName = firstName;
        this.email = email;
        this.password = password;
    }
    @JsonCreator
    public CustomerDto(@JsonProperty("id") final Long id)
    {
        this.id = id;
    }

    public CustomerDto(final long id, final String email, final String firstName, final String lastName)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.id = id;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public String getEmail()
    {
        return email;
    }

    public String getPassword()
    {
        return password;
    }

    public Long getId()
    {
        return id;
    }
}
