package com.foodorder.crm.entity;

import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * User entity representing restaurant Staff
 */
@Entity
@Table()
@Getter
public class Staff
{
    @Id
    @GeneratedValue(generator="STAFF_SEQ",strategy=GenerationType.SEQUENCE)
    @Column(name="id")
    private Long id;

    @Column(name="first_name", nullable = false)
    private String firstName;

    @Column(name="last_name", nullable = false)
    private String lastName;

    @Column(name="email", unique = true, updatable = true)
    private String email;

    @Column(name="password", nullable = false)
    private String protectedPassword;

    @Column(name="status", nullable = false)
    private boolean status;

    @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
    private StaffRole role;

    public Staff()
    {

    }

    public Staff(final String firstName, final String lastName, final String email, final String password,  final StaffRole staffRole)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.protectedPassword = password;
        this.status = false;
        this.role = staffRole;
    }

    public String getProtectedPassword()
    {
        return protectedPassword;
    }

    private Set<StaffAuthority> getAuthorities()
    {
        return getRole().getStaffAuthorities();
    }

    public Set<GrantedAuthority> getGrantedAuthorities()
    {
        Set<GrantedAuthority> grantedAuthoritySet = new HashSet<>();
        getAuthorities().forEach(auth ->
                grantedAuthoritySet.add(new SimpleGrantedAuthority(auth.getName()))
        );
        return grantedAuthoritySet;
    }

    public void setStatus(final boolean status)
    {
        this.status = status;
    }

    public void setProtectedPassword(final String protectedPassword)
    {
        this.protectedPassword = protectedPassword;
    }
}
