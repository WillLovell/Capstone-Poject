/**
 * Data Transfer Object Classes used for internal transfer of data
 */
package com.foodorder.crm.dto.spring;