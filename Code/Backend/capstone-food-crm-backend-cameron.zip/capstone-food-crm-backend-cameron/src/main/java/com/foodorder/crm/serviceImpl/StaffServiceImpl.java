package com.foodorder.crm.serviceImpl;
import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.dto.spring.TokenDto;
import com.foodorder.crm.entity.Customer;
import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffRole;
import com.foodorder.crm.entity.StaffVerifyToken;
import com.foodorder.crm.repositories.StaffRepository;
import com.foodorder.crm.repositories.StaffRoleRepository;
import com.foodorder.crm.repositories.StaffVerifyTokenRepository;
import com.foodorder.crm.security.Encryption;
import com.foodorder.crm.security.PrincipalStaff;
import com.foodorder.crm.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Component
/**
 * Implementation of the StaffService interface.
 */
public class StaffServiceImpl implements StaffService
{
    private final Encryption encryption;
    private final StaffRepository staffRepository;
    private final StaffRoleRepository staffRoleRepository;
    private final StaffVerifyTokenRepository staffVerifyTokenRepository;


    @Autowired
    public StaffServiceImpl(final Encryption encryption, final StaffRepository staffRepository, final StaffRoleRepository staffRoleRepository, final StaffVerifyTokenRepository staffVerifyTokenRepository)
    {
        this.encryption = encryption;
        this.staffRepository = staffRepository;
        this.staffRoleRepository = staffRoleRepository;
        this.staffVerifyTokenRepository = staffVerifyTokenRepository;
    }

    @Override
    public Staff getStaffById(final Long id)
    {

        Optional<Staff> optionalStaff = staffRepository.findById(id);
        if(optionalStaff.isPresent())
            {
                return optionalStaff.get();
            }
        throw new IllegalStateException("No such staff member");

    }

    @Override
    public Staff getStaffByEmail(final String email)
    {
        Optional<Staff> optionalStaff = staffRepository.findStaffByEmail(email);
        if(optionalStaff.isPresent())
            {
                return optionalStaff.get();
            }
        throw new IllegalStateException("No such staff member");
    }
    @Modifying
    @Transactional
    @Override
    public Staff updateStaff(final StaffDto staffDto)
    {
        Optional<Staff> staffCheck = staffRepository.findById(staffDto.getId());

        if(!staffCheck.isPresent())
            {
                throw new IllegalStateException("No such staff");
            }
        else
        {
            if (!staffCheck.get().isStatus())
                {
                    throw new IllegalStateException("Staff inactive");
                }
            staffRepository.updateStaff(
                    staffDto.getFirstName(),
                    staffDto.getLastName(),
                    staffDto.getEmail(),
                    staffDto.getStaffRole(),
                    staffDto.getId());
        }

        return staffRepository.findById(staffDto.getId()).get();

    }

    @Override
    public Staff confirmStaff(final StaffDto staffDto)
    {
        Optional<Staff> staffCheck = staffRepository.findStaffByEmail(staffDto.getEmail());
        if(!staffCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        Staff staff = staffCheck.get();
        staff.setStatus(true);
        staffRepository.save(staff);
        return staff;
    }
    @Transactional
    @Override
    public Staff createStaff(final StaffDto staffDto)
    {
        Optional<Staff> staffCheck = staffRepository.findStaffByEmail(staffDto.getEmail());

        if(staffCheck.isPresent())
            {
                throw new IllegalStateException("Staff already exists");
            }
        StaffRole staffRole = staffRoleRepository.findByName("ROLE_UNASSIGNED");
        Staff staff = new Staff(
                staffDto.getFirstName(),
                staffDto.getLastName(),
                staffDto.getEmail(),
                encryption.encode(staffDto.getPassword()),
                staffRole
        );

        StaffVerifyToken staffVerifyToken = new StaffVerifyToken(staff);
        staffRepository.save(staff);
        staffVerifyTokenRepository.save(staffVerifyToken);

        System.out.println("STAFF MEMBER CREATED");
        return staff;
    }

    @Override
    @Transactional
    public Boolean deleteStaff(final long id, final boolean delete, final boolean deactivate)
    {
        Staff staff = this.getStaffById(id);
        if(delete)
            {
                staffRepository.delete(staff);
                System.out.println("deleted");
                return true;
            }
        else if(delete == false && deactivate ==true)
            {
//                Staff newStaff = new Staff(staff.getFirstName(),
//                        staff.getLastName(),
//                        staff.getEmail(),
//                        staff.getProtectedPassword(),
//                        staff.getRole());
//
//                staffRepository.delete(staff);
                staff.setStatus(false);
                staffRepository.save(staff);
                System.out.println("deactivated");
                return true;
            }
        return false;
    }

    @Override
    public Staff resetPassword(final StaffDto staffDto, final String password)
    {
        Optional<Staff> staffCheck = staffRepository.findStaffByEmail(staffDto.getEmail());
        if(!staffCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        staffCheck.get().setProtectedPassword(encryption.encode(password));
        staffRepository.save(staffCheck.get());
        return staffCheck.get();
    }

    @Override
    public Set<StaffRole> getRoles()
    {
        Set<StaffRole> staffRoleSet = new HashSet<>();
        final Iterator<StaffRole> iterator = staffRoleRepository.findAll().iterator();
        while (iterator.hasNext())
            {
                staffRoleSet.add(iterator.next());
            }
        return staffRoleSet;
    }

    @Override
    public StaffRole getRole(final String role)
    {
        Optional<StaffRole> roleCheck = Optional.ofNullable(staffRoleRepository.findByName(role));
        if(!roleCheck.isPresent())
            {
                throw new IllegalArgumentException("Invalid details Provided");
            }
        return roleCheck.get();
    }

    @Override
    public Set<Staff> getAllStaff()
    {
        Set<Staff> staffSet = StreamSupport.stream(staffRepository.findAll().spliterator(),false).collect(Collectors.toSet());
        return staffSet;
    }


    @Override
    public UserDetails loadUserByUsername(final String email) throws UsernameNotFoundException
    {
        Optional<Staff> staffCheck = staffRepository.findStaffByEmail(email);
        if(!staffCheck.isPresent())
            {
                throw new UsernameNotFoundException("Incorrect Details Provided");
            }
        Staff staff = staffCheck.get();
        PrincipalStaff principalStaff = new PrincipalStaff(staff.getEmail(), staff.getProtectedPassword(), staff.getGrantedAuthorities(), staff.getId(), staff.isStatus());
        return principalStaff;
    }
}
