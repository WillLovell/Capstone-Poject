package com.foodorder.crm.serviceImpl;

import com.foodorder.crm.entity.Customer;
import com.foodorder.crm.repositories.CustomerRepository;
import com.foodorder.crm.security.Encryption;
import com.foodorder.crm.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Implementation of the CustomerService interface.
 */
@Component
public class CustomerServiceImpl implements CustomerService
{
    private Encryption encryption;
    private CustomerRepository customerRepository;

    @Autowired
    private CustomerServiceImpl(final CustomerRepository customerRepository, final Encryption encryption)
    {
        this.customerRepository = customerRepository;
        this.encryption = encryption;
    }

    @Override
    public Customer getCustomer(final Long id)
    {
        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        if(optionalCustomer.isPresent())
            {
                return optionalCustomer.get();
            }
        throw new IllegalStateException("No such Customer");
    }
//
//    @Override
//    public Customer updateCustomer(final CustomerDto customerUpdateRequest)
//    {
//        Optional<Customer> customerCheck = customerRepository.findById(customerUpdateRequest.getId());
//        if(!customerCheck.isPresent())
//            {
//                throw new UsernameNotFoundException("Incorrect Details Provided");
//            }
//
//        customerRepository.updateCustomer(
//                customerUpdateRequest.getFirstName(),
//                customerUpdateRequest.getLastName(),
//                customerUpdateRequest.getId());
//        return customerRepository.findById(customerUpdateRequest.getId()).get();
//    }

    @Override
    public Set<Customer> getAllCustomers()
    {
        Set<Customer> customers = StreamSupport.stream(customerRepository.findAll().spliterator(),false).collect(Collectors.toSet());
        return customers;

    }

}
