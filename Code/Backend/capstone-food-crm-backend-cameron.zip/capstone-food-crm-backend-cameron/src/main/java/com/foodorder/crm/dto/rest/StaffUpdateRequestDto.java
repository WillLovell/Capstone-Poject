package com.foodorder.crm.dto.rest;

/**
 * Data Transfer Class used for REST Request to update an existing User entity
 */
public class StaffUpdateRequestDto
{
    private String firstName;
    private String email;
    private String lastName;
    private String role;

    public StaffUpdateRequestDto(final String firstName, final String email, final String lastName, final String role)
    {
        this.firstName = firstName;
        this.email = email;
        this.lastName = lastName;
        this.role = role;
    }


    public String getFirstName()
    {
        return firstName;
    }

    public String getEmail()
    {
        return email;
    }

    public String getLastName()
    {
        return lastName;
    }

    public String getRole()
    {
        return role;
    }
}
