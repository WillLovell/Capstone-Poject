package com.foodorder.crm.dto.spring;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Data Transfer Object (DTO) Class used to transfer data between Spring Classes.
 * MenuItemDto represent a MenuItem entity
 */
@Data
public class MenuItemDto implements Serializable
{
    private  Long id;
    private  String name;
    private  BigDecimal price;
    private  String  imageUrl;
    private  String description;
    private MenuCategoryDto menuCategory;


    public MenuItemDto(final Long id, final String name, final BigDecimal price, final String imageUrl, final String description, MenuCategoryDto menuCategory)
    {
        this.id = id;
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
        this.menuCategory = menuCategory;
    }

    public MenuItemDto(final Long id, final String name, final BigDecimal price, final String imageUrl, final String description)
    {
        this.id = id;
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
    }

    public MenuItemDto(final long id)
    {
        this.id = id;
    }
}
