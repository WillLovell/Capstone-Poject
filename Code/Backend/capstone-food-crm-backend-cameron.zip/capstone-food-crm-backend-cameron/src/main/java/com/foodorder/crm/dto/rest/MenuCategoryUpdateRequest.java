package com.foodorder.crm.dto.rest;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
/**
 * Data Transfer Class used for REST Request
 */
@Data
public class MenuCategoryUpdateRequest
{
    private String name;
    @JsonCreator
    public MenuCategoryUpdateRequest(@JsonProperty("name") final String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
}
