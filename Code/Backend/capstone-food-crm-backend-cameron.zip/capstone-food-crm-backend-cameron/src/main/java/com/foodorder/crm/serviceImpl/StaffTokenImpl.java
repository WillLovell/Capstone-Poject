package com.foodorder.crm.serviceImpl;

import com.foodorder.crm.dto.spring.StaffDto;
import com.foodorder.crm.dto.spring.TokenDto;
import com.foodorder.crm.entity.Staff;
import com.foodorder.crm.entity.StaffResetToken;
import com.foodorder.crm.entity.StaffVerifyToken;
import com.foodorder.crm.repositories.StaffRepository;
import com.foodorder.crm.repositories.StaffResetTokenRepository;
import com.foodorder.crm.repositories.StaffVerifyTokenRepository;
import com.foodorder.crm.security.ConstantsUtil;
import com.foodorder.crm.service.StaffTokenService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Optional;
@Component
/**
 * Implementation of the StaffTokenService interface.
 */
public class StaffTokenImpl implements StaffTokenService
{
    private final StaffVerifyTokenRepository staffVerifyTokenRepository;
    private final StaffResetTokenRepository staffResetTokenRepository;
    private final StaffRepository staffRepository;

    public StaffTokenImpl(final StaffVerifyTokenRepository staffVerifyTokenRepository, final StaffResetTokenRepository staffResetTokenRepository, final StaffRepository staffRepository)
    {
        this.staffVerifyTokenRepository = staffVerifyTokenRepository;
        this.staffResetTokenRepository = staffResetTokenRepository;
        this.staffRepository = staffRepository;
    }

    @Override
    public StaffVerifyToken getVerificationToken(StaffDto staffDto)
    {
        Optional<Staff> staffCheck = staffRepository.findStaffByEmail(staffDto.getEmail());
        if(!staffCheck.isPresent())
            {
                throw new IllegalArgumentException("Incorrect Details Provided");
            }
        Optional<StaffVerifyToken> staffVerifyTokenCheck = Optional.ofNullable(staffVerifyTokenRepository.findStaffVerifyTokenByStaff(staffCheck.get()));
        if(!staffVerifyTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Incorrect Details Provided");
            }

        return staffVerifyTokenCheck.get();
    }

    @Override
    public StaffVerifyToken getVerificationToken(final TokenDto tokenDto)
    {
        Optional<StaffVerifyToken> staffVerifyTokenCheck = Optional.ofNullable(staffVerifyTokenRepository.findStaffVerifyTokensByToken(tokenDto.getToken()));
        if(!staffVerifyTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Invalid Token");
            }
        if(!verifyTokenExpiry(tokenDto.getToken()))
            {
                throw new IllegalArgumentException("Invalid Token");
            };
        return staffVerifyTokenCheck.get();
    }

    @Override
    public boolean deleteVerifyToken(final StaffVerifyToken staffVerifyToken)
    {
        Optional<StaffVerifyToken> staffVerifyTokenCheck = Optional.ofNullable(staffVerifyTokenRepository.findStaffVerifyTokensByToken(staffVerifyToken.getToken()));
        if(!staffVerifyTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Invalid Token");
            }

        staffVerifyTokenRepository.delete(staffVerifyTokenCheck.get());
        return true;
    }

    @Override
    public StaffResetToken generateResetToken(final StaffDto staffDto)
    {
        Optional<Staff> staffCheck = staffRepository.findStaffByEmail(staffDto.getEmail());
        if(!staffCheck.isPresent())
            {
                throw new IllegalArgumentException();
            }
        Optional<StaffResetToken> tokenCheck = Optional.ofNullable(staffResetTokenRepository.findByStaff(staffCheck.get()));
        if(tokenCheck.isPresent())
            {

                 staffResetTokenRepository.delete(tokenCheck.get());
            }

        StaffResetToken staffResetToken = new StaffResetToken(staffCheck.get());
        staffResetTokenRepository.save(staffResetToken);
        return staffResetToken;

    }

    @Override
    public StaffResetToken getResetToken(final TokenDto tokenDto)
    {
        Optional<StaffResetToken> staffResetToken = Optional.ofNullable(staffResetTokenRepository.findByToken(tokenDto.getToken()));
        if(!staffResetToken.isPresent())
            {
                throw new IllegalArgumentException("Incorrect Details Provided");
            }
        if(!verifyTokenExpiry(tokenDto.getToken()))
            {
                throw new IllegalArgumentException("Token Expired");
            }
        return staffResetToken.get();
    }

    private boolean verifyTokenExpiry(final String token)
    {
        try
            {
                final Claims claim = (Claims) Jwts.parser().setSigningKey(ConstantsUtil.TOKEN_SECRET).parse(token).getBody();
                Date tokenDate = claim.getExpiration();
                if(new Date(System.currentTimeMillis()).compareTo(tokenDate) > 0 )
                    {
                       return false;
                    }
            }catch (ExpiredJwtException e)
            {

                return false;
            }

        return true;
    }

    @Override
    public boolean deleteResetToken(final StaffResetToken staffResetToken)
    {
        Optional<StaffResetToken> staffResetTokenCheck = Optional.ofNullable(staffResetTokenRepository.findByToken(staffResetToken.getToken()));
        if(!staffResetTokenCheck.isPresent())
            {
                throw new IllegalArgumentException("Invalid Token");
            }

        staffResetTokenRepository.delete(staffResetTokenCheck.get());
        return true;
    }

    @Override
    public String getUserDetailsFromToken(final TokenDto tokenDto)
    {
        String email = Jwts.parser()
                .setSigningKey(ConstantsUtil.TOKEN_SECRET)
                .parseClaimsJws(tokenDto.getToken())
                .getBody()
                .getSubject();
        if (email == null)
            {
                throw new IllegalStateException("Invalid");
            }

        return email;
    }

//    private boolean verifyToken(final String token)
//    {
//        final Claims body = (Claims) Jwts.parser().parse(token).getBody();
//
//        if(new Date(System.currentTimeMillis()).compareTo(body.getExpiration()) < 0 )
//            {
//                throw new IllegalArgumentException("Token issued");
//            }
//        throw new IllegalArgumentException("");
//    }

}
