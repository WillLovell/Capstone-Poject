package com.foodorder.crm.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MenuControllerTest
{

    @Test
    void getMenuCategoryDto()
    {
    }

    @Test
    void updateMenuCategoryDto()
    {
    }

    @Test
    void getMenuCategories()
    {
    }
}