'use strict';

customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`
        <nav>
            <ul class="list">
                <li class="title">
                    <a href="index.html" data-type="index-link">food-ecommerce documentation</a>
                </li>

                <li class="divider"></li>
                ${ isNormalMode ? `<div id="book-search-input" role="search"><input type="text" placeholder="Type to search"></div>` : '' }
                <li class="chapter">
                    <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
                    <ul class="links">
                        <li class="link">
                            <a href="overview.html" data-type="chapter-link">
                                <span class="icon ion-ios-keypad"></span>Overview
                            </a>
                        </li>
                        <li class="link">
                            <a href="index.html" data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>README
                            </a>
                        </li>
                                <li class="link">
                                    <a href="dependencies.html" data-type="chapter-link">
                                        <span class="icon ion-ios-list"></span>Dependencies
                                    </a>
                                </li>
                                <li class="link">
                                    <a href="properties.html" data-type="chapter-link">
                                        <span class="icon ion-ios-apps"></span>Properties
                                    </a>
                                </li>
                    </ul>
                </li>
                    <li class="chapter modules">
                        <a data-type="chapter-link" href="modules.html">
                            <div class="menu-toggler linked" data-toggle="collapse" ${ isNormalMode ?
                                'data-target="#modules-links"' : 'data-target="#xs-modules-links"' }>
                                <span class="icon ion-ios-archive"></span>
                                <span class="link-name">Modules</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                        </a>
                        <ul class="links collapse " ${ isNormalMode ? 'id="modules-links"' : 'id="xs-modules-links"' }>
                            <li class="link">
                                <a href="modules/AppModule.html" data-type="entity-link" >AppModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' : 'data-target="#xs-components-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' :
                                            'id="xs-components-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' }>
                                            <li class="link">
                                                <a href="components/AddMenuItemComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AddMenuItemComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AdminDashboardComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AdminDashboardComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AdminDashboardPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AdminDashboardPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AdminReportPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AdminReportPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AdminReportsComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AdminReportsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CartItemComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CartItemComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CartPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CartPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CategoryPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CategoryPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/EditCategoriesPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EditCategoriesPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/EditMenuModalComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EditMenuModalComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/EditOrderModalComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EditOrderModalComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/EditProfileModalComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EditProfileModalComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/EditUsersPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EditUsersPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ForgotPasswordComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ForgotPasswordComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ForgotPasswordPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ForgotPasswordPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HomePageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >HomePageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoginComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LoginComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoginPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LoginPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ManagerDashboardComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ManagerDashboardComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ManagerDashboardPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ManagerDashboardPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MenuComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MenuComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MenuItemComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MenuItemComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MenuPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MenuPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NavBarComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >NavBarComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/OrderHistoryComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >OrderHistoryComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/OrderHistoryPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >OrderHistoryPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/PasswordResetComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >PasswordResetComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ProfilePageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ProfilePageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RegisterComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >RegisterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/RegistrationPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >RegistrationPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ResetPasswordPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ResetPasswordPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ShoppingCartComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ShoppingCartComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SideBarComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >SideBarComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/StaffLoginComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >StaffLoginComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/StaffLoginPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >StaffLoginPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/StaffResetComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >StaffResetComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/StaffVerifyComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >StaffVerifyComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/StaffVerifyPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >StaffVerifyPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/StaffresetPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >StaffresetPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SystemMaintenanceComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >SystemMaintenanceComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SystemMaintenancePageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >SystemMaintenancePageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/UserProfileComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >UserProfileComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/VerifyUserComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >VerifyUserComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/VerifyUserPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >VerifyUserPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ViewCategoriesComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ViewCategoriesComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ViewOrdersComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ViewOrdersComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ViewOrdersPageComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ViewOrdersPageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ViewUsersComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ViewUsersComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/WelcomeComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >WelcomeComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' : 'data-target="#xs-injectables-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' :
                                        'id="xs-injectables-links-module-AppModule-9b6109a9d774cd7aa7fdc52196c342512d1ae07827991b761020411d0b0839cbd7313efa804a30f82545d4e5887af75ce33c3051f479fa5c9f4832d2050bfb0a"' }>
                                        <li class="link">
                                            <a href="injectables/MenuService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MenuService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                </ul>
                </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#classes-links"' :
                            'data-target="#xs-classes-links"' }>
                            <span class="icon ion-ios-paper"></span>
                            <span>Classes</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                            <li class="link">
                                <a href="classes/CartItem.html" data-type="entity-link" >CartItem</a>
                            </li>
                            <li class="link">
                                <a href="classes/Category.html" data-type="entity-link" >Category</a>
                            </li>
                            <li class="link">
                                <a href="classes/MenuItem.html" data-type="entity-link" >MenuItem</a>
                            </li>
                            <li class="link">
                                <a href="classes/Order.html" data-type="entity-link" >Order</a>
                            </li>
                            <li class="link">
                                <a href="classes/OrderItem.html" data-type="entity-link" >OrderItem</a>
                            </li>
                            <li class="link">
                                <a href="classes/OrderRequest.html" data-type="entity-link" >OrderRequest</a>
                            </li>
                            <li class="link">
                                <a href="classes/ShoppingCart.html" data-type="entity-link" >ShoppingCart</a>
                            </li>
                            <li class="link">
                                <a href="classes/User.html" data-type="entity-link" >User</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#injectables-links"' :
                                'data-target="#xs-injectables-links"' }>
                                <span class="icon ion-md-arrow-round-down"></span>
                                <span>Injectables</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="injectables-links"' : 'id="xs-injectables-links"' }>
                                <li class="link">
                                    <a href="injectables/AuthService.html" data-type="entity-link" >AuthService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/CartService.html" data-type="entity-link" >CartService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/CategoryService.html" data-type="entity-link" >CategoryService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/CheckoutService.html" data-type="entity-link" >CheckoutService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/MenuService.html" data-type="entity-link" >MenuService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/OrderService.html" data-type="entity-link" >OrderService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/ReportService.html" data-type="entity-link" >ReportService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/ResetService.html" data-type="entity-link" >ResetService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/SystemService.html" data-type="entity-link" >SystemService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/TokenStorageService.html" data-type="entity-link" >TokenStorageService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/UserService.html" data-type="entity-link" >UserService</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#interceptors-links"' :
                            'data-target="#xs-interceptors-links"' }>
                            <span class="icon ion-ios-swap"></span>
                            <span>Interceptors</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="interceptors-links"' : 'id="xs-interceptors-links"' }>
                            <li class="link">
                                <a href="interceptors/AuthInterceptor.html" data-type="entity-link" >AuthInterceptor</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#interfaces-links"' :
                            'data-target="#xs-interfaces-links"' }>
                            <span class="icon ion-md-information-circle-outline"></span>
                            <span>Interfaces</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? ' id="interfaces-links"' : 'id="xs-interfaces-links"' }>
                            <li class="link">
                                <a href="interfaces/categoryElements.html" data-type="entity-link" >categoryElements</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/UserElement.html" data-type="entity-link" >UserElement</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/viewOrdersElement.html" data-type="entity-link" >viewOrdersElement</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#miscellaneous-links"'
                            : 'data-target="#xs-miscellaneous-links"' }>
                            <span class="icon ion-ios-cube"></span>
                            <span>Miscellaneous</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                            <li class="link">
                                <a href="miscellaneous/enumerations.html" data-type="entity-link">Enums</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/variables.html" data-type="entity-link">Variables</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <a data-type="chapter-link" href="routes.html"><span class="icon ion-ios-git-branch"></span>Routes</a>
                        </li>
                    <li class="chapter">
                        <a data-type="chapter-link" href="coverage.html"><span class="icon ion-ios-stats"></span>Documentation coverage</a>
                    </li>
                    <li class="divider"></li>
                    <li class="copyright">
                        Documentation generated using <a href="https://compodoc.app/" target="_blank">
                            <img data-src="images/compodoc-vectorise.png" class="img-responsive" data-type="compodoc-logo">
                        </a>
                    </li>
            </ul>
        </nav>
        `);
        this.innerHTML = tp.strings;
    }
});