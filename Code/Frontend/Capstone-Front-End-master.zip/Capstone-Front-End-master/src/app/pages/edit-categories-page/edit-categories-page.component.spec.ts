import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCategoriesPageComponent } from './edit-categories-page.component';

describe('EditCategoriesPageComponent', () => {
  let component: EditCategoriesPageComponent;
  let fixture: ComponentFixture<EditCategoriesPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditCategoriesPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCategoriesPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
