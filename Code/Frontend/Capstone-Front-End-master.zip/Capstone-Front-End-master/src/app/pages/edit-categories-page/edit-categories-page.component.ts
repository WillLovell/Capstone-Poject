import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-categories-page',
  templateUrl: './edit-categories-page.component.html',
  styleUrls: ['./edit-categories-page.component.css']
})
export class EditCategoriesPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
