import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-users-page',
  templateUrl: './edit-users-page.component.html',
  styleUrls: ['./edit-users-page.component.css']
})
export class EditUsersPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
