import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staffreset-page',
  templateUrl: './staffreset-page.component.html',
  styleUrls: ['./staffreset-page.component.css']
})
export class StaffresetPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
