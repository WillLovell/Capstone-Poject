import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffresetPageComponent } from './staffreset-page.component';

describe('StaffresetPageComponent', () => {
  let component: StaffresetPageComponent;
  let fixture: ComponentFixture<StaffresetPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffresetPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffresetPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
