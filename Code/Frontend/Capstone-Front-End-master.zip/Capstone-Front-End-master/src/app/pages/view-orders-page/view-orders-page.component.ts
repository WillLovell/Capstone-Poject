import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-orders-page',
  templateUrl: './view-orders-page.component.html',
  styleUrls: ['./view-orders-page.component.css']
})
export class ViewOrdersPageComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
