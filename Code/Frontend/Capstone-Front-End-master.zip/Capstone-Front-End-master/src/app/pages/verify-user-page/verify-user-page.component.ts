import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-user-page',
  templateUrl: './verify-user-page.component.html',
  styleUrls: ['./verify-user-page.component.css']
})
export class VerifyUserPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
