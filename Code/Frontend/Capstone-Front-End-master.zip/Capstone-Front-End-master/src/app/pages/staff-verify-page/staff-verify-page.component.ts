import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-verify-page',
  templateUrl: './staff-verify-page.component.html',
  styleUrls: ['./staff-verify-page.component.css']
})
export class StaffVerifyPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
