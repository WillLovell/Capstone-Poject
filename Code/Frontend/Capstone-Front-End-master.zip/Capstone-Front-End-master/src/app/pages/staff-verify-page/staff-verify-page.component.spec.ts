import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffVerifyPageComponent } from './staff-verify-page.component';

describe('StaffVerifyPageComponent', () => {
  let component: StaffVerifyPageComponent;
  let fixture: ComponentFixture<StaffVerifyPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffVerifyPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffVerifyPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
