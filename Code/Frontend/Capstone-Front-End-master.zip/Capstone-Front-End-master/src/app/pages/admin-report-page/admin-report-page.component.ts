import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-report-page',
  templateUrl: './admin-report-page.component.html',
  styleUrls: ['./admin-report-page.component.css']
})
export class AdminReportPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
