import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-maintenance-page',
  templateUrl: './system-maintenance-page.component.html',
  styleUrls: ['./system-maintenance-page.component.css']
})
export class SystemMaintenancePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
