import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemMaintenancePageComponent } from './system-maintenance-page.component';

describe('SystemMaintenancePageComponent', () => {
  let component: SystemMaintenancePageComponent;
  let fixture: ComponentFixture<SystemMaintenancePageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SystemMaintenancePageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemMaintenancePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
