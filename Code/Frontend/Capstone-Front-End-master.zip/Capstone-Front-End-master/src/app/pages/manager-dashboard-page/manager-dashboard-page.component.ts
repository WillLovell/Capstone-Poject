import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manager-dashboard-page',
  templateUrl: './manager-dashboard-page.component.html',
  styleUrls: ['./manager-dashboard-page.component.css']
})
export class ManagerDashboardPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
