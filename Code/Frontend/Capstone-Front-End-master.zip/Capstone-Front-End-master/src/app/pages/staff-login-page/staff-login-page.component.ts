import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-login-page',
  templateUrl: './staff-login-page.component.html',
  styleUrls: ['./staff-login-page.component.css']
})
export class StaffLoginPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
