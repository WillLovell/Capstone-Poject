import {Component, OnDestroy, OnInit} from '@angular/core';
import {CartService} from "../../service/rest/cart.service";
import {CartItem} from "../../dto/cart-item";
import {Subscription} from "rxjs";
import {MenuItem} from "../../dto/menu-item";
import {ShoppingCart} from "../../dto/shopping-cart";
import {CheckoutService} from "../../service/rest/checkout.service";
import {OrderRequest} from "../../dto/order-request";
import {TokenStorageService} from "../../service/rest/token-storage.service";
import {Order} from "../../dto/order";
import {OrderItem} from "../../dto/orderitem";
import {AuthService} from "../../service/rest/auth.service";


@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})

/**
 * class that renders shopping cart
 */
export class ShoppingCartComponent implements OnInit {
  shoppingCart!: ShoppingCart;
  orderRequest!: OrderRequest;
  newOrder!: Order;
  subscriptions!: Subscription;
  orderItems !: OrderItem[];

  constructor(private cartService: CartService, private checkoutService: CheckoutService, private authService: AuthService) {
  }


  ngOnInit(): void {
    this.loadCartData();
    // this.shoppingCart = new ShoppingCart([new CartItem(3.99, 1, "test", "test", 1)], 1, 10)
  }

  /**
   * Method is called from ngOnInit. Get the new menu item to be added to the cart via the observable
   * from getShoppingCartData(). New CartItem is instantiated with the quantity hard coded to 1, as each click
   * will add 1 MenuItem to the cart.
   *
   * The updateCart method is called to update the CartItem[] held in the component
   * @private
   */
  // private addNewCartItem():void
  // {
  //   this.subscriptions = this.cartService.getShoppingCartData().subscribe(
  //     (menuItem: MenuItem) =>
  //     {
  //       const newCartItem: CartItem = new CartItem(
  //       menuItem.price, 1, menuItem.name, menuItem.imageUrl, menuItem.id
  //     )
  //         this.updateCart(newCartItem) //Update CartItem[]
  //     }
  //   );
  // }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }


  // private updateCart(newCartItem: CartItem)
  // {
  //   if (this.cartItems.filter(e => e.menuItemId === newCartItem.menuItemId).length==0)
  //   {
  //     this.cartItems.push(newCartItem);
  //   }
  //   else{
  //     for (let i = 0; i < this.cartItems.length; i++)
  //     {
  //       if(this.cartItems[i].menuItemId == newCartItem.menuItemId)
  //       {
  //         let quantity : number = this.cartItems[i].quantity + 1;
  //         this.cartItems[i].quantity = quantity;
  //         break;
  //       }
  //     }
  //   }
  // }


  // incrementCartItem($event: CartItem): void
  // {
  //   // @ts-ignore
  //   this.cartItems.find(e => e.menuItemId == $event.menuItemId).quantity++;
  // }
  // /**
  //  * Event emitted from Child Component - CartItem, to update the quantity
  //  * @param $event the cartItem To Update
  //  */
  // decrementCartItem($event: CartItem): void
  // {
  //   // @ts-ignore
  //   this.cartItems.find(e => e.menuItemId == $event.menuItemId).quantity--;
  // }

  /**
   * method that loads and updates cart data
   * @private
   */
  private loadCartData() {
    this.subscriptions = this.cartService.getShoppingCartData().subscribe(
      (shoppingCartData: ShoppingCart) => {
        this.shoppingCart = shoppingCartData
      }
    );
    //
    // this.subtotal = this.shoppingCart.subTotal
    // this.tax = this.shoppingCart.orderTax
    // this.total = this.shoppingCart.totalPrice

  }

  /**
   * Event emitted from Child Component - CartItem, to update the quantity
   * @param $event the cartItem To Update
   */
  incrementCartItem($event: CartItem): void {


    // // @ts-ignore
    // @ts-ignore
    this.cartService.incrementCartItem($event.menuItemId);
  }

  /**
   * Event emitted from Child Component - CartItem, to update the quantity
   * @param $event the cartItem To Update
   */
  decrementCartItem($event: CartItem): void {
    // @ts-ignore
    this.cartService.decrementCartItem($event.menuItemId);
  }

  /**
   * method that removes and item from the cart
   * @param $event
   */
  removeCartItem($event: CartItem): void {
    this.cartService.deleteCartItem($event.menuItemId);
  }

  /**
   * method that calls the checkout service to place an order
   */
  checkout() {
    console.log("Test")
    // if (this.checkoutService.canPlace()){
      this.generateOrderRequest(this.orderItems)
      this.checkoutService.placeOrder(this.orderRequest)
    console.log("end")
    // }
  }

  /**
   * method to generate a orderRequest to place an order
   * @param orderItems
   * @private
   */
  private generateOrderRequest(orderItems: OrderItem[]): OrderRequest {
    console.log("Generation")
    this.newOrder = new Order(this.shoppingCart.totalQuantity, this.shoppingCart.totalPrice)
    orderItems = this.shoppingCart.cartItems.map(cartItem => new OrderItem(cartItem.menuItemImageUrl, cartItem.price, cartItem.quantity, cartItem.menuItemId ))
    // this.orderRequest = new OrderRequest(this.newOrder, orderItems, )
    console.log(this.orderRequest)
    return this.orderRequest


  }
}





