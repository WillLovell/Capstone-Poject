import { Component, OnInit } from '@angular/core';
import {OrderService} from "../../service/rest/order.service";
import {ViewOrdersComponent} from "../view-orders/view-orders.component";

@Component({
  selector: 'app-edit-order-modal',
  templateUrl: './edit-order-modal.component.html',
  styleUrls: ['./edit-order-modal.component.css']
})

/**
 * class that handels editing a order status
 */
export class EditOrderModalComponent implements OnInit {
  form: any = {
    status: null
  };

  orderID: any

  constructor(private order: OrderService) { }

  /**
   * Method to pull in order details on intilization
   */
  ngOnInit(): void {
    this.orderID = ViewOrdersComponent.arguments.editOrderID
  }

  /**
   * method to pass form inputs to update order status service onsubmit
   */
  onSubmit() {
    const { status } = this.form;
    this.order.updateOrderStatus(this.orderID, status)
  }

}
