import {Component, OnInit} from '@angular/core';
import {TokenStorageService} from "../../service/rest/token-storage.service";
import {UserService} from "../../service/rest/user.service";
import {MatDialog} from "@angular/material/dialog";
import {EditProfileModalComponent} from "../../components/edit-profile-modal/edit-profile-modal.component";

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})

/**
 * class to render the users profile
 */
export class UserProfileComponent implements OnInit {
  currentUser: any;

  constructor(private token: TokenStorageService, private userService: UserService, private dialogRef: MatDialog) {
  }

  /**
   * onload the current users data is retrieved
   */
  ngOnInit(): void {
    this.currentUser = this.token.getUser();
  }

  /**
   * method to open the edit profile details modal
   */
  openDialog() {
    this.dialogRef.open(EditProfileModalComponent);
  }

}
