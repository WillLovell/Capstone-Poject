import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {CartService} from "../../service/rest/cart.service";
import {ShoppingCart} from "../../dto/shopping-cart";
import {AuthService} from "../../service/rest/auth.service";
import {TokenStorageService} from "../../service/rest/token-storage.service";

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})

/**
 * class for nav bar
 */
export class NavBarComponent implements OnInit {
  cartQuantity: number = 0
  userType: any
  loginStatus: boolean = false
  @Output() cartView : EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private cartService: CartService, private authService: AuthService, private tokenService: TokenStorageService) { }

  /**
   * method to update nav bar on load
   */
  ngOnInit(): void
  {
    if (this.tokenService.getToken()) {
      this.loginStatus = true;

    }
    this.loadCartData()
    this.userType = this.authService.getUserType()

  }

  /**
   * Private method to load items into the Shopping cart component,
   * by subscribing to the cartService mehtod getShoppingCartData
   * @private
   */
  private loadCartData()
  {
    this.cartService.getShoppingCartData().subscribe(
      (shoppingCartData: ShoppingCart) => {
        this.cartQuantity = shoppingCartData.totalQuantity
      }
    );
  }

  /**
   * method to logout
   */
  logout(){
    this.tokenService.signOut()
  }


}
