import {Component, OnInit} from '@angular/core';
import {TokenStorageService} from "../../service/rest/token-storage.service";
import {UserService} from "../../service/rest/user.service";

@Component({
  selector: 'app-edit-profile-modal',
  templateUrl: './edit-profile-modal.component.html',
  styleUrls: ['./edit-profile-modal.component.css']
})

/**
 * class to handle updatinf a user profile
 */
export class EditProfileModalComponent implements OnInit {
  currentUser: any
  form: any = {
    firstName: null,
    lastName: null,
    email: null
  };

  constructor(private token: TokenStorageService, private userService: UserService) {
  }

  /**
   * method to get the current users info on load
   */
  ngOnInit(): void {
    this.currentUser = this.token.getUser();
  }

  /**
   * method to pass form inputs to user service to update customer details on submit
   */
  onSubmit(): void {
    const { firstName, lastName, email } = this.form;
    this.userService.updateCustomer(this.currentUser.id,firstName, lastName, email)
  }

}
