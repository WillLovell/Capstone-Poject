import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffVerifyComponent } from './staff-verify.component';

describe('StaffVerifyComponent', () => {
  let component: StaffVerifyComponent;
  let fixture: ComponentFixture<StaffVerifyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffVerifyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffVerifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
