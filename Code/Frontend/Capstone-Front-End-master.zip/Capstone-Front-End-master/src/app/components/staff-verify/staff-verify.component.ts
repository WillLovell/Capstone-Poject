import { Component, OnInit } from '@angular/core';
import {AuthService} from "../../service/rest/auth.service";

@Component({
  selector: 'app-staff-verify',
  templateUrl: './staff-verify.component.html',
  styleUrls: ['./staff-verify.component.css']
})

/**
 * class to activate a staffs account
 */
export class StaffVerifyComponent implements OnInit {
  verified: any

  constructor(private verifyService: AuthService) { }

  /**
   * method that onload class staff verify service
   */
  ngOnInit(): void {
    this.verified = this.verifyService.staffVerify()
  }

}
