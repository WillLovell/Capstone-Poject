import {Component, OnInit} from '@angular/core';
import {ResetService} from "../../service/rest/reset.service"

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})

/**
 * class to handle forgot password form
 */
export class ForgotPasswordComponent implements OnInit {
  form: any = {
    username: null
  };
  requestSubmitted = false;
  requestFailed = false;
  errorMessage = '';

  constructor(private resetService: ResetService) {
  }

  ngOnInit(): void {

  }

  /**
   * method that passes form inputs to resetservice to send a recovory email to the user
   */
  onSubmit(): void {
    const {username} = this.form;
    this.resetService.forgot(username).subscribe(
      data => {
        this.requestFailed = false;
        this.requestSubmitted = true;
        // this.reloadPage();
      },
      err => {
        this.errorMessage = err.error.message;
        this.requestFailed = true;
      }
    );
  }

  // reloadPage(): void {
  //   window.location.reload();
  // }


}
