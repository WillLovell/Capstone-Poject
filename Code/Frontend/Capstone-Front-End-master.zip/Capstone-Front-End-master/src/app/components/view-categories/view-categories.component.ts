import {Component, OnInit} from '@angular/core';
import {AuthService} from "../../service/rest/auth.service";
import {CategoryService} from "../../service/rest/category.service";

export interface categoryElements {
  id: number;
  name: string;
}


/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-view-categories',
  templateUrl: './view-categories.component.html',
  styleUrls: ['./view-categories.component.css']
})

/**
 * class that renders page to display categories
 */
export class ViewCategoriesComponent {
  displayedColumns: string[] = ['category_ID', 'category_name'];
  dataSource: any

  constructor(private categoryService: CategoryService) {
  }

  /**
   * onload the categories data is retrieved
   */
  ngOnInit(): void {
    this.dataSource = this.categoryService.getMenuCategories()
  }

}
