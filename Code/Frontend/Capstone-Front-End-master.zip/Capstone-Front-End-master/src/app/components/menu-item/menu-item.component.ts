import {Component, OnInit, Input, Output} from '@angular/core';
import {MenuItem} from "../../dto/menu-item";
import {EventEmitter} from "@angular/core";
import {MatDialog} from "@angular/material/dialog";
import {EditMenuModalComponent} from "../edit-menu-modal/edit-menu-modal.component";
import {AuthService} from "../../service/rest/auth.service";
import {MenuService} from "../../service/rest/menu.service";

@Component({
  selector: 'app-menu-item',
  templateUrl: './menu-item.component.html',
  styleUrls: ['./menu-item.component.css']
})

/**
 * class to render each menu item
 */
export class MenuItemComponent implements OnInit {
  @Input() menuItem! : MenuItem;
  @Output() seeItem: EventEmitter<MenuItem> = new EventEmitter<MenuItem>();
  @Output() addToCart: EventEmitter<MenuItem> = new EventEmitter<MenuItem>();

  userType: any;

  constructor(private dialogRef : MatDialog, private authService: AuthService, private menuService: MenuService) { }

  /**
   * method to open modal to edit a menu item
   */
  openDialog(){
    this.dialogRef.open(EditMenuModalComponent);
  }

  /**
   * method to delete a menu item
   * @param id
   */
  deleteItem(id: number) {
    this.menuService
  }


  /**
   * on load checks users role to decide what buttons to render
   */
  ngOnInit(): void
  {
    this.userType = this.authService.getUserType()
  }

  /**
   * Emit the seeItem event to view a specific menu item
   * @param menuItem to view
   */
  viewItemDetails(menuItem: MenuItem)
  {
    this.seeItem.emit(menuItem);
  }

  /**
   * Emits the addToCart EventEmitter to the parent class (Menu-Componenet)
   * @param menuItem to be added to the cart
   */
  sendToCart(menuItem: MenuItem)
  {
    this.addToCart.emit(menuItem);
  }
}
