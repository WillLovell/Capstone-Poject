import {Component, OnInit} from '@angular/core';
import {MatDialog} from "@angular/material/dialog";
import {OrderService} from "../../service/rest/order.service";
import {EditOrderModalComponent} from "../edit-order-modal/edit-order-modal.component";
import {UserService} from "../../service/rest/user.service";

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})

/**
 * Class that renders a customers order history
 */
export class OrderHistoryComponent implements OnInit {
  displayedColumns: string[] = ['order_ID', 'customer_ID', 'order_quantity', 'order_total', 'order_status', 'action'];
  dataSource: any

  constructor(private dialogRef: MatDialog, private orderService: OrderService, private userService: UserService) {
  }

  /**
   * onload retreives all orders of a specific customer
   */
  ngOnInit() {
    this.dataSource = this.orderService.getOrders()
  }

  /**
   * method to cancel a order as a customer
   * @param customerID
   * @param orderID
   */
  cancelRequest(customerID: number, orderID: number) {
    this.orderService.cancelOrder(customerID, orderID)
  }

}
