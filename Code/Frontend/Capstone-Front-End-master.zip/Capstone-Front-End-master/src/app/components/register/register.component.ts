import {Component, OnInit} from '@angular/core';
import {AuthService} from "../../service/rest/auth.service";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

/**
 * class to register a customer
 */
export class RegisterComponent implements OnInit {
  form: any = {
    firstname: null,
    lastname: null,
    email: null,
    password: null
  };
  signUpSuccessful = false;
  signUpFailed = false;
  errorMessage = '';

  constructor(private authService: AuthService) {
  }

  ngOnInit(): void {
  }

  /**
   * method that takes form inputs and passes them to the register service
   */
  onSubmit(): void {
    const {firstName, lastName, email, password} = this.form;
    this.authService.register(firstName, lastName, email, password).subscribe(
      data => {
        console.log(data);
        this.signUpSuccessful = true;
        this.signUpFailed = false;
      },
      err => {
        this.errorMessage = err.error.message;
        this.signUpFailed = true;
      }
    );
  }
}
