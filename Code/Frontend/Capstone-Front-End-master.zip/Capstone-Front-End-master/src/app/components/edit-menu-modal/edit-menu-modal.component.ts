import { Component, OnInit } from '@angular/core';
import {MenuService} from "../../service/rest/menu.service";

@Component({
  selector: 'app-edit-menu-modal',
  templateUrl: './edit-menu-modal.component.html',
  styleUrls: ['./edit-menu-modal.component.css']
})

/**
 * incharge of editing a menuitem
 */
export class EditMenuModalComponent implements OnInit {
  form: any = {
    name: null,
    price: null,
    // added: null,
    id: null,
    catID: null,
    img: null,
    active: null,
    description: null,
  };

  constructor(private menu: MenuService) { }
  canOrder: any

  ngOnInit(): void {

  }

  /**
   * method to pass forms inputs to a the update menu item service on submit
   */
  onSubmit() {
    const { id, description, img, catID, name, price, active} = this.form;
    this.menu.updateMenuItem(id, description, img, catID, name, price, active)
  }

}
