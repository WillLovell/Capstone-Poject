import { Component, OnInit } from '@angular/core';
import {MenuService} from "../../service/rest/menu.service";

@Component({
  selector: 'app-add-menu-item',
  templateUrl: './add-menu-item.component.html',
  styleUrls: ['./add-menu-item.component.css']
})

/**
 * class in charge of passing form details to service to add a menu item
 */
export class AddMenuItemComponent implements OnInit {
  form: any = {
    name: null,
    price: null,
    id: null,
    catID: null,
    img: null,
    active: null,
    description: null,
  };

  constructor(private menu: MenuService) { }

  ngOnInit(): void {
  }

  /**
   * method to forward to menu service on submit
   */
  onSubmit() {
    const {description, img, catID, name, price, active} = this.form;
    this.menu.createMenuItem(description, img, catID, name, price, active)
  }

}
