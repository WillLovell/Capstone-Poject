import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffResetComponent } from './staff-reset.component';

describe('StaffResetComponent', () => {
  let component: StaffResetComponent;
  let fixture: ComponentFixture<StaffResetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffResetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffResetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
