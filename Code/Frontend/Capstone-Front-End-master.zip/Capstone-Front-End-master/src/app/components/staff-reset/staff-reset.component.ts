import { Component, OnInit } from '@angular/core';
import {ResetService} from "../../service/rest/reset.service";

@Component({
  selector: 'app-staff-reset',
  templateUrl: './staff-reset.component.html',
  styleUrls: ['./staff-reset.component.css']
})

/**
 * class to reset a staff users password
 */
export class StaffResetComponent implements OnInit {
  form: any = {
    password: null
  };
  resetSuccessful = false;
  resetFailed = false;
  errorMessage = '';

  constructor(private resetService: ResetService) {
  }
  ngOnInit(): void {
  }

  /**
   * method to pass new password to staff reset service
   */
  onSubmit(): void {
    const {password} = this.form;
    this.resetService.staffReset(password).subscribe(
      data => {
        this.resetFailed = false;
        this.resetSuccessful = true;
        // this.reloadPage();
      },
      err => {
        this.errorMessage = err.error.message;
        this.resetFailed = true;
      }
    );
  }

  // reloadPage(): void {
  //   window.location.reload();
  // }


}
