import { Component, OnInit } from '@angular/core';
import {AuthService} from "../../service/rest/auth.service";

@Component({
  selector: 'app-verify-user',
  templateUrl: './verify-user.component.html',
  styleUrls: ['./verify-user.component.css']
})

/**
 * class that activates a customers account
 */
export class VerifyUserComponent implements OnInit {
  verified: any

  constructor(private verifyService: AuthService) { }

  /**
   * on load the verify service is called
   */
  ngOnInit(): void {
    this.verified = this.verifyService.verify()
  }

}
