import {Component, OnInit} from '@angular/core';
import {Router, NavigationEnd} from '@angular/router';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css']
})

/**
 * class to render the sidebar
 */
export class SideBarComponent implements OnInit {

  currentRoute: string;
  sortBy: any;

  constructor(private router: Router) {
    this.currentRoute = router.url;
    console.log(this.currentRoute);
  }

  ngOnInit(): void {

  }

  /**
   * method to render page based on selected filter
   * @param selectedValue
   */
  sidebarChange( selectedValue: any ) {
    this.sortBy = selectedValue;
    console.log(this.sortBy)
  }

  /**
   * method to filter menu items
   */
  isCategoryRoute() {
    return this.router.url.includes("/category");
  }

}
