import { Component, OnInit } from '@angular/core';
import {ResetService} from "../../service/rest/reset.service";

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  styleUrls: ['./password-reset.component.css']
})

/**
 * class that handles customer password reset
 */
export class PasswordResetComponent implements OnInit {
  form: any = {
    password: null
  };
  resetSuccessful = false;
  resetFailed = false;
  errorMessage = '';

  constructor(private resetService: ResetService) {
  }
  ngOnInit(): void {
  }

  /**
   * method that takes form inputs to reset a customers password
   */
  onSubmit(): void {
    const {password} = this.form;
    this.resetService.reset(password).subscribe(
      data => {
        this.resetFailed = false;
        this.resetSuccessful = true;
        // this.reloadPage();
      },
      err => {
        this.errorMessage = err.error.message;
        this.resetFailed = true;
      }
    );
  }

  // reloadPage(): void {
  //   window.location.reload();
  // }


}
