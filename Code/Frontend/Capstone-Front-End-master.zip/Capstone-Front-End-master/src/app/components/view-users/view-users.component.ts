import { Component, OnInit } from '@angular/core';
import {UserService} from "../../service/rest/user.service";

export interface UserElement {
  user_ID: number;
  email: string;
  firstName: string;
  lastName: string;
}

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.css']
})

/**
 * class to display all user data
 */
export class ViewUsersComponent {
  displayedColumns: string[] = ['user_ID', 'user_email', 'user_fname', 'user_lname'];
   customers: any
   staff: any

  constructor(private userService: UserService) { }

  /**
   * on load it retreives that customers data and the staff users data
   */
  ngOnInit(): void {
    this.customers = this.userService.getCustomers()
    this.staff = this.userService.getAllStaff()
  }
}
