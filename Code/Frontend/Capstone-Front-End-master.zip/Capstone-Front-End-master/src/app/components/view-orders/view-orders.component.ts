import {Component, OnInit} from '@angular/core';
import {MatDialog} from "@angular/material/dialog";
import {EditOrderModalComponent} from "../edit-order-modal/edit-order-modal.component";
import {OrderService} from "../../service/rest/order.service";

export interface viewOrdersElement {
  name: string;
  Order_ID: number;
  weight: number;
  symbol: string;
}

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'app-view-orders',
  templateUrl: './view-orders.component.html',
  styleUrls: ['./view-orders.component.css']
})

/**
 * class to render order page
 */
export class ViewOrdersComponent {
  displayedColumns: string[] = ['order_ID', 'customer_ID', 'order_quantity', 'order_total', 'order_status', 'action'];
  dataSource: any
  editOrderID: any

  constructor(private dialogRef: MatDialog, private orderService: OrderService) {
  }

  /**
   * method to open the modal to edit an orders status
   * @param id
   */
  openDialog(id: number) {
    this.dialogRef.open(EditOrderModalComponent);
    this.editOrderID = id
  }

  /**
   * on load the all orders data is retrieved
   */
  ngOnInit() {
    this.dataSource = this.orderService.getOrders()
  }
}
