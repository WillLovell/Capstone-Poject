import { Component, OnInit } from '@angular/core';
import {SystemService} from "../../service/rest/system.service";

@Component({
  selector: 'app-system-maintenance',
  templateUrl: './system-maintenance.component.html',
  styleUrls: ['./system-maintenance.component.css']
})

/**
 * class to render system maintenance page
 */
export class SystemMaintenanceComponent implements OnInit {
  form: any = {
    weekday: null,
    openTime: null,
    closeTime: null,
  }

  constructor(private systemService: SystemService) { }

  ngOnInit(): void {
  }

  /**
   * method to pass form inputs to systemService class to change operating hours
   */
  onSubmit(): void {
    const { weekday, openTime, closeTime } = this.form;
        this.systemService.updateHours(closeTime, weekday, openTime)
  }

}
