import {Component, OnInit, Input, SimpleChanges, SimpleChange, Output, EventEmitter} from '@angular/core';
import {CartItem} from "../../dto/cart-item";

@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.component.html',
  styleUrls: ['./cart-item.component.css']
})

export class CartItemComponent implements OnInit {
  @Input() cartItem!: CartItem;
  @Output() incrementCartItem : EventEmitter<CartItem> = new EventEmitter<CartItem>();
  @Output() decrementCartItem : EventEmitter<CartItem> = new EventEmitter<CartItem>();
  @Output() removeCartItem : EventEmitter<CartItem> = new EventEmitter<CartItem>();


  constructor() { }

  /**
   *
   */
  ngOnInit(): void
  {

  }

  /**
   * Emit incrementCartItem to Parent (Shopping Cart Component)
   * passing in the cartitem in question to increment quantity
   */
  incrementQuantity()
  {
    this.incrementCartItem.emit(this.cartItem);
  }
  /**
   * Emit incrementCartItem to Parent (Shopping Cart Component)
   * passing in the cartitem in question to decrement quantity
   */
  decrementQuantity()
  {
    this.decrementCartItem.emit(this.cartItem);
  }

  /**
   * Method to remove an item from the users cart
   */
  removeItem()
  {
    console.log("REMOVE TRIGGERED")
    this.removeCartItem.emit(this.cartItem);
  }
}
