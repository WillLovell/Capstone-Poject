import { Component, OnInit } from '@angular/core';
import {MatDialog} from "@angular/material/dialog";
import {OrderService} from "../../service/rest/order.service";
import {EditOrderModalComponent} from "../edit-order-modal/edit-order-modal.component";

@Component({
  selector: 'app-admin-reports',
  templateUrl: './admin-reports.component.html',
  styleUrls: ['./admin-reports.component.css']
})

/**
 * Class to render data for reports page
 */
export class AdminReportsComponent {
  displayedColumns: string[] = ['order_ID', 'customer_ID', 'order_quantity', 'order_total', 'order_status', 'action'];
  dataSource: any
  editOrderID: any

  constructor(private dialogRef: MatDialog, private orderService: OrderService) {
  }

  /**
   * Method to open edit order modal
   * @param id
   */
  openDialog(id: number) {
    this.dialogRef.open(EditOrderModalComponent);
    this.editOrderID = id
  }

  /**
   * method to retrive orders data on intilization
   */
  ngOnInit() {
    this.dataSource = this.orderService.getOrders()
  }
}
