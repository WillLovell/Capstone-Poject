import {ComponentFixture, TestBed} from '@angular/core/testing';
import {MenuComponent} from './menu.component';
import {By} from "@angular/platform-browser";
import {DebugElement} from "@angular/core";

describe('MenuComponent', () => {
  let component: MenuComponent;
  let fixture: ComponentFixture<MenuComponent>;
  let de: DebugElement

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MenuComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a list of menuItems', () => {
    expect(component.menuitems).toBeGreaterThan(0)
  });

  it('should have a H1 tag of `menu`', () => {
    expect(de.query(By.css('h1')).nativeElement.innerText);
  })


});
