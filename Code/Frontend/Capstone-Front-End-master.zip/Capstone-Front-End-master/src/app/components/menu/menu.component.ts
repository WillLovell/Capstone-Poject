import { Component, OnInit, Input } from '@angular/core';
import {MenuItem} from "../../dto/menu-item";
import {CartService} from "../../service/rest/cart.service";
import {MenuService} from "../../service/rest/menu.service";
import {AuthService} from "../../service/rest/auth.service";
import {MatDialog} from "@angular/material/dialog";
import {AddMenuItemComponent} from "../add-menu-item/add-menu-item.component";
import {EditOrderModalComponent} from "../edit-order-modal/edit-order-modal.component";

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})

/**
 * class that handles how menu renders
 */
export class MenuComponent implements OnInit {
  @Input() category = 0;
  menuitems: MenuItem[] = [];
  menuItem!: MenuItem;
  listView: boolean = true;
  userType: any

  // dummyData = [ new MenuItem(1, "menu1", 1.99, "", "this is menu1", 1),
  //   new MenuItem(2, "menu2", 2.99, "", "this is menu2", 1),
  //   new MenuItem(3, "menu3", 3.99, "", "this is menu3", 2)
  //   ];

  constructor(private menuService: MenuService,
              private cartService: CartService,
              private  authService: AuthService,
              private dialogRef: MatDialog) {
  }

  /**
   * onload menu is populated
   */
  ngOnInit() {
    this.menuService.getAllMenuItems().subscribe(
      (data: MenuItem[]) => {
        this.menuitems = data;
      }
    );
    // this.userType = this.authService.getUserType()
    this.userType = "MANAGER"
  }

  /**
   * method to return if categories are being displayed
   */
  allCategory() {
    return this.category == 0 ? true : false;
  }

  /**
   * method to display menu items based on category
   * @param menu
   */
  getCategoryId(menu: MenuItem) {
    return menu.menuCategory.id;
  }

  /**
   * Method to change view between listing out menu items in a grid view vs an individual view
   * one triggered boolean list view will be set to the opposite value.
   * @param $event Menuitem to view
   */
  changeView($event: MenuItem) {
    this.menuItem = $event;
    this.listView = !this.listView;
  }

  /**
   * Method calls the addItemToCart in the cartService class. Trigger from the add to cart button
   * @param menuItem menu item to add to cart
   */
  addToCart(menuItem: MenuItem) {
    console.log("ITEM TO SEND TO CART " + menuItem.id);
    this.cartService.addItemToCart(menuItem);
  }

  /**
   * Only callable from the detailed item view, changes the listView boolean to the oppsitve value
   */
  viewFullMenu() {
    this.listView = !this.listView;
  }

  /**
   * method to open up modal to add a menu item
   */
  openDialog(){
    this.dialogRef.open(EditOrderModalComponent);
  }
}
