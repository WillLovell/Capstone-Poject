/**
 * Different states of an order
 */
const enum OrderStatus
{

  PENDING="PENDING",
  DECLINED="DECLINED",
  CONFIMRED="CONFIMRED",
  INPROGRESS="INPROGRESS",
  COMPLETED="COMPLETED",
  COLLECTED="COLLECTED"

}

/**
 * Representation of the customers order. Initially set to pending
 */
export class Order
{
  private _totalQuantity: number;
  private _totalPrice: number;
  private _status: OrderStatus;

  constructor(totalQuantity: number, totalPrice: number) {
    this._totalQuantity = totalQuantity;
    this._totalPrice = totalPrice;
    this._status = OrderStatus["PENDING"];
  }

  get totalQuantity(): number
  {
    return this._totalQuantity;
  }

  get totalPrice(): number
  {
    return this._totalPrice;
  }

  get status(): OrderStatus
  {
    return this._status;
  }
}
