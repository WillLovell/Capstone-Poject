/**
 * CartItem - Menu items that have been added to a Shopping Cart
 */
export class CartItem
{
  private readonly _price: number;
  private _quantity: number;
  private readonly _description: string;
  private readonly _menuItemImageUrl: string;
  private readonly _menuItemId: number;


  constructor(price: number, quantity: number, description: string, menuItemImageUrl: string, menuItemId: number) {
    this._price = price;
    this._quantity = quantity;
    this._description = description;
    this._menuItemImageUrl = menuItemImageUrl;
    this._menuItemId = menuItemId;
  }


  get price(): number {
    return this._price;
  }

  get quantity(): number {
    return this._quantity;
  }

  set quantity(value: number) {
    this._quantity = value;
  }

  get description(): string {
    return this._description;
  }

  get menuItemImageUrl(): string {
    return this._menuItemImageUrl;
  }

  get menuItemId(): number {
    return this._menuItemId;
  }

}
