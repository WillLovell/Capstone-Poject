export class User {
  asObservable(): import("rxjs").Observable<User> {
      throw new Error('Method not implemented.');
  }


  constructor() {
  }

  get firstName(): string {
    return this._firstName;
  }

  set firstName(value: string) {
    this._firstName = value;
  }

  get email(): string {
    return this._email;
  }

  set email(value: string) {
    this._email = value;
  }

  get lastName(): string {
    return this._lastName;
  }

  set lastName(value: string) {
    this._lastName = value;
  }

  private _firstName!: string;
  private _lastName!: string;
  private _email!: string;

}
