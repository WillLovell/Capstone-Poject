import {CartItem} from "./cart-item";

/**
 * Representation of Menu items added to a Shopping Cart, and converted to a cart item.
 */
export class ShoppingCart
{

  private _cartItems : CartItem []
  private _totalQuantity : number
  private _subTotal: number
  private _orderTax: number
  private _totalPrice : number



  constructor(cartItems: CartItem[], totalQuantity: number, totalPrice: number) {
    this._cartItems = cartItems;
    this._totalQuantity = totalQuantity;
    this._subTotal = totalPrice;
    this._orderTax = totalPrice * 0.05;
    this._totalPrice = totalPrice + this._orderTax;
  }

  get cartItems(): CartItem[]
  {
    return this._cartItems;
  }

  set cartItems(value: CartItem[])
  {
    this._cartItems = value;
  }

  get totalQuantity(): number
  {
    return this._totalQuantity;
  }

  set totalQuantity(value: number)
  {
    this._totalQuantity = value;
  }

  get totalPrice(): number
  {
    return this._totalPrice;
  }

  set totalPrice(value: number)
  {
    this._totalPrice = value;
  }

  get orderTax(): number {
    return this._orderTax;
  }

  set orderTax(value: number) {
    this._orderTax = value;
  }
  get subTotal(): number {
    return this._subTotal;
  }

  set subTotal(value: number) {
    this._subTotal = value;
  }
}
