/**
 * MenuItem - Representation of the menu item dto received from the API call
 */
import {Category} from "./category";

export class MenuItem {
  private readonly _id: number;
  private readonly _name: string;
  private readonly _price:number;
  private readonly _description: string;
  private readonly _imageUrl : string;
  private readonly _menuCategory : Category;


  constructor(id: number, name: string, price: number, imgUrl: string, description: string, menuCategory: Category) {
    this._id = id;
    this._name = name;
    this._price = price;
    this._description = description;
    this._imageUrl = imgUrl;
    this._menuCategory = menuCategory;
  }

  get id(): number {
    return this._id;
  }

  get name(): string {
    return this._name;
  }

  get price(): number {
    return this._price;
  }

  get description(): string {
    return this._description;
  }

  get imageUrl(): string {
    return this._imageUrl;
  }

  get menuCategory(): Category {
    return this._menuCategory;
  }

}

