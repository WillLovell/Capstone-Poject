import {Category} from './category';

describe('category', () => {
  it('should create an instance', () => {
    expect(new Category()).toBeTruthy();
  });
});
