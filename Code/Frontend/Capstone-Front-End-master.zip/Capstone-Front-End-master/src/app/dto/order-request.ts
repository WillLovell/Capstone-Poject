import { Order } from "./order";
import { OrderItem } from "./orderitem";
import { User } from "./user";

/**
 * OrderRequest DTO sent via the POST method. Encapsulation of the customer, order and items ordered
 */
export class OrderRequest
{
  private readonly order: Order;
  private readonly orderItems: OrderItem[];
  private readonly customer: User;


  constructor(order:Order, orderItems: OrderItem[], customer:User) {
    this.order = order;
    this.orderItems = orderItems;
    this.customer = customer;
  }
}
