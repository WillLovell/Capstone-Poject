import { ShoppingCart } from './shopping-cart';

describe('ShoppingCart', () => {
  it('should create an instance', () => {
    expect(new ShoppingCart()).toBeTruthy();
  });
});
