import { OrderRequest } from './order-request';

describe('OrderRequest', () => {
  it('should create an instance', () => {
    expect(new OrderRequest()).toBeTruthy();
  });
});
