/**
 * Items that have successfully been added to a order, via the checkout process. 
 */
export class OrderItem {
  private readonly _imageUrl: string;
  private readonly _itemPrice: number;
  private readonly _quantity: number;
  private readonly _menuItemId: number;


  constructor(imageUrl: string, unitPrice: number, quantity: number, menuItemId: number) {
    this._imageUrl = imageUrl;
    this._itemPrice = unitPrice;
    this._quantity = quantity;
    this._menuItemId = menuItemId;
  }


  get imageUrl(): string {
    return this._imageUrl;
  }

  get itemPrice(): number {
    return this._itemPrice;
  }

  get quantity(): number {
    return this._quantity;
  }

  get menuItemId(): number {
    return this._menuItemId;
  }


}
