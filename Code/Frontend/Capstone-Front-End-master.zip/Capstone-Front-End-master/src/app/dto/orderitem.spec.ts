import { Orderitem } from './orderitem';

describe('Orderitem', () => {
  it('should create an instance', () => {
    expect(new Orderitem()).toBeTruthy();
  });
});
