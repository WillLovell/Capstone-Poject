//angular dependants
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {AppComponent} from './app.component';
import {HttpClientModule} from "@angular/common/http";
import {RouterModule, Routes} from "@angular/router";
import {FormsModule} from "@angular/forms";
import {MatTableModule} from '@angular/material/table';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatDialogModule} from "@angular/material/dialog";

//bootstrap
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

//fonts
import {FontAwesomeModule} from "@fortawesome/angular-fontawesome";

//components
import {MenuComponent} from './components/menu/menu.component';
import {MenuItemComponent} from './components/menu-item/menu-item.component';
import {NavBarComponent} from './components/nav-bar/nav-bar.component';
import {ShoppingCartComponent} from './components/shopping-cart/shopping-cart.component';
import {CartItemComponent} from './components/cart-item/cart-item.component';
import {SideBarComponent} from './components/side-bar/side-bar.component';
import {LoginComponent} from './components/login/login.component';
import {RegisterComponent} from './components/register/register.component';
import {StaffLoginComponent} from './components/staff-login/staff-login.component';
import {UserProfileComponent} from './components/user-profile/user-profile.component';
import {ForgotPasswordComponent} from './components/forgot-password/forgot-password.component';
import {PasswordResetComponent} from './components/password-reset/password-reset.component';
import {AdminReportsComponent} from './components/admin-reports/admin-reports.component';
import {ManagerDashboardComponent} from './components/manager-dashboard/manager-dashboard.component';
import {AdminDashboardComponent} from './components/admin-dashboard/admin-dashboard.component';
import {SystemMaintenanceComponent} from './components/system-maintenance/system-maintenance.component';
import {WelcomeComponent} from './components/welcome/welcome.component';
import {EditMenuModalComponent} from './components/edit-menu-modal/edit-menu-modal.component';
import {EditOrderModalComponent} from './components/edit-order-modal/edit-order-modal.component';
import {ViewCategoriesComponent} from './components/view-categories/view-categories.component';
import {ViewUsersComponent} from './components/view-users/view-users.component';
import {ViewOrdersComponent} from './components/view-orders/view-orders.component';
import {OrderHistoryComponent} from './components/order-history/order-history.component';
import {StaffVerifyComponent} from './components/staff-verify/staff-verify.component';
import {StaffResetComponent} from './components/staff-reset/staff-reset.component';
import {EditProfileModalComponent} from "./components/edit-profile-modal/edit-profile-modal.component";

//services
import {MenuService} from "./service/rest/menu.service";
import {authInterceptorProviders} from "./service/interceptor/auth.interceptor";

//pages
import {MenuPageComponent} from './pages/menu-page/menu-page.component';
import {LoginPageComponent} from './pages/login-page/login-page.component';
import {StaffLoginPageComponent} from './pages/staff-login-page/staff-login-page.component';
import {RegistrationPageComponent} from './pages/registration-page/registration-page.component';
import {ProfilePageComponent} from './pages/profile-page/profile-page.component';
import {ResetPasswordPageComponent} from './pages/reset-password-page/reset-password.component';
import {ForgotPasswordPageComponent} from './pages/forgot-password-page/forgot-password-page.component';
import {CartPageComponent} from './pages/cart-page/cart-page.component';
import {AdminReportPageComponent} from './pages/admin-report-page/admin-report-page.component';
import {AdminDashboardPageComponent} from './pages/admin-dashboard-page/admin-dashboard-page.component';
import {ManagerDashboardPageComponent} from './pages/manager-dashboard-page/manager-dashboard-page.component';
import {SystemMaintenancePageComponent} from './pages/system-maintenance-page/system-maintenance-page.component';
import {HomePageComponent} from './pages/home-page/home-page.component';
import {EditCategoriesPageComponent} from './pages/edit-categories-page/edit-categories-page.component';
import {EditUsersPageComponent} from './pages/edit-users-page/edit-users-page.component';
import {ViewOrdersPageComponent} from './pages/view-orders-page/view-orders-page.component';
import {VerifyUserComponent} from './components/verify-user/verify-user.component';
import {VerifyUserPageComponent} from './pages/verify-user-page/verify-user-page.component';
import {OrderHistoryPageComponent} from './pages/order-history-page/order-history-page.component';
import {StaffresetPageComponent} from './pages/staffreset-page/staffreset-page.component';
import {StaffVerifyPageComponent} from './pages/staff-verify-page/staff-verify-page.component';
import { CategoryPageComponent } from './pages/category-page/category-page.component';
import { AddMenuItemComponent } from './components/add-menu-item/add-menu-item.component';


const routes: Routes = [
  {path: 'home', component: HomePageComponent},
  {path: 'menu', component: MenuPageComponent},
  {path: 'view-cart', component: CartPageComponent},
  {path: 'login', component: LoginPageComponent},
  {path: 'staff', component: StaffLoginPageComponent},
  {path: 'register', component: RegistrationPageComponent},
  {path: 'profile', component: ProfilePageComponent},
  {path: 'forgot', component: ForgotPasswordPageComponent},
  {path: 'reset', component: ResetPasswordPageComponent},
  {path: 'admin-reports', component: AdminReportPageComponent},
  {path: 'admin-dash', component: AdminDashboardPageComponent},
  {path: 'manager-dash', component: ManagerDashboardPageComponent},
  {path: 'sys-manager', component: SystemMaintenancePageComponent},
  {path: 'edit-categories', component: EditCategoriesPageComponent},
  {path: 'edit-users', component: EditUsersPageComponent},
  {path: 'orders', component: ViewOrdersPageComponent},
  {path: 'verify', component: VerifyUserPageComponent},
  {path: 'order-history', component: OrderHistoryPageComponent},
  {path: 'staff-verify', component: StaffVerifyComponent},
  {path: 'staff-reset', component: StaffResetComponent},
  {path: 'category/:id', component: CategoryPageComponent },


  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: '**', redirectTo: '/home', pathMatch: 'full'},
];

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    MenuItemComponent,
    NavBarComponent,
    ShoppingCartComponent,
    CartItemComponent,
    SideBarComponent,
    LoginComponent,
    MenuPageComponent,
    LoginPageComponent,
    RegisterComponent,
    StaffLoginComponent,
    StaffLoginPageComponent,
    RegistrationPageComponent,
    UserProfileComponent,
    ProfilePageComponent,
    PasswordResetComponent,
    ResetPasswordPageComponent,
    ForgotPasswordComponent,
    ForgotPasswordPageComponent,
    CartPageComponent,
    AdminReportsComponent,
    AdminReportPageComponent,
    AdminDashboardComponent,
    AdminDashboardPageComponent,
    ManagerDashboardComponent,
    ManagerDashboardPageComponent,
    SystemMaintenanceComponent,
    SystemMaintenancePageComponent,
    EditMenuModalComponent,
    EditOrderModalComponent,
    HomePageComponent,
    WelcomeComponent,
    ViewCategoriesComponent,
    EditCategoriesPageComponent,
    ViewUsersComponent,
    EditUsersPageComponent,
    ViewOrdersComponent,
    ViewOrdersPageComponent,
    VerifyUserComponent,
    VerifyUserPageComponent,
    OrderHistoryComponent,
    OrderHistoryPageComponent,
    StaffVerifyComponent,
    StaffResetComponent,
    StaffresetPageComponent,
    StaffVerifyPageComponent,
    EditProfileModalComponent,
    CategoryPageComponent,
    AddMenuItemComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    NgbModule,
    FontAwesomeModule,
    FormsModule,
    MatTableModule,
    BrowserAnimationsModule,
    MatDialogModule,

  ],
  providers: [authInterceptorProviders, MenuService],
  bootstrap: [AppComponent]
})

export class AppModule {}
