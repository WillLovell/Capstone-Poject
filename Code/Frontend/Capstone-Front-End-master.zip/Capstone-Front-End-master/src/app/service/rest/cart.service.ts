import {Injectable} from '@angular/core';
import {MenuItem} from "../../dto/menu-item";
import {ShoppingCart} from "../../dto/shopping-cart";
import {CartItem} from "../../dto/cart-item";
import {BehaviorSubject, Observable, ReplaySubject, Subject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
/**
 * CartService is the central class responsible for management of ShoppingCart Class as menu items
 * are added and removed from the Shop Cart.
 */
export class CartService {
  private subject: Subject<ShoppingCart> = new BehaviorSubject<ShoppingCart>(new ShoppingCart([], 0, 0));
  private _shoppingCart: ShoppingCart;


  constructor() {
    this._shoppingCart = new ShoppingCart([], 0, 0);
  }

  /**
   * Menu item is received by the service and converted to a cart item. The method calls
   * the internal convertToCartItem method to perform the conversion
   * @param menuItem
   */
  addItemToCart(menuItem: MenuItem) {
    this.convertToCartItem(menuItem);
  }

  /**
   * Create new cart item
   * @param menuItem to convert
   * @private
   */
  private convertToCartItem(menuItem: MenuItem): void {

    const newCartItem: CartItem = new CartItem(menuItem.price, 1, menuItem.name,
      menuItem.imageUrl, menuItem.id);

    this.updateShoppingCart(newCartItem);
  }

  /**
   * The shoping cart is updated with the new cart item. The current cart is searched for
   * the item, if found increase quantity, else padd new item to the cart item array.
   * After processing, shopping cart totals are updated accordingly
   * @param newCartItem
   * @private
   */
  private updateShoppingCart(newCartItem: CartItem) {

    if (this._shoppingCart.cartItems.filter(e => e.menuItemId === newCartItem.menuItemId).length == 0) {
      this._shoppingCart.cartItems.push(newCartItem);
      console.log(this._shoppingCart.cartItems[0]);
    } else {
      for (let i = 0; i < this._shoppingCart.cartItems.length; i++) {
        console.log("LENGTH > 1");
        if (this._shoppingCart.cartItems[i].menuItemId == newCartItem.menuItemId) {
          let quantity: number = this._shoppingCart.cartItems[i].quantity + 1;
          this._shoppingCart.cartItems[i].quantity = quantity;
          break;
        }
      }
    }

    this.updateShoppingCartTotalQuantity(); //UPDATE TOTAL QUANTITY
    this.updateShoppingCartTotalPrice();
    // let x = this._shoppingCart.cartItems.forEach(
    //   function (cartItem) {
    //     let result:number = cartItem.quantity * cartItem.price;
    //   }
    // )
    // // @ts-ignore
    // this._shoppingCart.totalPrice = x;
    this.sendShoppingCartData();
  }

  /**
   * Send updated shopping cart info to all subscribers
   */
  sendShoppingCartData(): void {
    this.subject.next(this._shoppingCart);
  }

  /**
   * Method for all subscribers to call to get the latest information.
   */
  getShoppingCartData(): Observable<ShoppingCart> {
    return this.subject.asObservable();
  }

  /**
   * Method called from components using the service to increment the quantity
   * of a cart item
   * @param cartItemId id of the cart item's quantity  to incremeent
   */
  incrementCartItem(cartItemId: number): void {
    // @ts-ignore
    this._shoppingCart.cartItems.find(e => e.menuItemId == cartItemId).quantity++;
    /**
     * Method called from components using the service to increment the quantity
     * of a cart item
     * @param cartItemIdid of the cart item's quantity to decremeent
     */
    this.updateShoppingCartTotalQuantity(); //UPDATE TOTAL QUANTITY
    this.updateShoppingCartTotalPrice();
    this.sendShoppingCartData();
  }

  /**
   * Method to decrease the number of items in a cart
   * @param cartItemId
   */
  decrementCartItem(cartItemId: number): void {
    // @ts-ignore
    this._shoppingCart.cartItems.find(e => e.menuItemId == cartItemId).quantity--;
    this.updateShoppingCartTotalQuantity(); //UPDATE TOTAL QUANTITY
    this.updateShoppingCartTotalPrice();
    this.sendShoppingCartData();
  }

  /**
   * Method to delete an item from the cart
   * @param cartItemId
   */
  deleteCartItem(cartItemId: number): void {
    // @ts-ignore
    console.log("In Cart service to remove item no" + cartItemId);
    const index = this._shoppingCart.cartItems.findIndex(e => e.menuItemId === cartItemId);
    console.log("INDEX IS: " + index);
    console.log("length b4: " + this._shoppingCart.cartItems.length);
    if (index > -1) {
      this._shoppingCart.cartItems.splice(index, 1);
    }
    this.updateShoppingCartTotalQuantity(); //UPDATE TOTAL QUANTITY
    this.updateShoppingCartTotalPrice();
    this.sendShoppingCartData();
  }

  /**
   * method to update the shopping carts total quantity
   * @private
   */
  private updateShoppingCartTotalQuantity(): void {
    let totalItems: number = 0;
    this._shoppingCart.cartItems.forEach(cartItem => totalItems += cartItem.quantity);
    this._shoppingCart.totalQuantity = totalItems;
  }

  /**
   * method to update the shopping carts total price
   * @private
   */
  private updateShoppingCartTotalPrice(): void {
    let totalPrice: number = 0;
    this._shoppingCart.cartItems.forEach(cartItem => totalPrice += cartItem.quantity * cartItem.price);
    this._shoppingCart.totalPrice = totalPrice;

  }


}
