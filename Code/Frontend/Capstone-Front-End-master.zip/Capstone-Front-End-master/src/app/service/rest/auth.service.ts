import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {User} from "../../dto/user";

const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})

/**
 * class in charge of API calls for login
 */
export class AuthService {
  private user!: User

  constructor(private http: HttpClient) {
  }

  /**
   * API call to register a customer
   * @param firstName
   * @param lastName
   * @param email
   * @param password
   */
  register(firstName: string, lastName: string, email: string, password: string): Observable<any> {
    return this.http.post(ORDER_API + 'customers', {
      email,
      firstName,
      password
    }, httpOptions);
  }

  /**
   * API call to deactivate a customer
   */
  deactivateUser() {
    return this.http.delete(ORDER_API + 'customers')
  }

  /**
   * API call to login as a customer
   * @param username
   * @param password
   */
  login(username: string, password: string): Observable<any> {
    return this.http.post(ORDER_API + 'login', {
      username,
      password
    }, httpOptions);
  }

  /**
   * API call to login as a Staff user
   * @param username
   * @param password
   */
  staffLogin(username: string, password: string): Observable<any> {
    return this.http.post(ADMIN_API + 'login', {
      username,
      password
    }, httpOptions);
  }

  /**
   * Method to save a user and store their email
   * @param username
   */
  saveUser(username: string) {
    this.user = new  User()
    this.user.email = username
  }

  /**
   * Method to get a saved user
   */
  getUser(): Observable<User>{
    return this.user.asObservable();
  }

  /**
   *API call to verify a new customer account
   */
  verify() {
    return this.http.get(ORDER_API + 'login/1/confirm-account')

  }

  /**
   * API call to verify a new staff account
   */
  staffVerify() {
    return this.http.get(ADMIN_API + 'confirm')
  }

  /**
   * API call to get the current usertype to render user specific content
   */
  getUserType() {
    return this.http.get(ADMIN_API + 'can-access')
  }

  /**
   * API call confirm a staff user
   */
  // confirmStaff() {
  //   return this.http.get(ADMIN_API + 'confirm')
  // }


}
