import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

@Injectable({
  providedIn: 'root'
})

/**
 * This class handles API calls related to sorting reports
 */
export class ReportService {

  constructor(private http: HttpClient) { }

  /**
   * Gets orders related to the customer ID
   * @param id
   */
  getOrdersByCustomer(id: number){
    return this.http.get(ADMIN_API + 'dashboard/orders/search/customer')
  }

  /**
   * Gets orders based on a todays date
   */
  getOrdersByDate(){
    return this.http.get(ADMIN_API + 'dashboard/orders/search/date')
  }

  /**
   * Gets orders related to the order ID
   * @param id
   */
  getOrdersByOrderID(id: number){
    return this.http.get(ADMIN_API + 'dashboard/orders/search/order/' + id)
  }

  /**
   * Gets order related to a given status
   * @param status
   */
  getOrdersByStatus(status: string){
    return this.http.get( ADMIN_API + 'dashboard/orders/search/status/' + status)
  }
}
