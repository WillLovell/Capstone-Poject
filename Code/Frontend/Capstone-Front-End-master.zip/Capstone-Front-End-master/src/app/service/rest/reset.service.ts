import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";

const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})

/**
 * This class is in charge of the API calls related to resetting a password
 */
export class ResetService {

  constructor(private http: HttpClient) {
  }

  /**
   * API call to send a reset email to a customer
   * @param username
   */
  forgot(username: string): Observable<any> {
    return this.http.post(ORDER_API + 'login/forgot-password', {
      username
    }, httpOptions);
  }

  /**
   * API call to update the password to reset it
   * @param password
   */
  reset(password: string): Observable<any> {
    return this.http.post(ORDER_API + 'login/reset-password', {
      password
    }, httpOptions);
  }

  /**
   * API call to send a reset email to a staff user
   * @param username
   */
  staffForgot(username: string): Observable<any> {
    return this.http.post(ADMIN_API + 'login/forgot-password', {
      username,
    });
  }
  /**
   * API call to update the password and reset it for a staff user
   * @param password
   */
  staffReset(password: string): Observable<any> {
    return this.http.post(ADMIN_API + 'login/reset-password', {
      password
    }, httpOptions);
  }


}
