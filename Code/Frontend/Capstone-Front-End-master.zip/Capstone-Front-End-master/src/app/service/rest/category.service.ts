import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";

const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

@Injectable({
  providedIn: 'root'
})

/**
 * Class that has API's related to categories
 */
export class CategoryService {

  constructor(private http: HttpClient) {
  }

  /**
   * API call to get all exisitng categories
   */
  getMenuCategories() {
    return this.http.get(ADMIN_API + 'dashboard/menu/category')
  }

  /**
   * API call to get a specific menu category based on ID
   * @param id
   */
  getMenuCategory(id: number) {
    return this.http.get( ADMIN_API + 'dashboard/menu/category/' + id)
  }

  /**
   * API call to update a categories details
   * @param id
   * @param name
   */
  updateMenuCategory(id: number, name: string){
    return this.http.put( ADMIN_API + 'dashboard/menu/category/' + id, {
      name,
    })
  }



}
