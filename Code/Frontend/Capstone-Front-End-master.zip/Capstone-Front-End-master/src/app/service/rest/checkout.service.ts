import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable, tap} from "rxjs";
import {OrderRequest} from 'src/app/dto/order-request';
import {error} from "@angular/compiler/src/util";

const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

@Injectable({
  providedIn: 'root'
})

/**
 * Class in charge of APIs related to checkout
 */
export class CheckoutService {


  constructor(private http: HttpClient) {
  }

  /**
   * API to check if an order is allowed to be placed
   */
  canPlace() {
    return this.http.get(ORDER_API + 'account/can-place')
  }

  /**
   * API call to submit and order
   * @param orderRequest
   */
  placeOrder(orderRequest: OrderRequest): Observable<any> {
    return this.http.post<OrderRequest>(ORDER_API + 'account/checkout', {orderRequest}
    );

  }

  /**
   * API call to cancel an order
   * @param customerID
   * @param orderID
   */
  cancelOrder(customerID: number, orderID: number) {
    return this.http.post(ORDER_API + 'account/' + customerID + '/cancel-order' + orderID, {
      customerID,
      orderID
    });
  }

}
