import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";

const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

@Injectable({
  providedIn: 'root'
})

/**
 * This class is in charge of API calls related to orders
 */
export class OrderService {

  constructor(private http: HttpClient) {
  }

  /**
   * API that gets all orders of a specific customer
   * @param id
   * @param criteria
   */
  getOrderHistory(id: number, criteria: string) {
    return this.http.get(ORDER_API + 'account/' + id + '/search/' + criteria)
  }

  /**
   * API to cancel an order
   * @param customerID
   * @param orderID
   */
  cancelOrder(customerID: number, orderID: number){
    return this.http.post(ORDER_API + 'account/' + customerID + '/cancel-order', {
      customerID,
      orderID
    })
  }

  /**
   * API for staff to update an orders status
   * @param id
   * @param status
   */
  updateOrderStatus(id: number, status: string){
    return this.http.put(ADMIN_API + 'dashboard/orders', {
      id,
      status,
    })
  }

  /**
   * API to get all orders
   */
  getOrders() {
    return this.http.get( ADMIN_API + 'dashboard/orders/status')
  }
}
