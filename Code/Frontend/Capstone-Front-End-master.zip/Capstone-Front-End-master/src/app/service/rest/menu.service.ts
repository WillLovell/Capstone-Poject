import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable, tap} from "rxjs";
import {MenuItem} from "../../dto/menu-item";

const ADMIN_API = 'http://13.52.165.220:3000/';
const ORDER_API = 'http://13.52.165.220:3000/';

@Injectable({
  providedIn: 'root'
})
/**
 * The class is responsible for making API calls to retrieve menu related data
 */
export class MenuService {
  constructor(private _http: HttpClient) {
  }

  /**
   * API to get all menu items
   */
  getAllMenuItems(): Observable<MenuItem[]> {
    // return this._http.get<MenuItem[]>(this.BASEURL).pipe(
    //   tap(res_ => console.log(res_)),
    // );

    return this._http.get<MenuItem[]>(ORDER_API + 'menu');

  }

  /**
   * API to a specific menu item based on the item ID
   * @param id
   */
  getMenuItem(id: number): Observable<MenuItem> {
    return this._http.get<MenuItem>(ORDER_API + 'menu/menu/' + id).pipe(
      tap(res_ => console.log(res_)),
    );
  }

  /**
   * API to get specific menuitems based on the category ID
   * @param id
   */
  getMenuCategory(id: number): Observable<MenuItem> {
    return this._http.get<MenuItem>(ORDER_API + 'menu/menu/category/' + id).pipe(
      tap(res_ => console.log(res_)),
    );
  }

  /**
   * API to create a menuItem
   * @param description
   * @param imageURL
   * @param menuCategoryID
   * @param name
   * @param price
   * @param status
   */
  createMenuItem(description: string, imageURL: string, menuCategoryID: number, name: string, price: number, status: boolean) {
    return this._http.post(ADMIN_API + 'dashboard/menu', {
      description,
      imageURL,
      menuCategoryID,
      name,
      price,
      status
    })
  }

  /**
   * API to update a menuItem
   * @param id
   * @param description
   * @param imageURL
   * @param menuCategoryID
   * @param name
   * @param price
   * @param status
   */
  updateMenuItem(id: number, description: string, imageURL: string, menuCategoryID: number, name: string, price: number, status: boolean) {
    return this._http.put(ADMIN_API + 'dashboard/menu/' + id, {
      description,
      imageURL,
      menuCategoryID,
      name,
      price,
      status
    })
  }

  /**
   * API to delete a menuItem based on ID
   * @param id
   */
  deleteMenuItem(id: number) {
    return this._http.delete(ADMIN_API + 'dashboard/menu/' + id)
  }


}
