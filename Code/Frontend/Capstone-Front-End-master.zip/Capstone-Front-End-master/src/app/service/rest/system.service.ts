import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";

const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

@Injectable({
  providedIn: 'root'
})

/**
 * This class is responsible for making API calls related to the system maintenance
 */
export class SystemService {

  constructor(private http: HttpClient) {
  }

  /**
   * API to create operating hours for a specific day
   * @param close
   * @param dayOfWeek
   * @param open
   */
  createHours(close: string, dayOfWeek: number, open: string){
    return this.http.post(ADMIN_API + 'dashboard/hours', {
      close,
      dayOfWeek,
      open,
    })
  }

  /**
   * API call to update operating ours of a specific day
   * @param close
   * @param dayOfWeek
   * @param open
   */
  updateHours(close: string, dayOfWeek: number, open: string){
    return this.http.put(ADMIN_API + 'dashboard/hours', {
      close,
      dayOfWeek,
      open,
    })
  }


}
