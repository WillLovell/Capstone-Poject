import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {addModuleImportToModule} from "@angular/cdk/schematics";

const ADMIN_API = 'http://13.52.165.220:8081/';
const ORDER_API = 'http://13.52.165.220:8082/';

@Injectable({
  providedIn: 'root'
})

/**
 * The class is responsible for making API calls to retrieve user related data
 */
export class UserService {
  constructor(private http: HttpClient) {
  }

  /**
   * API call to create a customer
   * @param email
   * @param firstName
   * @param lastName
   * @param password
   */
  createStaff(email: string, firstName: string, lastName: string, password: string){
    return this.http.post(ADMIN_API + 'dashboard/staff', {
      email,
      firstName,
      lastName,
      password,
    })
  }

  /**
   * API call to deactivate a staff user account
   */
  deactivateStaff(){
    return this.http.delete(ADMIN_API + 'dashboard/staff');
}


  getPublicContent(): Observable<any> {
    return this.http.get(ADMIN_API + 'all', {responseType: 'text'});
  }

  /**
   * API call to get a specific users data
   * @param id
   */
  getCustomer(id: number) {
    return this.http.get(ORDER_API + 'customers/' + id)
  }

  /**
   * API call to update a customers data
   * @param id
   * @param email
   * @param firstName
   * @param lastName
   */
  updateCustomer(id: number, email: string, firstName: string, lastName: string) {
    return this.http.put(ORDER_API + 'customers/' + id, {
      email,
      firstName,
      lastName
    });
  }

  /**
   * API call to return all staff users in database
   */
  getAllStaff() {
    return this.http.get( ADMIN_API + '/dashboard/staff')
  }

  /**
   * API to get a specific staff users data
   * @param id
   */
  getStaff(id: number) {
    return this.http.get(ADMIN_API + '/dashboard/staff/' + id)
  }

  /**
   * API call to update a staff users data
   * @param id
   * @param email
   * @param firstName
   * @param lastName
   */
  updateStaff(id: number, email: string, firstName: string, lastName: string) {
    return this.http.put(ADMIN_API + 'dashboard/staff/' + id, {
      email,
      firstName,
      lastName
    })
  }

  /**
   * API call to return all customers
   */
  getCustomers() {
    return this.http.get(ADMIN_API + '/dashboard/customers')
  }


  // getCurrentUser() {
  //   return this.http.get(ORDER_API + '')
  // }

  // updateUser() {
  //
  // }
}
